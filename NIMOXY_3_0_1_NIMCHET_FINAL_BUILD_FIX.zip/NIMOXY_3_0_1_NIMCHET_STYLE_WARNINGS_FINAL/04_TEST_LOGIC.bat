@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo NIMOXY 3.0 - WINDOWS BUILD + REAL LOGIC TEST
echo ============================================================
where dotnet >nul 2>nul || (echo [FAIL] dotnet not found & exit /b 1)
dotnet restore Source\NIMOXY.csproj || exit /b 1
dotnet build Source\NIMOXY.csproj -c Release --no-restore || exit /b 1
echo [OK] Build passed.

echo.
echo [INFO] Running real regression suite (Tests\BenchmarkLogicTests.cs)
echo [INFO] against the built EXE with --self-test ...
for /f "delims=" %%p in ('dotnet build Source\NIMOXY.csproj -c Release --no-restore -v q -getProperty:TargetPath') do set NIMOXY_EXE=%%p
if not exist "%NIMOXY_EXE%" (
    echo [FAIL] Could not locate built EXE to run --self-test.
    exit /b 1
)
"%NIMOXY_EXE%" --self-test
if errorlevel 1 (
    echo [FAIL] Logic self-test FAILED. See %%LocalAppData%%\NIMOXY\crash.log for details.
    exit /b 1
)
echo [OK] Logic self-test passed.
echo.
echo [INFO] For live DNS Apply/Benchmark validation, run the EXE as Administrator on Windows 10/11.
exit /b 0
