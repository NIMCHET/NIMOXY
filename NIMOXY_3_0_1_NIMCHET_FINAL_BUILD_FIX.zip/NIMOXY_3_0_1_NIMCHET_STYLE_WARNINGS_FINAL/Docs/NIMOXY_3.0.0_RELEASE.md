# NIMOXY 3.0.0 — Global DNS Optimizer

Production-oriented rebuild centered on **Auto Pilot**, with separate Fast Probe and Deep Benchmark engines, verified-first DNS switching, tray-first startup, two verified fallbacks, live latency graph, global catalog aggregation, gaming profiles, and conservative anti-flapping.

## Important honesty rule
DNS resolver latency is not the same as in-game server ping. Gaming scoring measures DNS-related performance only.

## Auto Pilot defaults
- Check every 15 seconds
- 110 ms absolute degradation threshold
- 35% relative degradation
- 15% minimum meaningful improvement
- 3 consecutive bad checks
- 5 minute minimum hold
- 120 second cooldown
- 3 candidate verification probes

## Benchmark integrity
Every global operation tracks expected candidates and terminal results. The UI must never claim a complete scan unless the accounting reconciles.

## Install
Run `01_BUILD_EXE.bat` on Windows, then `02_BUILD_INSTALLER.bat` after publishing if Inno Setup is installed.
