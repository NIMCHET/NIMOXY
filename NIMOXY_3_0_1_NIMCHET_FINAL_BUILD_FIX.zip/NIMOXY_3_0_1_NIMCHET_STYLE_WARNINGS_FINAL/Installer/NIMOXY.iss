#define MyAppName "NIMOXY"
#define MyAppVersion "3.0.1"
#define MyAppPublisher "Nima"
#define MyAppExeName "NIMOXY.exe"
[Setup]
AppId={{A7C59B71-0C4F-4B54-BD8F-8D4D5A1B7C22}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\NIMOXY
DefaultGroupName={#MyAppName}
OutputBaseFilename=NIMOXY_Setup_3.0.1
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
UninstallDisplayIcon={app}\{#MyAppExeName}
SetupIconFile=..\Assets\AppIcon.ico
; Section C.1 (installer polish): branded wizard artwork instead of Inno's
; generic default banner/header, so Welcome/Finish look like a NIMOXY product
; screen rather than a stock installer. Plain WizardImageFile/WizardSmallImageFile —
; no plugin/DLL dependency, works with the stock Inno Setup compiler.
WizardImageFile=WizardImages\WizardModernImage.bmp
WizardSmallImageFile=WizardImages\WizardModernSmallImage.bmp
WizardImageStretch=no
WizardSizePercent=100
[Files]
Source: "..\Release\NIMOXY\NIMOXY.exe"; DestDir: "{app}"; Flags: ignoreversion
[Tasks]
; FIX 6.1: was a forced [Icons] entry with no way to skip it. Now an ordinary
; optional install-time Task, unchecked by default like a normal desktop icon
; prompt, so a Desktop shortcut is only created if the user actually asks for one.
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked
; FIX 6.2: was an unconditional [Run] entry that created an elevated
; (/RL HIGHEST) Scheduled Task on every single install, completely independent
; of — and invisible to — the app's own STARTUP toggle (AppStartupService,
; a plain non-elevated HKCU Run-key entry the user controls from inside
; NIMOXY). That meant a user could see "STARTUP OFF" in the app and still get
; an elevated auto-launch at every logon they never explicitly agreed to, with
; no in-app control over it — a real, undisclosed privilege-escalation-at-boot
; surface. It is now an explicit, unchecked-by-default, clearly-labelled Task:
; nothing elevated is scheduled unless the user opts in at install time. The
; app's own STARTUP button remains the normal, non-elevated way to control
; auto-start after install.
Name: "autostarttask"; Description: "اجرای خودکار NIMOXY هنگام ورود به ویندوز با دسترسی مدیر (Scheduled Task). در غیر این صورت می‌توانید بعداً از دکمه‌ی STARTUP داخل برنامه استفاده کنید."; GroupDescription: "گزینه‌های راه‌اندازی خودکار"; Flags: unchecked
[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\{#MyAppExeName}"; Tasks: desktopicon
[Run]
Filename: "schtasks.exe"; Parameters: '/Create /TN "NIMOXY Auto Start" /TR """{app}\NIMOXY.exe""" /SC ONLOGON /RL HIGHEST /F'; Flags: runhidden waituntilterminated; Tasks: autostarttask
Filename: "{app}\{#MyAppExeName}"; Description: "اجرای NIMOXY"; Flags: nowait postinstall skipifsilent
[UninstallRun]
Filename: "schtasks.exe"; Parameters: '/Delete /TN "NIMOXY Auto Start" /F'; Flags: runhidden waituntilterminated
; FIX 6.3: uninstall previously only removed the Scheduled Task above and left
; the HKCU\...\Run\NIMOXY value behind — anything AppStartupService.SetEnabled
; wrote while the app's own STARTUP button was ON would survive uninstall and
; keep trying to launch a now-deleted NIMOXY.exe at every logon. reg.exe exits
; non-zero (harmlessly) if the value was never created; that does not fail or
; interrupt the uninstall.
Filename: "reg.exe"; Parameters: 'delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "NIMOXY" /f'; Flags: runhidden waituntilterminated
[Messages]
; Section C.1 (installer polish): the checkbox-for-shortcut and
; checkbox-for-"run the app", both under the Finish page, are NOT new here —
; they already existed and already worked correctly (see [Tasks] "desktopicon"
; above and the {app}\{#MyAppExeName} entry in [Run] with Flags: postinstall,
; which is exactly what makes Inno draw a "Launch NIMOXY" checkbox on Finish).
; What changes here is only presentation: Persian wizard copy + the branded
; artwork above, matching the app's own Persian docs/README_FA.txt tone.
WelcomeLabel1=به نصب %1 خوش آمدید
WelcomeLabel2=این برنامه، %1 را روی سیستم شما نصب می‌کند.%n%nپیشنهاد می‌شود پیش از ادامه، سایر برنامه‌های در حال اجرا را ببندید.
FinishedHeadingLabel=نصب %1 با موفقیت به پایان رسید
FinishedLabelNoIcons=نصب NIMOXY تمام شد.
FinishedLabel=نصب NIMOXY با موفقیت انجام شد. برای اجرای برنامه یا ساخت میانبر روی دسکتاپ، از گزینه‌های زیر استفاده کنید.
ClickFinish=برای خروج از نصب، روی «پایان» کلیک کنید.
ButtonFinish=&پایان
