# NIMOXY 2.7.2 — ALL DNS CATALOG

NIMOXY now treats the public DNS catalog as a dynamic global dataset instead of a small built-in list.

Sources:
- public-dns.info all public nameservers CSV
- public-dns.info all public nameservers plaintext fallback
- public-resolvers.json (DNSCrypt/DoH resolver catalog)
- built-in curated well-known resolvers as an offline fallback

Both public IPv4 and public IPv6 endpoints are accepted by the catalog and benchmark engine.
Duplicate IPs are merged and metadata from richer sources is preserved.

Important: the catalog is dynamic. It does not permanently embed every public resolver IP in the ZIP because the public resolver population changes continuously. On the current public-dns.info page the database reports 62,790 nameservers from 193 countries, and the site exposes downloads for valid/all nameservers.

Windows DNS Apply remains conservative: the existing apply path is IPv4-focused. IPv6 entries can be benchmarked and ranked without being silently applied through an IPv4-only setter.
