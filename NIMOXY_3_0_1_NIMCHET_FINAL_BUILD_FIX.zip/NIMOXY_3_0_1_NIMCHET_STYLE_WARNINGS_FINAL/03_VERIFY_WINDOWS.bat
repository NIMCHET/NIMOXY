@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NIMOXY - Windows Verification
color 0A

echo.
echo  ================================================
echo       NIMOXY 2.3.0 - WINDOWS VERIFICATION
echo  ================================================
echo.
where dotnet >nul 2>&1
if errorlevel 1 (
  echo [ERROR] dotnet SDK was not found.
  echo Run 01_BUILD_EXE.bat first or install .NET 8 SDK.
  pause
  exit /b 2
)

echo [INFO] dotnet version:
dotnet --version

echo.
echo [1/3] Restore
dotnet restore "Source\NIMOXY.csproj"
if errorlevel 1 goto :fail

echo.
echo [2/3] Build
dotnet build "Source\NIMOXY.csproj" -c Release --no-restore
if errorlevel 1 goto :fail

echo.
echo [3/3] Publish Win-x64
dotnet publish "Source\NIMOXY.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "Release\NIMOXY"
if errorlevel 1 goto :fail

echo.
echo [OK] Windows build verification passed.
echo EXE: %CD%\Release\NIMOXY\NIMOXY.exe
pause
exit /b 0

:fail
echo.
echo [FAILED] Verification/build failed. Compiler output is shown above.
pause
exit /b 1
