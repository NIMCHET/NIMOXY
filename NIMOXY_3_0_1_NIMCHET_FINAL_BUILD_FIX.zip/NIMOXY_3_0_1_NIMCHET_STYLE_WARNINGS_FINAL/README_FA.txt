NIMOXY 3.0.1
GLOBAL DNS OPTIMIZER

هسته اصلی این نسخه Auto Pilot است.
Fast Probe برای پایش سریع و Deep Benchmark برای رتبه‌بندی دقیق جدا هستند.
X پنجره را می‌بندد ولی برنامه را Exit نمی‌کند؛ به Tray می‌رود.
Exit واقعی فقط از Tray انجام می‌شود.

برای Build روی Windows:
1) 01_BUILD_EXE.bat
2) برای Installer: 02_BUILD_INSTALLER.bat

نکته مهم: DNS latency با ping داخل بازی یکی نیست. NIMOXY این دو را قاطی نمی‌کند.
