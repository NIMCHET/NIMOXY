@echo off
setlocal
cd /d "%~dp0"
cls
echo.
echo  ================================================
echo                    NIMOXY
echo          GLOBAL PUBLIC DNS OPTIMIZER
echo  ================================================
echo.
echo  [1] Build EXE
echo  [2] Build Installer
echo  [3] Open README
echo  [Q] Quit
echo.
choice /c 123Q /n /m "Select: "
if errorlevel 4 exit /b 0
if errorlevel 3 start "" notepad "%~dp0README_FA.txt" & goto :eof
if errorlevel 2 call "%~dp002_BUILD_INSTALLER.bat" & goto :eof
if errorlevel 1 call "%~dp001_BUILD_EXE.bat" & goto :eof
