@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NIMOXY - Build EXE
color 0B

echo.
echo  ================================================
echo                 NIMOXY BUILD
echo  ================================================
echo.

where dotnet >nul 2>&1
if errorlevel 1 (
  echo [INFO] .NET 8 SDK was not found.
  where winget >nul 2>&1
  if errorlevel 1 (
    echo [ERROR] Neither dotnet nor winget is available.
    echo Install .NET 8 SDK manually, then run this file again.
    pause
    exit /b 2
  )
  echo [INFO] Installing .NET 8 SDK with Windows Package Manager...
  winget install --id Microsoft.DotNet.SDK.8 --exact --accept-source-agreements --accept-package-agreements
  if errorlevel 1 (
    echo [ERROR] Automatic .NET 8 installation failed.
    pause
    exit /b 2
  )
  set "PATH=%PATH%;%ProgramFiles%\dotnet"
)

where dotnet >nul 2>&1
if errorlevel 1 (
  echo [ERROR] dotnet is still unavailable after installation.
  echo Restart this terminal once, then run the script again.
  pause
  exit /b 2
)

if exist "Release\NIMOXY" rmdir /s /q "Release\NIMOXY"
if exist "Source\bin" rmdir /s /q "Source\bin"
if exist "Source\obj" rmdir /s /q "Source\obj"

pushd Source
dotnet restore NIMOXY.csproj
if errorlevel 1 goto :fail
dotnet publish NIMOXY.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o "..\Release\NIMOXY"
if errorlevel 1 goto :fail
popd

if not exist "Release\NIMOXY\NIMOXY.exe" (
  echo [ERROR] Publish reported success but NIMOXY.exe was not found.
  pause
  exit /b 1
)

echo.
echo [OK] NIMOXY.exe created successfully:
echo %CD%\Release\NIMOXY\NIMOXY.exe
echo.
pause
exit /b 0

:fail
popd
echo.
echo [FAILED] Build failed. The compiler output above contains the exact error.
echo.
pause
exit /b 1
