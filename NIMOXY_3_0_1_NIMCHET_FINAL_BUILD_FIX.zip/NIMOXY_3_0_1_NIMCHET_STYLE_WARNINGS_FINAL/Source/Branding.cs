namespace NIMOXY;
public static class Branding
{
    public const string Name = "NIMOXY";
    public const string Owner = "Nima";
    public const string BrandLine = "NIMOXY • Nima";
}
