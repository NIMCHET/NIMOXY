using System.IO;
using System.Threading.Tasks;
using System.Windows;
using NIMOXY.Services;

namespace NIMOXY;

public partial class App : System.Windows.Application
{
    public static AppSettings Settings { get; } = AppSettings.Load();
    private static string LogPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NIMOXY", "crash.log");

    protected override void OnStartup(StartupEventArgs e)
    {
        // "--self-test" runs the real regression suite (Tests/BenchmarkLogicTests)
        // against the actual production services and exits with a non-zero code
        // on failure — this is what 04_TEST_LOGIC.bat now calls, so "build
        // succeeded" and "tests pass" (Section 74 acceptance criteria) are two
        // different, both-genuinely-checked things instead of one being assumed
        // from the other.
        if (e.Args.Contains("--self-test", StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                NIMOXY.Tests.BenchmarkLogicTests.RunAll();
                Log("Self-test", new Exception("PASS (informational log, not an error)"));
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Log("Self-test FAILED", ex);
                Environment.Exit(1);
            }
            return;
        }

        DispatcherUnhandledException += (_, args) =>
        {
            Log("UI exception", args.Exception);
            // Last line of defence for WPF event-handler exceptions.
            args.Handled = true;
            try
            {
                if (Current?.MainWindow is MainWindow w && !w.Dispatcher.HasShutdownStarted)
                    w.ReportRecoverableError(args.Exception);
            }
            catch { }
        };

        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            Log("Unobserved task exception", args.Exception);
            args.SetObserved();
        };

        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            try { Log("AppDomain unhandled exception", args.ExceptionObject as Exception ?? new Exception(args.ExceptionObject?.ToString())); } catch { }
        };

        try
        {
            base.OnStartup(e);
            if (e.Args.Contains("--self-test", StringComparer.OrdinalIgnoreCase)) return;

            // Do not use StartupUri here. Explicit construction lets us catch
            // constructor/XAML/runtime failures before Windows briefly shows a
            // blank/black window and the process exits.
            var window = new MainWindow();
            MainWindow = window;
            window.Show();
        }
        catch (Exception ex)
        {
            Log("Startup exception", ex);
            try
            {
                System.Windows.MessageBox.Show(
                    "NIMOXY failed to start.\n\n" + ex.Message +
                    "\n\nDiagnostic log:\n" + LogPath,
                    "NIMOXY startup error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch { }
            Shutdown(1);
        }
    }

    private static void Log(string title, Exception ex)
    {
        try
        {
            var dir = Path.GetDirectoryName(LogPath)!;
            Directory.CreateDirectory(dir);
            File.AppendAllText(LogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] {title}: {ex}\r\n\r\n");
        }
        catch { }
    }
}
