using NIMOXY.Models;
using NIMOXY.Services;
using System.IO;

namespace NIMOXY.Tests;

// These call the real production classes (OperationTracker, RetirementService),
// not a re-derived copy of their formulas. That is the point: Section 70/
// PASS 15 asks for a regression check that accounting is honest, and a test
// that reimplements the logic separately would never catch a real regression
// in NIMOXY.Services itself.
public static class BenchmarkLogicTests
{
    public static void RunAll()
    {
        AccountingReconcilesWhenEveryCandidateTerminal();
        AccountingIsIncompleteWhenCandidatesAreMissing();
        AccountingIsInconsistentOnDoubleTerminalWrite();
        AccountingNeverReportsCompleteEarly();
        RetirementRequiresMultipleFailuresNotOne();
        RetirementIsReversibleOnSuccess();
        RetirementRecheckWindowIsRespected();
        TrendRequiresConsecutiveDegradationNotOneSample();
        TrendResetsClearlyOnNewBaseline();
        ConfidenceRequiresBothSampleCountAndConsistency();
        ConfidenceCapPreventsOneSampleFromOutrankingManyStableSamples();
        HistoryServiceRoundTripsSwitchEntriesAndStaysBounded();
        GameDetectionMatchesKnownProcessName();
        GameDetectionIsFalseWhenNoKnownProcessIsRunning();
        GameDetectionIsConservativeWhenEnumerationFails();
        GameDetectionHonorsConfiguredProcessNameOverride();
    }

    // FIX (testability gap noted in the prior handoff): GameDetectionService
    // used to call Process.GetProcesses() directly, so "a game is/is not
    // running" could not be simulated deterministically in a test. It now
    // takes an injectable process-name provider; these tests exercise the
    // real detection logic (case-insensitive matching, conservative default
    // on failure, configurable override list) against fake process lists
    // instead of the real Windows process table.
    private static void GameDetectionMatchesKnownProcessName()
    {
        var svc = new GameDetectionService(new AppSettings(), () => new[] { "explorer", "STEAM", "chrome" });
        if (!svc.IsGameLikelyRunning()) throw new InvalidOperationException("A known launcher process name (case-insensitive) must be detected as gaming.");
    }

    private static void GameDetectionIsFalseWhenNoKnownProcessIsRunning()
    {
        var svc = new GameDetectionService(new AppSettings(), () => new[] { "explorer", "chrome", "notepad" });
        if (svc.IsGameLikelyRunning()) throw new InvalidOperationException("No known game/launcher process running must not be reported as gaming.");
    }

    private static void GameDetectionIsConservativeWhenEnumerationFails()
    {
        var svc = new GameDetectionService(new AppSettings(), () => throw new InvalidOperationException("simulated enumeration failure"));
        // Phase 3's explicit rule: if detection cannot be verified, default to
        // "assume gaming" rather than risk scanning during an actual session.
        if (!svc.IsGameLikelyRunning()) throw new InvalidOperationException("A failed process enumeration must conservatively assume gaming, not the opposite.");
    }

    private static void GameDetectionHonorsConfiguredProcessNameOverride()
    {
        var settings = new AppSettings { GamingSafeModeProcessNames = new List<string> { "mycustomlauncher" } };
        var svc = new GameDetectionService(settings, () => new[] { "steam" });
        // Once an operator supplies their own list, it replaces (not adds to)
        // the built-in defaults -- "steam" alone must no longer match.
        if (svc.IsGameLikelyRunning()) throw new InvalidOperationException("A configured override list must replace the built-in defaults, not be unioned with them.");
        var svc2 = new GameDetectionService(settings, () => new[] { "MyCustomLauncher" });
        if (!svc2.IsGameLikelyRunning()) throw new InvalidOperationException("The configured override list must still match case-insensitively.");
    }

    private static void AccountingReconcilesWhenEveryCandidateTerminal()
    {
        var tracker = new OperationTracker(3);
        tracker.MarkStarted("0"); tracker.MarkStarted("1"); tracker.MarkStarted("2");
        tracker.MarkTerminal("0", TerminalState.Success);
        tracker.MarkTerminal("1", TerminalState.Failed);
        tracker.MarkTerminal("2", TerminalState.Timeout);
        var snap = tracker.Reconcile();
        if (snap.Status != OperationStatus.Complete) throw new InvalidOperationException("Expected Complete when all candidates reached a terminal state.");
        if (!tracker.IsGenuinelyComplete) throw new InvalidOperationException("IsGenuinelyComplete must agree with Reconcile().");
    }

    private static void AccountingIsIncompleteWhenCandidatesAreMissing()
    {
        var tracker = new OperationTracker(5);
        tracker.MarkTerminal("0", TerminalState.Success);
        tracker.MarkTerminal("1", TerminalState.Success);
        var snap = tracker.Reconcile();
        // This is the exact bug class Section 9 exists to prevent: a scan that
        // only finished 2 of 5 candidates must never look identical to a full
        // 5/5 pass to the UI layer.
        if (snap.Status == OperationStatus.Complete) throw new InvalidOperationException("Must not report Complete with candidates still missing a terminal state.");
        if (tracker.IsGenuinelyComplete) throw new InvalidOperationException("IsGenuinelyComplete must be false for a partial run.");
    }

    private static void AccountingIsInconsistentOnDoubleTerminalWrite()
    {
        var tracker = new OperationTracker(1);
        var firstAccepted = tracker.MarkTerminal("0", TerminalState.Success);
        var secondAccepted = tracker.MarkTerminal("0", TerminalState.Failed);
        if (!firstAccepted) throw new InvalidOperationException("First terminal write for a candidate must be accepted.");
        if (secondAccepted) throw new InvalidOperationException("A second terminal write for the same candidate must be rejected, not silently overwritten.");
        var snap = tracker.Reconcile();
        if (snap.Status != OperationStatus.Complete) throw new InvalidOperationException("A rejected duplicate write should not corrupt an otherwise-complete reconcile.");
    }

    private static void AccountingNeverReportsCompleteEarly()
    {
        // Guards against a regression where Expected is computed from the
        // wrong collection (e.g. UI-filtered subset instead of the real
        // candidate list) and a scan looks "done" before it truly is.
        var tracker = new OperationTracker(100);
        for (var i = 0; i < 99; i++) tracker.MarkTerminal(i.ToString(), TerminalState.Success);
        if (tracker.IsGenuinelyComplete) throw new InvalidOperationException("99/100 terminal states must not be reported as complete.");
    }

    private static void RetirementRequiresMultipleFailuresNotOne()
    {
        var settings = new AppSettings();
        var svc = new RetirementService(settings);
        var dns = new DnsResolver { Ip = "203.0.113.5" };
        var now = DateTimeOffset.UtcNow;
        svc.RecordResult(dns, success: false, now);
        // Section 6: "هیچ resolver را صرفا به خاطر یک failure از بین نبر" —
        // one bad probe must never retire a resolver.
        if (dns.Retired) throw new InvalidOperationException("A single failure must not retire a resolver.");
    }

    private static void RetirementIsReversibleOnSuccess()
    {
        var settings = new AppSettings();
        var svc = new RetirementService(settings);
        var dns = new DnsResolver { Ip = "203.0.113.6" };
        var now = DateTimeOffset.UtcNow;
        svc.RecordResult(dns, false, now);
        svc.RecordResult(dns, false, now);
        svc.RecordResult(dns, false, now);
        if (!dns.Retired) throw new InvalidOperationException("Three consecutive failures should retire the resolver.");
        svc.RecordResult(dns, true, now.AddMinutes(1));
        if (dns.Retired) throw new InvalidOperationException("Retirement must be reversible: a later success must un-retire immediately (Section 74: 'Dead DNS retirement is reversible').");
    }

    private static void RetirementRecheckWindowIsRespected()
    {
        var settings = new AppSettings { DeadResolverRetestHours = 24 };
        var svc = new RetirementService(settings);
        var dns = new DnsResolver { Ip = "203.0.113.7" };
        var t0 = DateTimeOffset.UtcNow;
        svc.RecordResult(dns, false, t0);
        svc.RecordResult(dns, false, t0);
        svc.RecordResult(dns, false, t0);
        if (svc.IsDueForRecheck(dns, t0.AddHours(1))) throw new InvalidOperationException("Must not be due for recheck before the retest window elapses.");
        if (!svc.IsDueForRecheck(dns, t0.AddHours(25))) throw new InvalidOperationException("Must be due for recheck once the retest window has elapsed.");
        if (svc.IsEligibleForActivePool(dns, t0.AddHours(1))) throw new InvalidOperationException("A retired resolver not yet due for recheck must stay out of the active pool.");
        if (!svc.IsEligibleForActivePool(dns, t0.AddHours(25))) throw new InvalidOperationException("A retired resolver due for recheck must be eligible for the active pool again.");
    }

    private static void TrendRequiresConsecutiveDegradationNotOneSample()
    {
        var trend = new TrendTracker();
        trend.Add(20, 35); // establishes baseline, cannot itself be "degraded"
        trend.Add(20, 35);
        trend.Add(20, 35);
        // One single spike must not immediately count as sustained degradation.
        trend.Add(200, 35);
        if (trend.ConsecutiveDegraded > 1) throw new InvalidOperationException("A single spike must only count once, not compound instantly.");
        // But repeated bad samples must accumulate.
        trend.Add(200, 35);
        trend.Add(200, 35);
        if (trend.ConsecutiveDegraded < 2) throw new InvalidOperationException("Repeated degraded samples must accumulate ConsecutiveDegraded (Section 62: not a single-sample decision).");
    }

    private static void TrendResetsClearlyOnNewBaseline()
    {
        var trend = new TrendTracker();
        trend.Add(20, 35); trend.Add(200, 35); trend.Add(200, 35);
        trend.Reset();
        if (trend.Ewma is not null || trend.ConsecutiveDegraded != 0 || trend.SampleCount != 0)
            throw new InvalidOperationException("Reset() must fully clear trend state for a newly-adopted resolver.");
    }

    private static void ConfidenceRequiresBothSampleCountAndConsistency()
    {
        // Many samples but wildly inconsistent (high loss) must not be HIGH.
        var inconsistent = ConfidenceService.Classify(sampleCount: 50, lossPct: 40, jitterMs: 5, medianMs: 20);
        if (inconsistent == "HIGH") throw new InvalidOperationException("High sample count with high loss must not be classified HIGH confidence.");

        // Few samples, even if perfectly consistent, must not be HIGH.
        var tooFew = ConfidenceService.Classify(sampleCount: 2, lossPct: 0, jitterMs: 1, medianMs: 20);
        if (tooFew == "HIGH") throw new InvalidOperationException("Too few samples must not be classified HIGH confidence regardless of consistency.");

        var genuinelyHigh = ConfidenceService.Classify(sampleCount: 30, lossPct: 0, jitterMs: 2, medianMs: 25);
        if (genuinelyHigh != "HIGH") throw new InvalidOperationException("Many consistent samples should be classified HIGH confidence.");
    }

    private static void ConfidenceCapPreventsOneSampleFromOutrankingManyStableSamples()
    {
        // Section 60, literally: "a DNS with one excellent measurement must
        // not get ahead of a resolver with hundreds of stable measurements."
        var oneGreatSample = ConfidenceService.ApplyConfidenceCap(rawScore: 99, sampleCount: 1);
        var manyStableGoodSamples = ConfidenceService.ApplyConfidenceCap(rawScore: 80, sampleCount: 200);
        if (oneGreatSample >= manyStableGoodSamples)
            throw new InvalidOperationException("A one-sample reading must not be able to outrank a well-tested, stable resolver.");
        // The cap must still track sample count monotonically (more evidence -> higher ceiling).
        if (ConfidenceService.ApplyConfidenceCap(100, 1) > ConfidenceService.ApplyConfidenceCap(100, 5))
            throw new InvalidOperationException("Confidence cap must not decrease as sample count grows.");
    }

    private static void HistoryServiceRoundTripsSwitchEntriesAndStaysBounded()
    {
        var tempDir = Path.Combine(Path.GetTempPath(), "nimoxy-selftest-" + Guid.NewGuid().ToString("N"));
        try
        {
            var svc = new HistoryService(tempDir);
            var entry = new SwitchLogEntry(Guid.NewGuid(), DateTimeOffset.UtcNow, "1.1.1.1", "8.8.8.8", 80, 90, 30, 20, 0, 0, "self-test", true, false);
            svc.AppendSwitch(entry);
            var loaded = svc.LoadRecent();
            if (loaded.Count != 1) throw new InvalidOperationException("HistoryService must round-trip a single appended entry.");
            if (loaded[0].NewDns != "8.8.8.8" || loaded[0].OldDns != "1.1.1.1") throw new InvalidOperationException("HistoryService round-trip lost or corrupted field values.");

            // Section 63: the log must be bounded, not grow forever.
            for (var i = 0; i < 2100; i++)
                svc.AppendSwitch(entry with { OperationId = Guid.NewGuid() });
            var afterMany = svc.LoadRecent(max: 5000);
            if (afterMany.Count > 2000) throw new InvalidOperationException("HistoryService must stay bounded (Section 63: no unbounded growth) instead of logging every switch forever.");
        }
        finally
        {
            try { if (Directory.Exists(tempDir)) Directory.Delete(tempDir, recursive: true); } catch { }
        }
    }
}
