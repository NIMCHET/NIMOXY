using System.IO;
using System.Net.Http;
using System.Globalization;
using System.Net.Http.Json;
using System.Net;
using System.Text.Json;
using NIMOXY.Models;

namespace NIMOXY.Services;

public sealed class CatalogService
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(20) };
    private const string AllCsvUrl = "https://public-dns.info/nameservers.csv";
    private const string AllTxtUrl = "https://public-dns.info/nameservers.txt";
    private const string IpGeoUrl = "https://ipapi.co/json/";

    public async Task<List<DnsResolver>> LoadGlobalAsync(CancellationToken ct = default)
    {
        // Start with a built-in catalog so NIMOXY is never empty, even when the
        // network is offline or a public list is temporarily unavailable.
        var merged = Seeds().ToDictionary(x => x.Ip, StringComparer.OrdinalIgnoreCase);

        var sourceTasks = new[]
        {
            LoadPublicDnsCsvAsync(ct),
            LoadPublicDnsTxtAsync(ct),
            LoadDnsCryptJsonAsync(ct)
        };

        // FIX 3.8: this used to be a straight 2-tier fallback (remote -> the
        // ~50-entry built-in Seeds()), even though the UI's footer/stats text
        // already claimed a 3-tier "remote -> cached -> built-in" chain. There
        // was no disk cache anywhere in this file, so that claim was false.
        var anySourceSucceeded = false;
        try
        {
            var results = await Task.WhenAll(sourceTasks);
            foreach (var batch in results)
            {
                if (batch.Count > 0) anySourceSucceeded = true;
                foreach (var item in batch)
                {
                    if (!merged.TryGetValue(item.Ip, out var known))
                    {
                        merged[item.Ip] = item;
                        continue;
                    }

                    // Prefer the richer metadata from the public catalogue, but keep
                    // our curated provider identity for well-known anycast resolvers.
                    if (!string.IsNullOrWhiteSpace(item.Country)) known.Country = item.Country;
                    if (!string.IsNullOrWhiteSpace(item.Provider) && known.Provider == "Public Resolver") known.Provider = item.Provider;
                    known.Trusted |= item.Trusted;
                    known.DnsSec |= item.DnsSec;
                    known.Icon = string.IsNullOrWhiteSpace(known.Icon) ? item.Icon : known.Icon;
                }
            }
        }
        catch (OperationCanceledException) { throw; } // FIX 3.7: a real cancellation must surface as CANCELLED, not as "used built-in list"
        catch
        {
            // Individual source failures are intentionally non-fatal. The merged
            // built-in list remains usable and can be benchmarked immediately.
        }

        if (anySourceSucceeded)
        {
            // At least one remote source answered this run — remember this
            // merged catalog on disk so a future offline run has something
            // richer than the built-in list to fall back to.
            TryWriteDiskCache(merged.Values);
        }
        else
        {
            // No remote source answered at all this run (offline, DNS down,
            // firewall, etc). Before settling for the tiny built-in list,
            // try the last catalog we successfully persisted.
            foreach (var cached in TryReadDiskCache())
                merged.TryAdd(cached.Ip, cached);
        }

        var list = merged.Values.ToList();
        if (list.Count == 0) throw new InvalidDataException("No public DNS resolvers are available.");
        return list;
    }

    private static string CacheFilePath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NIMOXY", "catalog-cache.json");

    private static void TryWriteDiskCache(IEnumerable<DnsResolver> resolvers)
    {
        try
        {
            var dir = Path.GetDirectoryName(CacheFilePath)!;
            Directory.CreateDirectory(dir);
            // Cache only catalog identity/metadata, not live benchmark results —
            // a cached "1.1.1.1 was fast yesterday" must never be presented as
            // this run's fresh measurement (Section 60).
            var snapshot = resolvers.Select(r => new DnsResolver
            {
                Ip = r.Ip, Provider = r.Provider, Country = r.Country, Trusted = r.Trusted,
                DnsSec = r.DnsSec, Icon = r.Icon, Source = "Cached"
            }).ToList();
            var tmp = CacheFilePath + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(snapshot));
            File.Move(tmp, CacheFilePath, overwrite: true);
        }
        catch
        {
            // Best-effort: a failed cache write must never affect the catalog
            // NIMOXY already successfully loaded this run.
        }
    }

    private static List<DnsResolver> TryReadDiskCache()
    {
        try
        {
            if (!File.Exists(CacheFilePath)) return new();
            var json = File.ReadAllText(CacheFilePath);
            return JsonSerializer.Deserialize<List<DnsResolver>>(json) ?? new();
        }
        catch { return new(); }
    }

    private async Task<List<DnsResolver>> LoadPublicDnsCsvAsync(CancellationToken ct)
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, AllCsvUrl);
            req.Headers.UserAgent.ParseAdd("NIMOXY/3.0.1 (+global DNS catalog)");
            using var resp = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
            resp.EnsureSuccessStatusCode();
            var text = await resp.Content.ReadAsStringAsync(ct);
            return ParseCsv(text);
        }
        catch (OperationCanceledException) { throw; } // FIX 3.7: cancellation must propagate, not look like "source had nothing"
        catch { return new(); }
    }

    private async Task<List<DnsResolver>> LoadPublicDnsTxtAsync(CancellationToken ct)
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, AllTxtUrl);
            req.Headers.UserAgent.ParseAdd("NIMOXY/3.0.1 (+global DNS catalog)");
            using var resp = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
            resp.EnsureSuccessStatusCode();
            var txt = await resp.Content.ReadAsStringAsync(ct);
            return txt.Split(new[] { '\r', '\n', ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .Where(IsPublicAddress)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Select(ip => NormalizeIp(ip))
                .Select(ip => new DnsResolver { Ip = ip, Provider = "Public Resolver", Icon = ResolverIcon("Public Resolver", "", ip) })
                .DistinctBy(x => x.Ip, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }
        catch (OperationCanceledException) { throw; } // FIX 3.7: cancellation must propagate, not look like "source had nothing"
        catch { return new(); }
    }

    private async Task<List<DnsResolver>> LoadDnsCryptJsonAsync(CancellationToken ct)
    {
        // Public, machine-readable resolver catalog containing many additional
        // DoH/DNSCrypt resolvers. Import both public IPv4 and IPv6 endpoints.
        // The benchmark engine supports both families; Apply remains conservative for Windows.
        const string url = "https://raw.githubusercontent.com/CarloWood/dnscrypt-resolvers/master/public-resolvers.json";
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, url);
            req.Headers.UserAgent.ParseAdd("NIMOXY/3.0.1 (+global DNS catalog)");
            using var resp = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
            resp.EnsureSuccessStatusCode();
            await using var stream = await resp.Content.ReadAsStreamAsync(ct);
            using var doc = await JsonDocument.ParseAsync(stream, cancellationToken: ct);
            var result = new List<DnsResolver>();
            foreach (var node in doc.RootElement.EnumerateArray())
            {
                var name = node.TryGetProperty("name", out var n) ? n.GetString() ?? "" : "";
                var info = node.TryGetProperty("info", out var inf) && inf.ValueKind == JsonValueKind.Array
                    ? string.Join(" ", inf.EnumerateArray().Select(x => x.GetString() ?? "")) : "";
                var dnssec = (info + " " + name).Contains("DNSSEC", StringComparison.OrdinalIgnoreCase);
                if (!node.TryGetProperty("sdns", out var sdns) || sdns.ValueKind != JsonValueKind.Array) continue;
                foreach (var entry in sdns.EnumerateArray())
                {
                    if (!entry.TryGetProperty("IP", out var ipNode)) continue;
                    var ip = ipNode.GetString();
                    if (!IsPublicAddress(ip)) continue;
                    ip = NormalizeIp(ip!);
                    result.Add(new DnsResolver
                    {
                        Ip = ip!,
                        Provider = string.IsNullOrWhiteSpace(name) ? "DNSCrypt / DoH" : name,
                        Trusted = dnssec,
                        DnsSec = dnssec,
                        Icon = ResolverIcon(name, "", ip!)
                    });
                }
            }
            return result.DistinctBy(x => x.Ip, StringComparer.OrdinalIgnoreCase).ToList();
        }
        catch (OperationCanceledException) { throw; } // FIX 3.7: cancellation must propagate, not look like "source had nothing"
        catch { return new(); }
    }

    public async Task<List<DnsResolver>> LoadLocalAsync(CancellationToken ct = default)
    {
        var geo = await GetClientGeoAsync(ct);
        if (geo is null || string.IsNullOrWhiteSpace(geo.Country)) return await LoadGlobalAsync(ct);

        var countryUrl = $"https://public-dns.info/nameserver/{geo.Country.ToLowerInvariant()}.txt";
        try
        {
            var text = await Http.GetStringAsync(countryUrl, ct);
            var ips = text.Split(new[] { '\r', '\n', ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim())
                .Where(IsPublicAddress)
                .Select(NormalizeIp)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Select(ip => new DnsResolver { Ip = ip, Country = geo.Country.ToUpperInvariant(), Provider = "Public Resolver", Icon = ResolverIcon("Public Resolver", geo.Country, ip) })
                .ToList();
            if (ips.Count > 0)
            {
                MergeKnown(ips);
                var located = await LocateResolversAsync(ips.Select(x => x.Ip), ct);
                return ips.OrderBy(x => located.TryGetValue(x.Ip, out var point) ? HaversineKm(geo.Lat, geo.Lon, point.Lat, point.Lon) : double.MaxValue)
                    .ToList();
            }
        }
        catch { }

        return (await LoadGlobalAsync(ct)).Where(x => x.Country.Equals(geo.Country, StringComparison.OrdinalIgnoreCase)).ToList();
    }

    public async Task<string?> GetClientCountryAsync(CancellationToken ct = default)
    {
        try
        {
            await using var stream = await Http.GetStreamAsync(IpGeoUrl, ct);
            using var doc = await JsonDocument.ParseAsync(stream, cancellationToken: ct);
            if (doc.RootElement.TryGetProperty("country", out var c)) return c.GetString();
        }
        catch { }
        return null;
    }

    private static List<DnsResolver> ParseCsv(string text)
    {
        var lines = text.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        if (lines.Length == 0) return Seeds();
        var header = SplitCsv(lines[0]);
        var looksLikeHeader = header.Any(x => x.Contains("ip", StringComparison.OrdinalIgnoreCase) || x.Contains("country", StringComparison.OrdinalIgnoreCase) || x.Contains("reliability", StringComparison.OrdinalIgnoreCase));
        var ipIdx = looksLikeHeader ? Find(header, "ip", "address", "ip_address") : 0;
        var countryIdx = Find(header, "country", "country_code", "countrycode", "country_id");
        var providerIdx = Find(header, "org", "organization", "provider", "as_name", "asn_name", "as_org", "as_organization");
        var reliabilityIdx = Find(header, "reliability", "reliability_score");
        var dnssecIdx = Find(header, "dnssec", "dns_sec", "valid_dnssec");

        var list = new List<DnsResolver>(Math.Max(1024, lines.Length - 1));
        foreach (var raw in (looksLikeHeader ? lines.Skip(1) : lines))
        {
            var cols = SplitCsv(raw);
            if (ipIdx < 0 || ipIdx >= cols.Count) continue;
            var ip = cols[ipIdx].Trim();
            if (!IsPublicAddress(ip)) continue;
            ip = NormalizeIp(ip);
            var country = countryIdx >= 0 && countryIdx < cols.Count ? cols[countryIdx].Trim() : "";
            var provider = providerIdx >= 0 && providerIdx < cols.Count ? cols[providerIdx].Trim() : "Public Resolver";
            var reliability = ParsePercent(reliabilityIdx >= 0 && reliabilityIdx < cols.Count ? cols[reliabilityIdx] : "");
            var dnssecRaw = dnssecIdx >= 0 && dnssecIdx < cols.Count ? cols[dnssecIdx].Trim() : "";
            var dnssec = dnssecRaw.Equals("true", StringComparison.OrdinalIgnoreCase) ||
                         dnssecRaw.Equals("1", StringComparison.OrdinalIgnoreCase) ||
                         dnssecRaw.Contains("dnssec", StringComparison.OrdinalIgnoreCase);
            list.Add(new DnsResolver {
                Ip = ip,
                Country = country,
                Provider = string.IsNullOrWhiteSpace(provider) ? "Public Resolver" : provider,
                Trusted = reliability >= 90,
                DnsSec = dnssec,
                Icon = ResolverIcon(provider, country, ip)
            });
        }
        return list.DistinctBy(x => x.Ip, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static List<DnsResolver> MergeKnown(List<DnsResolver> list)
    {
        var known = Seeds().ToDictionary(x => x.Ip, StringComparer.OrdinalIgnoreCase);
        foreach (var item in list)
            if (known.TryGetValue(item.Ip, out var k))
            {
                item.Provider = k.Provider;
                item.Country = string.IsNullOrWhiteSpace(item.Country) ? k.Country : item.Country;
                item.Trusted = k.Trusted;
                item.DnsSec = k.DnsSec;
                item.Icon = k.Icon;
            }
        return list;
    }

    // FIX 3.6: dedup across the built-in seeds and the three remote sources
    // used to compare raw, un-normalized IP strings with OrdinalIgnoreCase.
    // Two textually different representations of the same address (e.g. an
    // IPv6 address in compressed vs. expanded form, or with different hex
    // case) were treated as two distinct resolvers. Every entry-point below
    // that turns a raw string into a DnsResolver now stores IPAddress.Parse(
    // value).ToString() instead of the raw text, so identity comparisons
    // and Dictionary/DistinctBy keys are all comparing the same canonical form.
    private static string NormalizeIp(string value) => IPAddress.TryParse(value.Trim(), out var parsed) ? parsed.ToString() : value.Trim();

    private static bool IsPublicAddress(string? value)
    {
        if (!IPAddress.TryParse(value?.Trim(), out var ip)) return false;

        if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
        {
            var b = ip.GetAddressBytes();
            // FIX 3.5: the original check missed 169.254.0.0/16 (APIPA /
            // link-local), 100.64.0.0/10 (CGNAT), and the three TEST-NET
            // ranges reserved by RFC 5737 for documentation — none of these
            // are real public Internet resolvers and Section 5 explicitly
            // requires filtering link-local/reserved addresses out of the
            // public pool.
            var isLinkLocal = b[0] == 169 && b[1] == 254;
            var isCgnat = b[0] == 100 && b[1] >= 64 && b[1] <= 127;
            var isTestNet = (b[0] == 192 && b[1] == 0 && b[2] == 2) ||
                             (b[0] == 198 && b[1] == 51 && b[2] == 100) ||
                             (b[0] == 203 && b[1] == 0 && b[2] == 113);
            return !(b[0] == 10 || b[0] == 127 || b[0] == 0 ||
                     (b[0] == 172 && b[1] >= 16 && b[1] <= 31) ||
                     (b[0] == 192 && b[1] == 168) ||
                     (b[0] >= 224) ||
                     isLinkLocal || isCgnat || isTestNet);
        }

        if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
        {
            // Keep global IPv6 resolvers; reject loopback, unspecified, multicast,
            // link-local and unique-local addresses that are not public Internet resolvers.
            return !IPAddress.IsLoopback(ip) && !ip.IsIPv4MappedToIPv6 &&
                   !ip.Equals(IPAddress.IPv6Any) &&
                   !ip.IsIPv6LinkLocal && !ip.IsIPv6SiteLocal && !ip.IsIPv6Multicast &&
                   (ip.GetAddressBytes()[0] & 0xFE) != 0xFC;
        }

        return false;
    }

    private static List<string> SplitCsv(string line)
    {
        var result = new List<string>();
        var sb = new System.Text.StringBuilder();
        var quoted = false;
        foreach (var ch in line)
        {
            if (ch == '"') quoted = !quoted;
            else if (ch == ',' && !quoted) { result.Add(sb.ToString().Trim('"')); sb.Clear(); }
            else sb.Append(ch);
        }
        result.Add(sb.ToString().Trim('"'));
        return result;
    }

    private static int Find(IReadOnlyList<string> header, params string[] names)
    {
        for (var i = 0; i < header.Count; i++)
            if (names.Contains(header[i].Trim().TrimStart('\uFEFF').ToLowerInvariant(), StringComparer.OrdinalIgnoreCase)) return i;
        return -1;
    }

    private static double ParsePercent(string raw)
    {
        var s = raw.Replace("%", "", StringComparison.Ordinal).Trim();
        if (!double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var v)) return 0;
        // public-dns.info uses a 0..1 reliability score in its CSV; tolerate
        // 0..100 and percentage-formatted variants as well.
        return v <= 1 ? v * 100 : v;
    }


    private sealed record GeoPoint(string Country, double Lat, double Lon);

    private sealed record ResolverPoint(double Lat, double Lon);

    private async Task<GeoPoint?> GetClientGeoAsync(CancellationToken ct)
    {
        try
        {
            await using var stream = await Http.GetStreamAsync(IpGeoUrl, ct);
            using var doc = await JsonDocument.ParseAsync(stream, cancellationToken: ct);
            var root = doc.RootElement;
            if (root.TryGetProperty("country_code", out var c) && root.TryGetProperty("latitude", out var lat) && root.TryGetProperty("longitude", out var lon) &&
                lat.TryGetDouble(out var la) && lon.TryGetDouble(out var lo))
                return new GeoPoint(c.GetString() ?? "", la, lo);
        }
        catch { }
        return null;
    }

    private async Task<Dictionary<string, ResolverPoint>> LocateResolversAsync(IEnumerable<string> ips, CancellationToken ct)
    {
        var all = ips.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var result = new Dictionary<string, ResolverPoint>(StringComparer.OrdinalIgnoreCase);
        foreach (var chunk in all.Chunk(100))
        {
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Post, "http://ip-api.com/batch?fields=status,message,query,lat,lon");
                req.Content = JsonContent.Create(chunk.Select(x => new { query = x }).ToArray());
                using var resp = await Http.SendAsync(req, ct);
                resp.EnsureSuccessStatusCode();
                using var doc = await JsonDocument.ParseAsync(await resp.Content.ReadAsStreamAsync(ct), cancellationToken: ct);
                foreach (var item in doc.RootElement.EnumerateArray())
                {
                    if (!item.TryGetProperty("status", out var st) || st.GetString() != "success") continue;
                    if (!item.TryGetProperty("query", out var q) || !item.TryGetProperty("lat", out var lat) || !item.TryGetProperty("lon", out var lon)) continue;
                    if (lat.TryGetDouble(out var la) && lon.TryGetDouble(out var lo)) result[q.GetString() ?? ""] = new ResolverPoint(la, lo);
                }
            }
            catch { }
        }
        return result;
    }

    private static double HaversineKm(double lat1, double lon1, double lat2, double lon2)
    {
        const double r = 6371.0;
        double ToRad(double x) => x * Math.PI / 180.0;
        var dLat = ToRad(lat2 - lat1);
        var dLon = ToRad(lon2 - lon1);
        var a = Math.Pow(Math.Sin(dLat / 2), 2) + Math.Cos(ToRad(lat1)) * Math.Cos(ToRad(lat2)) * Math.Pow(Math.Sin(dLon / 2), 2);
        return 2 * r * Math.Asin(Math.Min(1, Math.Sqrt(a)));
    }

    private static string ResolverIcon(string provider, string country, string ip)
    {
        // Lightweight, deterministic frog badges: no remote icon downloads and no
        // per-row network work. Different resolvers/providers get varied frog badges.
        var key = $"{provider}|{country}|{ip}".Trim().ToUpperInvariant();
        if (key.Length == 0) return "🐸✨";
        var frogs = new[] { "🐸✨", "🐸👑", "🐸⚡", "🐸🎧", "🐸🕶️", "🐸🚀", "🐸💎", "🐸🍀", "🐸🌙", "🐸🔥" };
        var hash = 17;
        foreach (var c in key) hash = unchecked(hash * 31 + c);
        return frogs[Math.Abs(hash % frogs.Length)];
    }

    private static List<DnsResolver> Seeds() => new()
    {
        // Major global anycast / public resolvers.
        new() { Ip="1.1.1.1", Provider="Cloudflare", Country="US", Trusted=true, DnsSec=true, Icon="☁️" },
        new() { Ip="1.0.0.1", Provider="Cloudflare", Country="US", Trusted=true, DnsSec=true, Icon="☁️" },
        new() { Ip="8.8.8.8", Provider="Google", Country="US", Trusted=true, DnsSec=true, Icon="🔎" },
        new() { Ip="8.8.4.4", Provider="Google", Country="US", Trusted=true, DnsSec=true, Icon="🔎" },
        new() { Ip="9.9.9.9", Provider="Quad9 Secure", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="149.112.112.112", Provider="Quad9 Secure", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="9.9.9.10", Provider="Quad9 Unsecured", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="149.112.112.10", Provider="Quad9 Unsecured", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="9.9.9.11", Provider="Quad9 Secure ECS", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="149.112.112.11", Provider="Quad9 Secure ECS", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="9.9.9.12", Provider="Quad9 Unsecured ECS", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="149.112.112.12", Provider="Quad9 Unsecured ECS", Country="CH", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="208.67.222.222", Provider="OpenDNS", Country="US", Trusted=true, DnsSec=true, Icon="🌐" },
        new() { Ip="208.67.220.220", Provider="OpenDNS", Country="US", Trusted=true, DnsSec=true, Icon="🌐" },
        new() { Ip="94.140.14.14", Provider="AdGuard DNS", Country="Global", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="94.140.15.15", Provider="AdGuard DNS", Country="Global", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="94.140.14.140", Provider="AdGuard DNS Non-filtering", Country="Global", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="94.140.14.141", Provider="AdGuard DNS Non-filtering", Country="Global", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="94.140.14.15", Provider="AdGuard Family", Country="Global", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="94.140.15.16", Provider="AdGuard Family", Country="Global", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="76.76.2.0", Provider="Control D", Country="US", Trusted=true, DnsSec=true, Icon="🎛️" },
        new() { Ip="76.76.10.0", Provider="Control D", Country="US", Trusted=true, DnsSec=true, Icon="🎛️" },
        new() { Ip="76.76.19.19", Provider="Control D", Country="US", Trusted=true, DnsSec=true, Icon="🎮" },
        new() { Ip="76.223.122.150", Provider="Control D", Country="US", Trusted=true, DnsSec=true, Icon="🎮" },
        new() { Ip="84.200.69.80", Provider="DNS.WATCH", Country="DE", Trusted=true, DnsSec=true, Icon="⌚" },
        new() { Ip="84.200.70.40", Provider="DNS.WATCH", Country="DE", Trusted=true, DnsSec=true, Icon="⌚" },
        new() { Ip="64.6.64.6", Provider="Verisign", Country="US", Trusted=true, DnsSec=true, Icon="✅" },
        new() { Ip="64.6.65.6", Provider="Verisign", Country="US", Trusted=true, DnsSec=true, Icon="✅" },
        new() { Ip="1.1.1.2", Provider="Cloudflare Malware", Country="US", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="1.0.0.2", Provider="Cloudflare Malware", Country="US", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="1.1.1.3", Provider="Cloudflare Family", Country="US", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="1.0.0.3", Provider="Cloudflare Family", Country="US", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="185.228.168.9", Provider="CleanBrowsing Security", Country="US", Trusted=true, DnsSec=true, Icon="🧹" },
        new() { Ip="185.228.169.9", Provider="CleanBrowsing Security", Country="US", Trusted=true, DnsSec=true, Icon="🧹" },
        new() { Ip="185.228.168.10", Provider="CleanBrowsing Adult", Country="US", Trusted=true, DnsSec=true, Icon="🧹" },
        new() { Ip="185.228.169.11", Provider="CleanBrowsing Family", Country="US", Trusted=true, DnsSec=true, Icon="🧹" },
        new() { Ip="76.76.2.1", Provider="Alternate DNS", Country="US", Trusted=true, DnsSec=true, Icon="🔁" },
        new() { Ip="76.76.10.1", Provider="Alternate DNS", Country="US", Trusted=true, DnsSec=true, Icon="🔁" },
        new() { Ip="8.26.56.26", Provider="Comodo Secure DNS", Country="US", Trusted=true, Icon="🔐" },
        new() { Ip="8.20.247.20", Provider="Comodo Secure DNS", Country="US", Trusted=true, Icon="🔐" },
        new() { Ip="156.154.70.1", Provider="UltraRecursive / Neustar", Country="US", Trusted=true, DnsSec=true, Icon="🛰️" },
        new() { Ip="156.154.71.1", Provider="UltraRecursive / Neustar", Country="US", Trusted=true, DnsSec=true, Icon="🛰️" },
        new() { Ip="156.154.70.2", Provider="UltraRecursive Family", Country="US", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="156.154.71.2", Provider="UltraRecursive Family", Country="US", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="208.67.222.123", Provider="OpenDNS FamilyShield", Country="US", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="208.67.220.123", Provider="OpenDNS FamilyShield", Country="US", Trusted=true, DnsSec=true, Icon="👨‍👩‍👧" },
        new() { Ip="216.146.35.35", Provider="Dyn", Country="US", Trusted=true, DnsSec=true, Icon="⚙️" },
        new() { Ip="216.146.36.36", Provider="Dyn", Country="US", Trusted=true, DnsSec=true, Icon="⚙️" },
        new() { Ip="77.88.8.8", Provider="Yandex DNS", Country="RU", Trusted=true, DnsSec=true, Icon="🟣" },
        new() { Ip="77.88.8.1", Provider="Yandex DNS", Country="RU", Trusted=true, DnsSec=true, Icon="🟣" },
        new() { Ip="77.88.8.88", Provider="Yandex DNS Family", Country="RU", Trusted=true, DnsSec=true, Icon="🟣" },
        new() { Ip="77.88.8.2", Provider="Yandex DNS Family", Country="RU", Trusted=true, DnsSec=true, Icon="🟣" },
        new() { Ip="195.46.39.39", Provider="SafeServe", Country="DE", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="195.46.39.40", Provider="SafeServe", Country="DE", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="185.121.177.177", Provider="AdGuard / Other", Country="NL", Trusted=true, DnsSec=true, Icon="🛡️" },
        new() { Ip="185.121.177.53", Provider="AdGuard / Other", Country="NL", Trusted=true, DnsSec=true, Icon="🛡️" }
    };
}
