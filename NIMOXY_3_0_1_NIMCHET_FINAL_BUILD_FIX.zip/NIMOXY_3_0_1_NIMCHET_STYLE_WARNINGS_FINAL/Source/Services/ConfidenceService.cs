namespace NIMOXY.Services;

/// <summary>
/// Implements master-prompt Section 61 (Confidence): a HIGH/MEDIUM/LOW label
/// derived only from sample count and measurement consistency (loss and
/// relative jitter), never a random or cosmetic label. Also backs Section
/// 60's rule that "a DNS with one great measurement must not outrank a
/// resolver with hundreds of stable measurements" via ApplyConfidenceCap.
/// </summary>
public static class ConfidenceService
{
    public static string Classify(int sampleCount, double lossPct, double jitterMs, double medianMs)
    {
        if (sampleCount <= 0) return "LOW";

        // Consistency: jitter as a fraction of the median. A resolver whose
        // jitter is a large share of its own latency is not "consistent",
        // however many samples it has.
        var relativeJitter = medianMs > 0 && !double.IsNaN(medianMs) ? jitterMs / medianMs : 1.0;
        var consistent = lossPct <= 5 && relativeJitter <= 0.35;
        var fairlyConsistent = lossPct <= 20 && relativeJitter <= 0.75;

        if (sampleCount >= 20 && consistent) return "HIGH";
        if (sampleCount >= 6 && fairlyConsistent) return "MEDIUM";
        return "LOW";
    }

    /// <summary>
    /// Section 60, enforced as a hard cap rather than a soft multiplier: a
    /// resolver with very few samples cannot score above this ceiling, no
    /// matter how good those few samples looked. This is what actually makes
    /// "one great measurement must not outrank hundreds of stable ones" true
    /// — a small multiplicative nudge alone is not enough to guarantee it
    /// whenever the raw score gap is larger than the nudge.
    /// </summary>
    public static double ApplyConfidenceCap(double rawScore, int sampleCount)
    {
        var cap = sampleCount switch
        {
            <= 1 => 60.0,
            <= 5 => 75.0,
            <= 19 => 90.0,
            _ => 100.0
        };
        return Math.Min(rawScore, cap);
    }
}
