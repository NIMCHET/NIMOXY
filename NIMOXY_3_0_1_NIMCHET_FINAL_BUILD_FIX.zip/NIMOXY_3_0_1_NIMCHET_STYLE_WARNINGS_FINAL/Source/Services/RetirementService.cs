using NIMOXY.Models;

namespace NIMOXY.Services;

/// <summary>
/// Implements master-prompt Section 5's retirement rule:
///   - a resolver that keeps failing is TEMPORARILY retired from the active
///     pool (roughly 24h), never permanently deleted;
///   - a retired resolver is rechecked later so a false negative can recover;
///   - only a single probe failure must never retire anything by itself.
/// This is intentionally a tiny, pure, testable piece of logic so the
/// retire/recheck rule lives in exactly one place instead of being
/// reimplemented (and inevitably drifting) across the catalog, scout and
/// Auto Pilot code paths.
/// </summary>
public sealed class RetirementService
{
    private readonly AppSettings settings;
    public RetirementService(AppSettings settings) => this.settings = settings;

    // A single bad probe is not evidence of a dead resolver (Section 6:
    // "هیچ resolver را صرفا به خاطر یک failure از بین نبر"). Require a small
    // streak before even starting the retirement clock.
    private const int MinConsecutiveFailuresBeforeRetirement = 3;

    /// <summary>Call after every probe/benchmark attempt for a resolver.</summary>
    public void RecordResult(DnsResolver resolver, bool success, DateTimeOffset now)
    {
        resolver.LastChecked = now;
        if (success)
        {
            resolver.ConsecutiveFailures = 0;
            resolver.LastSuccessful = now;
            // A resolver that answers again is un-retired immediately — the
            // failure streak that caused retirement is gone, so there is no
            // reason to make it wait out the rest of the recheck window.
            if (resolver.Retired) { resolver.Retired = false; resolver.RetiredAt = null; }
            return;
        }

        resolver.ConsecutiveFailures++;
        if (!resolver.Retired && resolver.ConsecutiveFailures >= MinConsecutiveFailuresBeforeRetirement)
        {
            resolver.Retired = true;
            resolver.RetiredAt = now;
            resolver.Status = "Retired";
        }
    }

    /// <summary>
    /// A retired resolver becomes eligible for recheck once the retest
    /// window has elapsed. Callers should re-probe it and call
    /// RecordResult() again rather than assuming it is dead forever.
    /// </summary>
    public bool IsDueForRecheck(DnsResolver resolver, DateTimeOffset now) =>
        resolver.Retired && resolver.RetiredAt is { } retiredAt &&
        now - retiredAt >= TimeSpan.FromHours(Math.Max(1, settings.DeadResolverRetestHours));

    /// <summary>Active pool = not retired, or retired but due for recheck right now.</summary>
    public bool IsEligibleForActivePool(DnsResolver resolver, DateTimeOffset now) =>
        !resolver.Retired || IsDueForRecheck(resolver, now);
}
