using Microsoft.Win32;

namespace NIMOXY.Services;

public static class AppStartupService
{
    private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "NIMOXY";
    public static bool IsEnabled
    {
        get
        {
            try { using var k = Registry.CurrentUser.OpenSubKey(RunKey, false); return k?.GetValue(ValueName) is string; }
            catch { return false; }
        }
    }
    public static bool SetEnabled(bool enabled)
    {
        try
        {
            using var k = Registry.CurrentUser.OpenSubKey(RunKey, true) ?? Registry.CurrentUser.CreateSubKey(RunKey);
            if (k is null) return false;
            if (enabled) { var path = Environment.ProcessPath ?? "NIMOXY.exe"; k.SetValue(ValueName, $"\"{path}\""); }
            else k.DeleteValue(ValueName, false);
            return true;
        }
        catch { return false; }
    }
}
