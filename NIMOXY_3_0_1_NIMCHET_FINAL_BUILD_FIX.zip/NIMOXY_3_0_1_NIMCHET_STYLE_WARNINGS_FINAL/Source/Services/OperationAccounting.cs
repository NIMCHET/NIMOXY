using System.Collections.Concurrent;

namespace NIMOXY.Services;

/// <summary>
/// Implements master-prompt Section 9 (Critical Test Completion Integrity).
/// Every global operation (Benchmark ALL, Auto Pilot candidate search, etc.)
/// must go through this tracker. Nothing in the UI is allowed to say
/// "COMPLETE" unless Reconcile() confirms every expected candidate reached
/// exactly one terminal state.
/// </summary>
public enum TerminalState { Success, Failed, Timeout, Cancelled, Skipped }

public enum OperationStatus { Running, Complete, Incomplete, Inconsistent, Cancelled }

public sealed record OperationSnapshot(
    Guid OperationId,
    int Expected,
    int Started,
    int Completed,
    int Success,
    int Failed,
    int TimedOut,
    int Cancelled,
    int Skipped,
    TimeSpan Duration,
    OperationStatus Status);

public sealed class OperationTracker
{
    public Guid OperationId { get; } = Guid.NewGuid();
    public int Expected { get; }

    private int started;
    private int success;
    private int failed;
    private int timedOut;
    private int cancelled;
    private int skipped;

    // Every candidate key must land here exactly once. A second terminal
    // write for the same key, or a missing one at reconcile time, is what
    // Section 9 calls out as an integrity violation.
    private readonly ConcurrentDictionary<string, TerminalState> terminal = new(StringComparer.OrdinalIgnoreCase);
    private readonly System.Diagnostics.Stopwatch clock = System.Diagnostics.Stopwatch.StartNew();
    private volatile bool operatorCancelled;

    public OperationTracker(int expected)
    {
        if (expected < 0) throw new ArgumentOutOfRangeException(nameof(expected));
        Expected = expected;
    }

    public void MarkStarted(string candidateKey) => Interlocked.Increment(ref started);

    public void MarkOperatorCancelled() => operatorCancelled = true;

    /// <summary>
    /// Records the single terminal outcome for one candidate. Returns false
    /// (and does not double-count) if this candidate already has a terminal
    /// state — that would itself be an accounting bug worth surfacing rather
    /// than silently overwriting.
    /// </summary>
    public bool MarkTerminal(string candidateKey, TerminalState state)
    {
        if (!terminal.TryAdd(candidateKey, state)) return false;
        switch (state)
        {
            case TerminalState.Success: Interlocked.Increment(ref success); break;
            case TerminalState.Failed: Interlocked.Increment(ref failed); break;
            case TerminalState.Timeout: Interlocked.Increment(ref timedOut); break;
            case TerminalState.Cancelled: Interlocked.Increment(ref cancelled); break;
            case TerminalState.Skipped: Interlocked.Increment(ref skipped); break;
        }
        return true;
    }

    /// <summary>
    /// The only place allowed to decide whether the operation may be shown
    /// as COMPLETE. Reconciles Expected against Started and against the sum
    /// of terminal states. Anything that doesn't add up returns INCOMPLETE
    /// or INCONSISTENT — never a fake 100%.
    /// </summary>
    public OperationSnapshot Reconcile()
    {
        var completed = terminal.Count;
        var sumTerminal = success + failed + timedOut + cancelled + skipped;

        OperationStatus status;
        if (operatorCancelled && completed < Expected)
        {
            status = OperationStatus.Cancelled;
        }
        else if (sumTerminal != completed)
        {
            // A candidate got counted into more than one bucket, or a bucket
            // increment happened without a corresponding terminal write.
            status = OperationStatus.Inconsistent;
        }
        else if (completed != Expected || started < completed)
        {
            status = OperationStatus.Incomplete;
        }
        else
        {
            status = OperationStatus.Complete;
        }

        return new OperationSnapshot(
            OperationId, Expected, started, completed,
            success, failed, timedOut, cancelled, skipped,
            clock.Elapsed, status);
    }

    /// <summary>True only when Reconcile() would say COMPLETE. UI code should
    /// call this — never assume completion from a progress bar reaching 100.</summary>
    public bool IsGenuinelyComplete => Reconcile().Status == OperationStatus.Complete;
}
