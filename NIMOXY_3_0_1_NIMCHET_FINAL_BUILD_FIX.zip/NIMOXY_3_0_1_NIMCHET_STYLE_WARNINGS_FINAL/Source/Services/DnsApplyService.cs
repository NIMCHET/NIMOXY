using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Security.Principal;
using System.Text;

namespace NIMOXY.Services;

public sealed record DnsApplyResult(bool Success, string Message, string InterfaceName, IReadOnlyList<string> AppliedServers, IReadOnlyList<string> ActualServers);

// FIX 4.3: a plain bool used to be the only signal a switch attempt returned,
// so callers (AutoPilotService) had no way to know whether a failed switch's
// automatic rollback actually happened, let alone whether it was verified —
// they just always displayed "Previous configuration restored", proven or
// not. This record carries the real outcome so the UI can say something true.
public sealed record SwitchOutcome(bool Verified, bool RolledBack, bool RollbackVerified);

public sealed class DnsApplyService
{
    public bool IsAdministrator => OperatingSystem.IsWindows() && new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);

    public IReadOnlyList<string> GetActiveInterfaces() => NetworkInterface.GetAllNetworkInterfaces()
        .Where(n => n.OperationalStatus == OperationalStatus.Up &&
                    (n.NetworkInterfaceType == NetworkInterfaceType.Ethernet || n.NetworkInterfaceType == NetworkInterfaceType.Wireless80211))
        .Where(n => !n.Name.Contains("VPN", StringComparison.OrdinalIgnoreCase) && !n.Description.Contains("VPN", StringComparison.OrdinalIgnoreCase))
        .OrderBy(n => n.NetworkInterfaceType == NetworkInterfaceType.Ethernet ? 0 : 1)
        .Select(n => n.Name).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

    public async Task<IReadOnlyList<string>> GetCurrentDnsAsync(string interfaceName, System.Net.Sockets.AddressFamily family = System.Net.Sockets.AddressFamily.InterNetwork)
    {
        // FIX 4.1: netsh/PowerShell are now told which IP version to read back
        // (ipv4 vs ipv6) via the family parameter, instead of always reading
        // ipv4. Existing call sites that don't care keep working unchanged
        // because IPv4 remains the default.
        var ipVersion = family == System.Net.Sockets.AddressFamily.InterNetworkV6 ? "ipv6" : "ipv4";
        var r = await RunAsync("netsh.exe", "interface", ipVersion, "show", "dnsservers", $"name={interfaceName}");
        var parsed = ParseIpList(r.Output, family);
        if (r.ExitCode == 0 && parsed.Count > 0) return parsed;

        // Fallback for Windows builds where netsh output/adapter naming behaves
        // differently. The adapter name is passed through an environment variable,
        // never interpolated into executable code.
        var afArg = family == System.Net.Sockets.AddressFamily.InterNetworkV6 ? "IPv6" : "IPv4";
        var ps = await RunPowerShellAsync(
            $"$a=$env:NIMOXY_ADAPTER; (Get-DnsClientServerAddress -InterfaceAlias $a -AddressFamily {afArg} -ErrorAction Stop).ServerAddresses",
            interfaceName);
        return ParseIpList(ps.Output, family);
    }

    public async Task<DnsApplyResult> ApplyAsync(string primary, string? secondary, string interfaceName)
    {
        // FIX 4.1: previously hard-required AddressFamily.InterNetwork, so any
        // IPv6 resolver in the catalog (or picked by Auto Pilot/Scout) failed
        // here with "Invalid primary DNS." before ever touching Windows. Now
        // both families are accepted and the correct `netsh interface ipv4|
        // ipv6` verb is used for every step below, driven off the parsed
        // address family of `primary`.
        if (!IPAddress.TryParse(primary, out var p) ||
            (p.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork && p.AddressFamily != System.Net.Sockets.AddressFamily.InterNetworkV6))
            return Fail("Invalid primary DNS.", interfaceName);
        if (!IsAdministrator) return Fail("Administrator permission is required. Run NIMOXY as administrator.", interfaceName);
        if (string.IsNullOrWhiteSpace(interfaceName)) return Fail("No network adapter was selected.", interfaceName);

        var family = p.AddressFamily;
        var ipVersion = family == System.Net.Sockets.AddressFamily.InterNetworkV6 ? "ipv6" : "ipv4";

        var servers = new List<string> { p.ToString() };
        // The secondary must be the same address family as the primary — mixing
        // an IPv4 primary with an IPv6 secondary (or vice versa) is not a valid
        // single `netsh interface ipv4|ipv6` server list.
        if (IPAddress.TryParse(secondary, out var s) && s.AddressFamily == family && !s.Equals(p))
            servers.Add(s.ToString());

        // Use the Windows netsh setter rather than appending DNS servers.
        // 'set dnsservers source=static address=...' replaces the complete list.
        // This is deliberately one synchronous Windows networking operation from
        // the user's point of view, while the process itself is awaited off the UI thread.
        var setArgs = new List<string>
        {
            "interface", ipVersion, "set", "dnsservers",
            $"name={interfaceName}", "source=static", $"address={servers[0]}", "validate=no"
        };
        var set = await RunAsync("netsh.exe", setArgs.ToArray());
        if (set.ExitCode != 0)
        {
            var ps = await RunPowerShellAsync(
                "$a=$env:NIMOXY_ADAPTER; Set-DnsClientServerAddress -InterfaceAlias $a -ServerAddresses ($env:NIMOXY_DNS -split \",\") -ErrorAction Stop",
                interfaceName, string.Join(",", servers));
            if (ps.ExitCode != 0)
                return Fail("Windows could not set the DNS: " + Clean(set.Output + " " + ps.Output), interfaceName, servers);
        }

        // Only add a secondary when the caller explicitly requested one.
        // Double-click passes null, therefore the old DNS list is fully replaced by one DNS.
        if (servers.Count > 1)
        {
            var add = await RunAsync("netsh.exe", "interface", ipVersion, "add", "dnsservers",
                $"name={interfaceName}", $"address={servers[1]}", "index=2", "validate=no");
            if (add.ExitCode != 0)
                return Fail("Primary DNS was set, but the secondary DNS could not be added: " + Clean(add.Output), interfaceName, servers);
        }

        await FlushDnsAsync();
        var actual = await GetCurrentDnsAsync(interfaceName, family);
        var expected = servers.Select(x => x.Trim()).ToArray();
        var ok = actual.Count == expected.Length && expected.SequenceEqual(actual, StringComparer.OrdinalIgnoreCase);

        return ok
            ? new(true, "DNS applied and verified.", interfaceName, servers, actual)
            : new(false, "DNS was changed, but verification failed. Windows reports: " + string.Join(", ", actual), interfaceName, servers, actual);
    }

    public async Task<(bool Success, string Message)> FlushDnsAsync()
    {
        // Flush the Windows DNS client cache. Prefer ipconfig because it is
        // available on supported Windows versions; use PowerShell as a fallback.
        var r = await RunAsync("ipconfig.exe", "/flushdns");
        if (r.ExitCode == 0)
            return (true, "Windows DNS cache flushed successfully.");

        var ps = await RunPowerShellAsync("Clear-DnsClientCache -ErrorAction Stop", "");
        return ps.ExitCode == 0
            ? (true, "Windows DNS cache flushed successfully.")
            : (false, "DNS cache flush failed: " + Clean(r.Output + " " + ps.Output));
    }

    public async Task<DnsApplyResult> RestoreAutomaticAsync(string interfaceName, System.Net.Sockets.AddressFamily family = System.Net.Sockets.AddressFamily.InterNetwork)
    {
        if (!IsAdministrator) return Fail("Administrator permission is required. Run NIMOXY as administrator.", interfaceName);
        var ipVersion = family == System.Net.Sockets.AddressFamily.InterNetworkV6 ? "ipv6" : "ipv4";
        var r = await RunAsync("netsh.exe", "interface", ipVersion, "set", "dnsservers", $"name={interfaceName}", "source=dhcp");
        if (r.ExitCode != 0)
        {
            var ps = await RunPowerShellAsync("$a=$env:NIMOXY_ADAPTER; Set-DnsClientServerAddress -InterfaceAlias $a -ResetServerAddresses -ErrorAction Stop", interfaceName);
            if (ps.ExitCode != 0) return Fail("Windows could not restore DHCP DNS: " + Clean(r.Output + " " + ps.Output), interfaceName);
        }
        await FlushDnsAsync();
        return new(true, "Automatic/DHCP DNS restored.", interfaceName, Array.Empty<string>(), await GetCurrentDnsAsync(interfaceName, family));
    }

    // FIX 13: neither RunAsync nor RunPowerShellAsync ever bounded how long
    // they would wait for netsh.exe/powershell.exe to exit. Every apply/
    // restore/flush call goes through applyGate (capacity 1), so a single
    // hung external process — a stuck network adapter is enough to trigger
    // this on real machines — blocked WaitForExitAsync() forever, holding
    // the gate closed and silently freezing every future DNS operation in
    // the app for the rest of the session, with no error or crash to explain
    // why. Both helpers now give the process a bounded window and kill it on
    // timeout instead of waiting indefinitely.
    private static readonly TimeSpan ProcessTimeout = TimeSpan.FromSeconds(15);

    private static DnsApplyResult Fail(string message, string iface, IReadOnlyList<string>? servers = null) => new(false, message, iface, servers ?? Array.Empty<string>(), Array.Empty<string>());
    private static string Clean(string value) => value.Replace("\r", " ").Replace("\n", " ").Trim();

    private static List<string> ParseIpList(string output, System.Net.Sockets.AddressFamily family) => output
        .Split(new[] { '\r', '\n', ' ', '\t', ',', ';' }, StringSplitOptions.RemoveEmptyEntries)
        .Where(x => IPAddress.TryParse(x, out var ip) && ip.AddressFamily == family)
        .Distinct(StringComparer.OrdinalIgnoreCase).ToList();

    private static async Task<(int ExitCode, string Output)> RunPowerShellAsync(string script, string adapter, string? dns = null)
    {
        var psi = new ProcessStartInfo("powershell.exe")
        {
            UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true,
            CreateNoWindow = true, StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
        };
        psi.ArgumentList.Add("-NoProfile");
        psi.ArgumentList.Add("-NonInteractive");
        psi.ArgumentList.Add("-ExecutionPolicy");
        psi.ArgumentList.Add("Bypass");
        psi.ArgumentList.Add("-Command");
        psi.ArgumentList.Add(script);
        psi.Environment["NIMOXY_ADAPTER"] = adapter;
        if (dns is not null) psi.Environment["NIMOXY_DNS"] = dns;
        using var p = new Process { StartInfo = psi };
        try
        {
            if (!p.Start()) return (-1, "PowerShell could not be started.");
            var stdoutTask = p.StandardOutput.ReadToEndAsync();
            var stderrTask = p.StandardError.ReadToEndAsync();
            using var timeoutCts = new CancellationTokenSource(ProcessTimeout);
            try { await p.WaitForExitAsync(timeoutCts.Token); }
            catch (OperationCanceledException)
            {
                TryKill(p);
                return (-1, $"powershell.exe did not respond within {ProcessTimeout.TotalSeconds:F0}s and was terminated.");
            }
            var stdout = await stdoutTask;
            var stderr = await stderrTask;
            return (p.ExitCode, string.IsNullOrWhiteSpace(stderr) ? stdout : stdout + " " + stderr);
        }
        catch (Exception ex) { return (-1, ex.Message); }
    }

    private static async Task<(int ExitCode, string Output)> RunAsync(string file, params string[] args)
    {
        var psi = new ProcessStartInfo(file)
        {
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };
        foreach (var arg in args) psi.ArgumentList.Add(arg);
        using var p = new Process { StartInfo = psi };
        try
        {
            if (!p.Start()) return (-1, "Process could not be started.");
            var stdoutTask = p.StandardOutput.ReadToEndAsync();
            var stderrTask = p.StandardError.ReadToEndAsync();
            using var timeoutCts = new CancellationTokenSource(ProcessTimeout);
            try { await p.WaitForExitAsync(timeoutCts.Token); }
            catch (OperationCanceledException)
            {
                TryKill(p);
                return (-1, $"{file} did not respond within {ProcessTimeout.TotalSeconds:F0}s and was terminated.");
            }
            var stdout = await stdoutTask;
            var stderr = await stderrTask;
            return (p.ExitCode, string.IsNullOrWhiteSpace(stderr) ? stdout : stdout + " " + stderr);
        }
        catch (Exception ex)
        {
            return (-1, ex.Message);
        }
    }

    private static void TryKill(Process p)
    {
        try { if (!p.HasExited) p.Kill(entireProcessTree: true); } catch { }
    }
}
