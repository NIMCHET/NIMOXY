using System.IO;
using System.Text.Json;

namespace NIMOXY.Services;

public enum DnsBucket
{
    None,
    Timeout,
    Failed,
    Applied
}

public sealed record DnsStateRecord(string Ip, DnsBucket Bucket, DateTimeOffset UpdatedAt);

/// <summary>
/// Small durable ledger for resolver UI state. DNS entries are never removed
/// from the catalog because a probe failed or because a resolver was applied;
/// this file only remembers the last UI/test bucket across application restarts.
/// </summary>
public sealed class DnsStateStore
{
    private readonly object gate = new();
    private readonly Dictionary<string, DnsStateRecord> states = new(StringComparer.OrdinalIgnoreCase);
    private readonly string filePath;

    public DnsStateStore()
    {
        var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NIMOXY");
        filePath = Path.Combine(dir, "dns-state.json");
        Load();
    }

    public DnsBucket Get(string ip)
    {
        if (string.IsNullOrWhiteSpace(ip)) return DnsBucket.None;
        lock (gate) return states.TryGetValue(ip, out var record) ? record.Bucket : DnsBucket.None;
    }

    public IReadOnlyList<DnsStateRecord> GetAll(DnsBucket bucket)
    {
        lock (gate) return states.Values.Where(x => x.Bucket == bucket).OrderByDescending(x => x.UpdatedAt).ToArray();
    }

    public void Set(string ip, DnsBucket bucket)
    {
        if (string.IsNullOrWhiteSpace(ip)) return;
        lock (gate)
        {
            states[ip] = new DnsStateRecord(ip.Trim(), bucket, DateTimeOffset.UtcNow);
        }
    }

    public void Clear(string ip)
    {
        if (string.IsNullOrWhiteSpace(ip)) return;
        lock (gate)
        {
            states.Remove(ip);
        }
    }

    private void Load()
    {
        try
        {
            if (!File.Exists(filePath)) return;
            var records = JsonSerializer.Deserialize<List<DnsStateRecord>>(File.ReadAllText(filePath));
            if (records is null) return;
            lock (gate)
            {
                foreach (var record in records.Where(x => !string.IsNullOrWhiteSpace(x.Ip)))
                    states[record.Ip] = record;
            }
        }
        catch { }
    }

    public void Save()
    {
        lock (gate) SaveLocked();
    }

    private void SaveLocked()
    {
        try
        {
            var dir = Path.GetDirectoryName(filePath)!;
            Directory.CreateDirectory(dir);
            var tmp = filePath + ".tmp";
            File.WriteAllText(tmp, JsonSerializer.Serialize(states.Values.OrderBy(x => x.Ip), new JsonSerializerOptions { WriteIndented = true }));
            File.Move(tmp, filePath, true);
        }
        catch { }
    }
}
