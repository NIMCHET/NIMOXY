using System.IO;
using System.Text.Json;

namespace NIMOXY.Services;

public sealed class AppSettings
{
    public string Theme { get; set; } = "Dark";
    public bool SoundsEnabled { get; set; } = true;
    public double Volume { get; set; } = 0.55;
    public bool StartupSound { get; set; }
    public bool StartWithWindows { get; set; } = true;
    public bool StartMinimized { get; set; } = false;
    public bool GamingMode { get; set; } = true;
    // FIX (gaming-safety gap): distinct from GamingMode above, which only
    // changes DNS scoring/ranking. This controls whether Auto Pilot's
    // background candidate search defers itself while a known game/launcher
    // process is running (see GameDetectionService). Defaults on because the
    // whole point of the feature is to protect a session the user did not
    // explicitly ask NIMOXY to interrupt.
    public bool GamingSafeModeEnabled { get; set; } = true;
    // Configurable, not a hard-coded placeholder: an operator can tune this
    // list for a game GameDetectionService's built-in defaults do not cover,
    // without a code change. Empty means "use the built-in defaults".
    public List<string> GamingSafeModeProcessNames { get; set; } = new();
    public string GamingProfile { get; set; } = "Competitive FPS"; // Section 68 default
    public int GamingRounds { get; set; } = 4;
    public int GamingDeepCandidates { get; set; } = 100;
    public int BenchmarkConcurrency { get; set; } = 512;
    public bool TurboBenchmark { get; set; } = true;
    public int TimeoutMs { get; set; } = 550;
    public int FastProbeTimeoutMs { get; set; } = 400;
    public int Retries { get; set; } = 1; // Section 68 default
    // FIX 3.3: EDNS0 ("send an OPT record at all") and DNSSEC's DO bit
    // ("ask the resolver to attempt/return DNSSEC validation") were a single
    // combined flag. Section 6 treats them as two independent behaviors —
    // a resolver can legitimately be tested with EDNS but without the DO
    // bit set. Kept both defaulting to true so existing behavior/settings
    // files upgrade sensibly (a missing key deserializes to the C# default).
    public bool EnableEdns { get; set; } = true;
    public bool EnableDnsSec { get; set; } = true;
    public int AutoPilotIntervalSeconds { get; set; } = 15;
    public int AutoPilotLatencyThresholdMs { get; set; } = 110;
    public double AutoPilotRelativeDegradationPct { get; set; } = 35;
    public double AutoPilotMinimumImprovementPct { get; set; } = 15;
    public double AutoPilotMinimumScoreImprovement { get; set; } = 3;
    public int AutoPilotBadChecks { get; set; } = 3;
    public int AutoPilotMinimumHoldMinutes { get; set; } = 5;
    public int AutoPilotCooldownSeconds { get; set; } = 120;
    public int AutoPilotCandidateVerificationProbes { get; set; } = 3;
    public double AutoPilotMaxCandidateLossPct { get; set; } = 34;
    public string AutoPilotProbeDomain { get; set; } = "example.com";
    public bool AutoPilotEnabled { get; set; } = true;
    public int CatalogRefreshHours { get; set; } = 12;
    public int DeadResolverRetestHours { get; set; } = 24;
    public int MaxUiRows { get; set; } = 5000;
    public List<string> TestDomains { get; set; } = new() { "example.com", "cloudflare.com", "google.com", "microsoft.com" };
    public List<string> GamingDomains { get; set; } = new() { "callofduty.com", "activision.com", "steamcommunity.com", "epicgames.com", "battle.net" };
    // Section 12 of the master prompt names five official gaming profiles.
    // Each list is a maintainable, real domain set for that profile — not a
    // placeholder. If a domain here ever stops resolving/verifying, that must
    // be logged (see BenchmarkService/FastProbeService), never silently hidden.
    public List<string> GetGamingDomainsForProfile() => GamingProfile switch
    {
        "Competitive FPS" => new() { "steamcommunity.com", "steampowered.com", "battle.net", "epicgames.com", "riotgames.com", "valvesoftware.com" },
        "Warzone / CoD" => new() { "callofduty.com", "activision.com", "battle.net", "steamcommunity.com", "xboxlive.com", "playstation.com" },
        "Steam" => new() { "steamcommunity.com", "steampowered.com", "steamstatic.com" },
        "Epic Games" => new() { "epicgames.com", "fortnite.com", "unrealengine.com" },
        "Battle.net" => new() { "battle.net", "blizzard.com", "activision.com", "callofduty.com" },
        _ => GamingDomains
    };
    public static readonly string[] OfficialGamingProfiles = { "Competitive FPS", "Warzone / CoD", "Steam", "Epic Games", "Battle.net" };
    private static string DirectoryPath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NIMOXY");
    private static string FilePath => Path.Combine(DirectoryPath, "settings.json");
    public static AppSettings Load()
    {
        try { if (File.Exists(FilePath)) return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new AppSettings(); } catch { }
        return new AppSettings();
    }
    public void Save()
    {
        try { Directory.CreateDirectory(DirectoryPath); File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true })); } catch { }
    }
}
