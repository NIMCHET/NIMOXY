using System.Buffers.Binary;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using NIMOXY.Models;

namespace NIMOXY.Services;

/// <summary>
/// Section 6 (FAST PROBE) of the master prompt. Independent from BenchmarkService
/// (the DEEP BENCHMARK engine): this one exists purely for quick health/candidate
/// filtering, so it stays cheap, but "cheap" must never mean "unvalidated" — a
/// resolver must not be marked healthy on the strength of a spoofed or malformed
/// UDP packet that merely happens to carry the right 2-byte transaction id.
/// </summary>
public enum ProbeStatus { Success, Timeout, NetworkError, InvalidResponse, ServFail, NxDomain, Refused, Unsupported, Cancelled }

public readonly record struct FastProbeResult(ProbeStatus Status, double LatencyMs, string Ip, string Domain, int Rcode, bool Truncated = false)
{
    public bool Success => Status == ProbeStatus.Success;
}

public sealed class FastProbeService
{
    private readonly AppSettings settings;
    public FastProbeService(AppSettings settings) => this.settings = settings;

    // Section C.1 (perf follow-up): a bare UdpClient holder that a bulk caller
    // (ProbeManyAsync / ProbeManyWithCallbackAsync) can keep across many
    // probes on the same worker, instead of one socket per probe. Plain
    // field, not a ref/out parameter, because ProbeCoreAsync is async and C#
    // does not allow ref/out parameters on async methods.
    private sealed class ClientSlot { public UdpClient? Client; }

    public Task<FastProbeResult> ProbeAsync(string ip, string? domain = null, CancellationToken ct = default)
        => ProbeCoreAsync(ip, domain, ct, slot: null);

    private async Task<FastProbeResult> ProbeCoreAsync(string ip, string? domain, CancellationToken ct, ClientSlot? slot)
    {
        domain ??= "example.com";
        if (!IPAddress.TryParse(ip, out var server) || server.AddressFamily is not (AddressFamily.InterNetwork or AddressFamily.InterNetworkV6))
            return new(ProbeStatus.NetworkError, double.NaN, ip, domain, -1);

        var id = (ushort)Random.Shared.Next(0, 65536);
        byte[] query;
        try { query = BuildQuery(id, domain, settings.EnableEdns, settings.EnableDnsSec); }
        catch { return new(ProbeStatus.NetworkError, double.NaN, ip, domain, -1); }

        try
        {
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(Math.Clamp(settings.FastProbeTimeoutMs, 120, 1500));
            var sw = Stopwatch.StartNew();

            // No pool (single-probe callers: manual Fast Probe button, Auto
            // Pilot's periodic health check, verify-candidate) -> unchanged
            // behavior, one socket created and disposed for this call only.
            //
            // Pooled (bulk callers) -> reuse the worker's socket across many
            // probes. Recreated only if the address family changes (mixed
            // IPv4/IPv6 catalogs) or a previous SocketException left it in a
            // state we no longer trust for reuse (see the inner catch below).
            var ownsClient = slot is null;
            UdpClient udp;
            if (slot is null)
            {
                udp = new UdpClient(server.AddressFamily);
            }
            else
            {
                if (slot.Client is null || slot.Client.Client.AddressFamily != server.AddressFamily)
                {
                    slot.Client?.Dispose();
                    slot.Client = new UdpClient(server.AddressFamily);
                }
                udp = slot.Client;
            }
            try
            {
                udp.Connect(server, 53);
                await udp.SendAsync(query.AsMemory(), timeout.Token);
                var reply = await udp.ReceiveAsync(timeout.Token);
                sw.Stop();

                var outcome = Validate(reply.Buffer, id, domain);
                if (outcome.Truncated)
                {
                    // TC bit set: UDP answer is incomplete, retry over TCP per spec
                    // ("TCP fallback در صورت TC") rather than trusting a truncated packet.
                    return await ProbeTcpAsync(server, ip, query, id, domain, sw.Elapsed.TotalMilliseconds, timeout.Token);
                }
                return outcome with { LatencyMs = sw.Elapsed.TotalMilliseconds, Ip = ip };
            }
            catch (SocketException) when (!ownsClient)
            {
                // A pooled socket that faulted at the OS/socket level is not
                // safe to reuse blindly; drop it so the next probe on this
                // worker gets a fresh one. A plain timeout (no reply) is NOT
                // caught here -- that is the common case for an offline
                // resolver and the socket is perfectly fine to reuse.
                slot!.Client?.Dispose();
                slot.Client = null;
                throw;
            }
            finally
            {
                if (ownsClient) udp.Dispose();
            }
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        { return new(ProbeStatus.Timeout, double.NaN, ip, domain, -1); }
        catch (OperationCanceledException)
        { return new(ProbeStatus.Cancelled, double.NaN, ip, domain, -1); }
        catch (SocketException)
        { return new(ProbeStatus.NetworkError, double.NaN, ip, domain, -1); }
        catch (InvalidDataException)
        { return new(ProbeStatus.InvalidResponse, double.NaN, ip, domain, -1); }
        catch
        { return new(ProbeStatus.NetworkError, double.NaN, ip, domain, -1); }
    }

    private async Task<FastProbeResult> ProbeTcpAsync(IPAddress server, string ip, byte[] query, ushort id, string domain, double udpMs, CancellationToken ct)
    {
        try
        {
            using var tcp = new TcpClient(server.AddressFamily);
            await tcp.ConnectAsync(server, 53, ct);
            await using var stream = tcp.GetStream();
            var len = new byte[2];
            BinaryPrimitives.WriteUInt16BigEndian(len, (ushort)query.Length);
            await stream.WriteAsync(len, ct);
            await stream.WriteAsync(query, ct);
            await stream.ReadExactlyAsync(len, ct);
            var size = BinaryPrimitives.ReadUInt16BigEndian(len);
            if (size < 12) return new(ProbeStatus.InvalidResponse, udpMs, ip, domain, -1);
            var response = new byte[size];
            await stream.ReadExactlyAsync(response, ct);
            var outcome = Validate(response, id, domain);
            // TCP is already the reliable transport; a second TC=1 here would be
            // a malformed/misbehaving server, not something to retry indefinitely.
            return outcome with { LatencyMs = udpMs, Ip = ip, Truncated = false };
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested) { return new(ProbeStatus.Timeout, double.NaN, ip, domain, -1); }
        catch (OperationCanceledException) { return new(ProbeStatus.Cancelled, double.NaN, ip, domain, -1); }
        catch (SocketException) { return new(ProbeStatus.NetworkError, double.NaN, ip, domain, -1); }
        catch { return new(ProbeStatus.InvalidResponse, double.NaN, ip, domain, -1); }
    }

    /// <summary>
    /// Full validation of a candidate DNS reply: transaction id, QR bit, question
    /// section echoed back correctly (protects against unrelated/spoofed UDP
    /// packets landing on the same socket), RCODE mapped to a distinct status,
    /// and defensive bounds checks so a truncated/garbled packet throws instead
    /// of reading past the buffer.
    /// </summary>
    private static FastProbeResult Validate(byte[] b, ushort expectedId, string domain)
    {
        if (b.Length < 12) throw new InvalidDataException("Reply shorter than a DNS header.");
        var replyId = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(0, 2));
        if (replyId != expectedId) throw new InvalidDataException("Transaction id mismatch.");

        var flags = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(2, 2));
        if ((flags & 0x8000) == 0) throw new InvalidDataException("QR bit not set (not a response).");
        var truncated = (flags & 0x0200) != 0;

        var qd = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(4, 2));
        if (qd != 1) throw new InvalidDataException("Unexpected question count.");

        var offset = 12;
        if (!TryMatchQuestionName(b, ref offset, domain)) throw new InvalidDataException("Question section does not echo the query.");
        if (offset + 4 > b.Length) throw new InvalidDataException("Malformed question section.");
        offset += 4; // QTYPE + QCLASS, already validated by construction

        var rcode = flags & 0x000F;
        var status = rcode switch
        {
            0 => ProbeStatus.Success,
            2 => ProbeStatus.ServFail,
            3 => ProbeStatus.NxDomain,
            5 => ProbeStatus.Refused,
            _ => ProbeStatus.Unsupported,
        };
        return new FastProbeResult(status, double.NaN, "", domain, rcode, truncated);
    }

    /// <summary>
    /// Compares the echoed QNAME (case-insensitive) against the domain we sent.
    /// Internal (not private) so BenchmarkService's Deep Benchmark engine can
    /// reuse the exact same question-consistency check instead of validating
    /// responses less strictly than Fast Probe does (Section 7 / FIX 3.2).
    /// </summary>
    internal static bool TryMatchQuestionName(byte[] b, ref int offset, string domain)
    {
        var expected = domain.Trim().TrimEnd('.').Split('.', StringSplitOptions.RemoveEmptyEntries);
        var i = 0;
        var guard = 0;
        while (offset < b.Length && guard++ < 128)
        {
            var len = b[offset];
            if (len == 0) { offset++; return i == expected.Length; }
            if ((len & 0xC0) != 0) return false; // compression not expected in the question section we sent
            if (offset + 1 + len > b.Length) return false;
            var label = Encoding.ASCII.GetString(b, offset + 1, len);
            if (i >= expected.Length || !label.Equals(expected[i], StringComparison.OrdinalIgnoreCase)) return false;
            i++;
            offset += 1 + len;
        }
        return false;
    }

    public async Task<IReadOnlyList<FastProbeResult>> ProbeManyAsync(IEnumerable<DnsResolver> resolvers, int concurrency, CancellationToken ct)
    {
        var list = resolvers.Where(x => !string.IsNullOrWhiteSpace(x.Ip)).ToList();
        var results = new FastProbeResult[list.Count];
        await RunPooledAsync(list.Count, concurrency, ct,
            async (i, slot, token) => results[i] = await ProbeCoreAsync(list[i].Ip, null, token, slot));
        return results;
    }

    // Section C.1: same pooled worker loop as ProbeManyAsync, but for bulk
    // scans (Global Fast Scout: up to the full catalog, thousands of
    // resolvers, concurrency up to 1024) that need to react to each result
    // as it arrives -- per-item progress UI, immediate scoring -- rather than
    // waiting for the whole batch. onStart fires the moment a worker claims
    // an item, before probing it; onResult fires once that probe completes.
    public async Task<int> ProbeManyWithCallbackAsync(
        IReadOnlyList<DnsResolver> resolvers,
        int concurrency,
        string? domain,
        Action<int, DnsResolver>? onStart,
        Func<int, DnsResolver, FastProbeResult, Task> onResult,
        CancellationToken ct)
    {
        var completed = 0;
        await RunPooledAsync(resolvers.Count, concurrency, ct, async (i, slot, token) =>
        {
            var dns = resolvers[i];
            onStart?.Invoke(i, dns);
            if (string.IsNullOrWhiteSpace(dns.Ip))
            {
                await onResult(i, dns, new FastProbeResult(ProbeStatus.NetworkError, double.NaN, dns.Ip, domain ?? "example.com", -1));
                return;
            }
            var result = await ProbeCoreAsync(dns.Ip, domain, token, slot);
            Interlocked.Increment(ref completed);
            await onResult(i, dns, result);
        });
        return completed;
    }

    // Section C.1: a bounded pool of `workers` long-lived tasks pulling items
    // off a shared index instead of Parallel.ForEachAsync spinning up one
    // logical unit of work per item -- each worker keeps one ClientSlot (one
    // pooled UdpClient) for its entire lifetime, so socket count for a bulk
    // scan is bounded by concurrency, not by catalog size.
    //
    // Cancellation semantics preserved from the original Parallel.ForEachAsync
    // call: a real cancellation of `ct` (Stop/Pause) always throws
    // OperationCanceledException out of this method -- this matters because
    // AutoPilotService.LoopAsync (Section A.1 fix) only ends its loop on a
    // genuine OperationCanceledException, never on an ordinary fault. An
    // exception from `processItem` itself (not cancellation) stops sibling
    // workers promptly via a local, internal-only token rather than letting
    // them keep burning through remaining items whose results will be
    // discarded anyway.
    private static async Task RunPooledAsync(int itemCount, int concurrency, CancellationToken ct, Func<int, ClientSlot, CancellationToken, Task> processItem)
    {
        var workers = Math.Clamp(concurrency, 16, 1024);
        var taskCount = Math.Min(workers, Math.Max(1, itemCount));
        var nextIndex = -1;
        using var stopEarly = CancellationTokenSource.CreateLinkedTokenSource(ct);

        async Task WorkerAsync()
        {
            var slot = new ClientSlot();
            try
            {
                while (true)
                {
                    ct.ThrowIfCancellationRequested();
                    if (stopEarly.IsCancellationRequested) return;
                    var i = Interlocked.Increment(ref nextIndex);
                    if (i >= itemCount) return;
                    await processItem(i, slot, stopEarly.Token);
                }
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                // stopEarly fired because a sibling worker faulted, not a
                // real cancellation -- exit quietly, Task.WhenAll below will
                // surface the sibling's actual exception.
            }
            catch
            {
                stopEarly.Cancel();
                throw;
            }
            finally { slot.Client?.Dispose(); }
        }

        var tasks = new Task[taskCount];
        for (var w = 0; w < taskCount; w++) tasks[w] = WorkerAsync();
        await Task.WhenAll(tasks);
    }

    // FIX 3.3: enableEdns ("attach an OPT record at all") and enableDnsSec
    // ("set the DO bit inside it") are now independent per Section 6 — a
    // caller can request EDNS without DNSSEC. The DO bit itself only has a
    // place to live inside an OPT record, so requesting DNSSEC alone still
    // implies attaching the OPT record (it cannot mean anything otherwise).
    private static byte[] BuildQuery(ushort id, string domain, bool enableEdns, bool enableDnsSec)
    {
        var attachOpt = enableEdns || enableDnsSec;
        var labels = domain.Trim().TrimEnd('.').Split('.', StringSplitOptions.RemoveEmptyEntries);
        var bytes = new List<byte>(96);
        void U16(ushort v) { bytes.Add((byte)(v >> 8)); bytes.Add((byte)v); }
        U16(id); U16(0x0100); U16(1); U16(0); U16(0); U16(attachOpt ? (ushort)1 : (ushort)0); // ARCOUNT=1 when we attach an OPT record
        foreach (var label in labels)
        {
            var ascii = Encoding.ASCII.GetBytes(label);
            if (ascii.Length is 0 or > 63) throw new InvalidDataException("Invalid DNS label.");
            bytes.Add((byte)ascii.Length);
            bytes.AddRange(ascii);
        }
        bytes.Add(0); U16(1); U16(1); // QTYPE=A, QCLASS=IN

        if (attachOpt)
        {
            // EDNS0 OPT pseudo-record: root name, TYPE=41, UDP payload 4096,
            // DO bit set only when DNSSEC was independently requested.
            bytes.Add(0); U16(41); U16(4096); U16(enableDnsSec ? (ushort)0x8000 : (ushort)0); U16(0); U16(0);
        }
        return bytes.ToArray();
    }
}
