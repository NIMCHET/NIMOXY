using System.Windows;
using System.Windows.Media;

namespace NIMOXY.Services;

public static class ThemeService
{
    public static void Apply(string theme)
    {
        var app = System.Windows.Application.Current;
        if (app is null) return;
        var dict = new ResourceDictionary
        {
            Source = new Uri(theme.Equals("Light", StringComparison.OrdinalIgnoreCase)
                ? "/NIMOXY;component/Themes/Light.xaml"
                : "/NIMOXY;component/Themes/Dark.xaml", UriKind.Relative)
        };
        app.Resources.MergedDictionaries.Clear();
        app.Resources.MergedDictionaries.Add(dict);
    }
}
