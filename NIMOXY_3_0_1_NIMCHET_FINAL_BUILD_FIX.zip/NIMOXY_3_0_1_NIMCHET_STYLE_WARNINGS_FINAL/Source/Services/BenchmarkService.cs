using System.Buffers.Binary;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using NIMOXY.Models;

namespace NIMOXY.Services;

/// <summary>
/// Fast, low-noise DNS benchmark engine.
/// Uses independent UDP probes, bounded concurrency, EDNS(0), optional DNSSEC,
/// TCP fallback for truncated responses and percentile-based scoring.
/// </summary>
public sealed class BenchmarkService
{
    // FIX 3.4: named constants for the scoring formula below. None of these
    // change behavior — they document, with the actual unit/meaning, values
    // that were previously bare literals scattered through TestAsync
    // (Section 73: "no magic numbers without named constants/settings").
    // Standard score: decay half-life-ish denominators (ms) for exp(-x/k).
    private const double StandardLatencyDecayMs = 55.0;
    private const double StandardTailDecayMs = 110.0;
    private const double StandardJitterDecayMs = 45.0;
    private const double StandardLossDecayPct = 3.0;
    // Standard score: component weights (must sum with the bonuses below to
    // stay within the eventual Math.Clamp(score, 0, 100)).
    private const double StandardLatencyWeight = 0.42;
    private const double StandardTailWeight = 0.28;
    private const double StandardJitterWeight = 0.15;
    private const double StandardLossWeight = 0.15;
    // Standard score: small, capped bonuses — cannot dominate speed/loss.
    private const double DnsSecBonus = 1.25;
    private const double EdnsBonus = 0.35;
    private const double TrustedBonus = 0.75;
    // A resolver benchmarked on fewer than this many total samples is
    // penalized slightly beyond the hard ApplyConfidenceCap, because a small
    // sample is useful for ranking but should not look as certain as a
    // deep, many-round test.
    private const int LowSampleCountThreshold = 6;
    private const double LowSampleCountPenalty = 1.0;
    // Gaming score: same shape as the standard score, but with denominators/
    // weights re-tuned to emphasize tail latency, jitter and loss (Section 12).
    private const double GamingLatencyDecayMs = 45.0;
    private const double GamingTailDecayMs = 85.0;
    private const double GamingJitterDecayMs = 25.0;
    private const double GamingLossDecayPct = 1.75;
    private const double GamingLatencyWeight = 0.30;
    private const double GamingTailWeight = 0.25;
    private const double GamingJitterWeight = 0.18;
    private const double GamingLossWeight = 0.12;
    private const double GamingCoverageWeight = 0.15;
    private const double GamingDnsSecBonus = 0.5;
    private const double GamingEdnsBonus = 0.2;

    private readonly AppSettings settings;
    public BenchmarkService(AppSettings settings) => this.settings = settings;

    public async Task TestAsync(DnsResolver resolver, int rounds, CancellationToken ct)
    {
        resolver.Status = "Testing";
        resolver.DeepTested = rounds > 1;
        resolver.SampleCount = 0;

        if (!IPAddress.TryParse(resolver.Ip, out var server) ||
            server.AddressFamily is not (AddressFamily.InterNetwork or AddressFamily.InterNetworkV6))
        {
            MarkFailed(resolver, "Invalid");
            return;
        }

        var domains = (settings.GamingMode ? settings.GetGamingDomainsForProfile() : settings.TestDomains)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim().TrimEnd('.'))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(6)
            .ToArray();
        if (domains.Length == 0) domains = new[] { "example.com", "cloudflare.com", "google.com", "microsoft.com" };

        var samples = new List<double>(Math.Max(8, domains.Length * Math.Max(1, rounds)));
        var failures = 0;
        var dnssec = false;
        var edns = false;
        var totalAttempts = 0;
        var domainSuccesses = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var domain in domains) domainSuccesses[domain] = 0;
        var roundsToRun = Math.Clamp(rounds, 1, 12);

        for (var round = 0; round < roundsToRun; round++)
        {
            ct.ThrowIfCancellationRequested();

            // Parallelize domains inside a resolver, but never share a UDP receive socket.
            var tasks = domains.Select(domain => ProbeWithRetryAsync(server, domain, ct)).ToArray();
            var results = await Task.WhenAll(tasks);
            totalAttempts += results.Length;

            foreach (var result in results)
            {
                if (result.Success)
                {
                    samples.Add(result.LatencyMs);
                    domainSuccesses[result.Domain]++;
                    dnssec |= result.DnsSec;
                    edns |= result.Edns;
                }
                else failures++;
            }
        }

        resolver.SampleCount = samples.Count;
        resolver.LossPct = totalAttempts == 0 ? 100 : failures * 100.0 / totalAttempts;
        resolver.DnsSec = dnssec;
        resolver.Edns = edns;
        resolver.GamingCoveragePct = domains.Length == 0 ? 0 : domainSuccesses.Values.Count(v => v > 0) * 100.0 / domains.Length;

        if (samples.Count == 0)
        {
            MarkFailed(resolver, "Offline");
            return;
        }

        var ordered = samples.OrderBy(x => x).ToList();
        resolver.AvgMs = samples.Average();
        resolver.MedianMs = PercentileSorted(ordered, .50);
        resolver.JitterMs = MeanAbsoluteDeviation(samples, resolver.MedianMs);
        resolver.P95Ms = PercentileSorted(ordered, .95);
        resolver.P99Ms = PercentileSorted(ordered, .99);

        // Absolute, human-friendly score. Tail latency and loss matter more than a tiny
        // average advantage. Security/features are small bonuses and cannot dominate speed.
        var latencyComponent = 100.0 * Math.Exp(-resolver.MedianMs / StandardLatencyDecayMs);
        var tailComponent = 100.0 * Math.Exp(-resolver.P95Ms / StandardTailDecayMs);
        var jitterComponent = 100.0 * Math.Exp(-resolver.JitterMs / StandardJitterDecayMs);
        var lossComponent = 100.0 * Math.Exp(-resolver.LossPct / StandardLossDecayPct);

        var score =
            latencyComponent * StandardLatencyWeight +
            tailComponent * StandardTailWeight +
            jitterComponent * StandardJitterWeight +
            lossComponent * StandardLossWeight +
            (resolver.DnsSec ? DnsSecBonus : 0) +
            (resolver.Edns ? EdnsBonus : 0) +
            (resolver.Trusted ? TrustedBonus : 0);

        // A very small sample is useful for ranking, but should not look as certain as a deep test.
        if (samples.Count < LowSampleCountThreshold) score -= LowSampleCountPenalty;
        resolver.Confidence = ConfidenceService.Classify(resolver.SampleCount, resolver.LossPct, resolver.JitterMs, resolver.MedianMs);
        // Section 60: a single excellent measurement must not outrank a
        // resolver backed by hundreds of consistent ones — enforced as a hard
        // cap, not a soft multiplier, so it holds regardless of score gap.
        resolver.Score = ConfidenceService.ApplyConfidenceCap(Math.Clamp(score, 0, 100), resolver.SampleCount);

        // Gaming score intentionally emphasizes tail latency, jitter and loss.
        // DNS can affect name resolution/matchmaking/launcher traffic, but it does
        // not directly control the ping to an already-connected game server.
        var gamingLatency = 100.0 * Math.Exp(-resolver.MedianMs / GamingLatencyDecayMs);
        var gamingTail = 100.0 * Math.Exp(-resolver.P95Ms / GamingTailDecayMs);
        var gamingJitter = 100.0 * Math.Exp(-resolver.JitterMs / GamingJitterDecayMs);
        var gamingLoss = 100.0 * Math.Exp(-resolver.LossPct / GamingLossDecayPct);
        var gamingCoverage = resolver.GamingCoveragePct;
        resolver.GamingScore = ConfidenceService.ApplyConfidenceCap(Math.Clamp(
            gamingLatency * GamingLatencyWeight +
            gamingTail * GamingTailWeight +
            gamingJitter * GamingJitterWeight +
            gamingLoss * GamingLossWeight +
            gamingCoverage * GamingCoverageWeight +
            (resolver.DnsSec ? GamingDnsSecBonus : 0) +
            (resolver.Edns ? GamingEdnsBonus : 0), 0, 100), resolver.SampleCount);
        resolver.Status = resolver.LossPct == 0 ? "Healthy" :
                          resolver.LossPct < 5 ? "Stable" :
                          resolver.LossPct < 20 ? "Unstable" : "Poor";
    }

    private async Task<ProbeResult> ProbeWithRetryAsync(IPAddress server, string domain, CancellationToken ct)
    {
        var retries = Math.Clamp(settings.Retries, 0, 3);
        for (var attempt = 0; attempt <= retries; attempt++)
        {
            try
            {
                var id = (ushort)Random.Shared.Next(1, 65535);
                var query = BuildQuery(id, domain, settings.EnableEdns, settings.EnableDnsSec);
                return await QueryAsync(server, query, domain, ct);
            }
            catch (OperationCanceledException) { throw; }
            catch when (attempt < retries)
            {
                var delay = 12 + attempt * 18 + Random.Shared.Next(0, 12);
                await Task.Delay(delay, ct);
            }
            catch { }
        }
        return ProbeResult.Failed;
    }

    private async Task<ProbeResult> QueryAsync(IPAddress server, byte[] packet, string domain, CancellationToken ct)
    {
        using var udp = new UdpClient(server.AddressFamily);
        udp.Client.ReceiveBufferSize = 64 * 1024;
        udp.Connect(server, 53);

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(Math.Clamp(settings.TimeoutMs, 100, 2500));

        var sw = Stopwatch.StartNew();
        await udp.SendAsync(packet, packet.Length);
        var result = await udp.ReceiveAsync(timeout.Token);
        sw.Stop();

        if (result.Buffer.Length < 12 || result.Buffer[0] != packet[0] || result.Buffer[1] != packet[1])
            throw new InvalidDataException("DNS transaction mismatch");

        var flags = BinaryPrimitives.ReadUInt16BigEndian(result.Buffer.AsSpan(2, 2));
        // Only accept an actual response to our query. This avoids counting
        // malformed/unrelated UDP packets as successful DNS samples.
        if ((flags & 0x8000) == 0) throw new InvalidDataException("DNS packet is not a response");
        var rcode = flags & 0x000F;
        if (rcode != 0) throw new InvalidDataException($"DNS rcode {rcode}");

        // FIX 3.2: the Deep Benchmark engine (this method) only checked the
        // 2-byte transaction id and the QR/RCODE bits — unlike Fast Probe,
        // it never confirmed the question section actually echoes the QNAME
        // we sent. A stray/spoofed UDP packet on the same socket with a
        // matching transaction id (a 16-bit space, collisions are cheap)
        // could be counted as a valid, successful sample. Section 7 lists
        // "Question consistency" as a mandatory validation step; reuse the
        // exact check Fast Probe already implements instead of duplicating
        // (and potentially drifting from) it.
        var qd = BinaryPrimitives.ReadUInt16BigEndian(result.Buffer.AsSpan(4, 2));
        if (qd != 1) throw new InvalidDataException("Unexpected question count.");
        var qOffset = 12;
        if (!FastProbeService.TryMatchQuestionName(result.Buffer, ref qOffset, domain))
            throw new InvalidDataException("Question section does not echo the query.");

        var parsed = ParseResponse(result.Buffer);
        if ((flags & 0x0200) != 0)
            return await QueryTcpAsync(server, packet, domain, sw.Elapsed.TotalMilliseconds, ct, parsed.DnsSec, parsed.Edns);

        return new ProbeResult(true, sw.Elapsed.TotalMilliseconds, parsed.DnsSec, parsed.Edns, domain);
    }

    private async Task<ProbeResult> QueryTcpAsync(IPAddress server, byte[] query, string domain, double udpMs, CancellationToken ct, bool dnssec, bool edns)
    {
        using var tcp = new TcpClient(server.AddressFamily);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(Math.Clamp(settings.TimeoutMs, 100, 2500));

        var sw = Stopwatch.StartNew();
        await tcp.ConnectAsync(server, 53, timeout.Token);
        await using var stream = tcp.GetStream();
        var len = new byte[2];
        BinaryPrimitives.WriteUInt16BigEndian(len, (ushort)query.Length);
        await stream.WriteAsync(len, timeout.Token);
        await stream.WriteAsync(query, timeout.Token);
        await stream.ReadExactlyAsync(len, timeout.Token);
        var size = BinaryPrimitives.ReadUInt16BigEndian(len);
        if (size < 12) throw new InvalidDataException("Invalid TCP DNS response");
        var response = new byte[size];
        await stream.ReadExactlyAsync(response, timeout.Token);
        sw.Stop();

        // FIX 3.2 (TCP fallback path): this previously accepted any TCP
        // payload of a plausible size with no transaction id, RCODE, or
        // question-consistency check at all — weaker validation than the
        // UDP path it falls back from. Apply the same checks here.
        if (response[0] != query[0] || response[1] != query[1])
            throw new InvalidDataException("DNS transaction mismatch (TCP)");
        var tcpFlags = BinaryPrimitives.ReadUInt16BigEndian(response.AsSpan(2, 2));
        if ((tcpFlags & 0x8000) == 0) throw new InvalidDataException("DNS packet is not a response (TCP)");
        var tcpRcode = tcpFlags & 0x000F;
        if (tcpRcode != 0) throw new InvalidDataException($"DNS rcode {tcpRcode} (TCP)");
        var tcpQd = BinaryPrimitives.ReadUInt16BigEndian(response.AsSpan(4, 2));
        if (tcpQd != 1) throw new InvalidDataException("Unexpected question count (TCP)");
        var tcpQOffset = 12;
        if (!FastProbeService.TryMatchQuestionName(response, ref tcpQOffset, domain))
            throw new InvalidDataException("Question section does not echo the query (TCP)");

        var parsed = ParseResponse(response);
        return new ProbeResult(true, udpMs + sw.Elapsed.TotalMilliseconds, dnssec || parsed.DnsSec, edns || parsed.Edns, domain);
    }

    // FIX 3.3: same split as FastProbeService.BuildQuery — EDNS (attach the
    // OPT record) and DNSSEC (set the DO bit) are independent settings now.
    // Previously this method always attached an OPT record unconditionally
    // and only the DO bit was toggled, so "EDNS off" was never actually
    // representable in the Deep Benchmark engine at all.
    private static byte[] BuildQuery(ushort id, string domain, bool enableEdns, bool enableDnsSec)
    {
        var attachOpt = enableEdns || enableDnsSec;
        var bytes = new List<byte>(192);
        void U16(ushort v) { bytes.Add((byte)(v >> 8)); bytes.Add((byte)v); }
        U16(id); U16(0x0100); U16(1); U16(0); U16(0); U16(attachOpt ? (ushort)1 : (ushort)0);
        foreach (var label in domain.Split('.', StringSplitOptions.RemoveEmptyEntries))
        {
            var ascii = Encoding.ASCII.GetBytes(label);
            if (ascii.Length is 0 or > 63) throw new InvalidDataException("Invalid DNS label");
            bytes.Add((byte)ascii.Length); bytes.AddRange(ascii);
        }
        bytes.Add(0); U16(1); U16(1);
        if (attachOpt)
        {
            bytes.Add(0); U16(41); U16(4096); U16((ushort)(enableDnsSec ? 0x8000 : 0)); U16(0); U16(0);
        }
        return bytes.ToArray();
    }

    private static (bool DnsSec, bool Edns) ParseResponse(byte[] b)
    {
        if (b.Length < 12) return (false, false);
        var qd = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(4, 2));
        var an = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(6, 2));
        var ns = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(8, 2));
        var ar = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(10, 2));
        var offset = 12;
        SkipQuestions(b, ref offset, qd);
        var dnssec = false;
        var edns = false;
        var records = an + ns + ar;
        for (var i = 0; i < records && offset < b.Length; i++)
        {
            SkipName(b, ref offset);
            if (offset + 10 > b.Length) break;
            var type = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(offset, 2));
            var rdlen = BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(offset + 8, 2));
            offset += 10;
            if (type == 46) dnssec = true;
            if (type == 41) edns = true;
            if (offset + rdlen > b.Length) break;
            offset += rdlen;
        }
        return (dnssec, edns);
    }

    private static void SkipQuestions(byte[] b, ref int o, int count)
    {
        for (var i = 0; i < count; i++) { SkipName(b, ref o); if (o + 4 > b.Length) return; o += 4; }
    }

    private static void SkipName(byte[] b, ref int o)
    {
        var guard = 0;
        while (o < b.Length && guard++ < 256)
        {
            var n = b[o++];
            if (n == 0) return;
            if ((n & 0xC0) == 0xC0) { if (o < b.Length) o++; return; }
            if ((n & 0xC0) != 0 || o + n > b.Length) { o = b.Length; return; }
            o += n;
        }
    }

    private static double MeanAbsoluteDeviation(List<double> values, double center)
    {
        if (values.Count == 0 || double.IsNaN(center)) return 0;
        double total = 0;
        foreach (var value in values) total += Math.Abs(value - center);
        return total / values.Count;
    }

    private static double PercentileSorted(List<double> values, double p)
    {
        if (values.Count == 0) return double.NaN;
        var idx = (values.Count - 1) * p;
        var lo = (int)Math.Floor(idx);
        var hi = (int)Math.Ceiling(idx);
        if (lo == hi) return values[lo];
        return values[lo] + (values[hi] - values[lo]) * (idx - lo);
    }

    private static void MarkFailed(DnsResolver r, string status)
    {
        r.AvgMs = r.MedianMs = r.JitterMs = r.P95Ms = r.P99Ms = double.NaN;
        r.LossPct = 100; r.Score = 0; r.GamingScore = 0; r.Status = status; r.SampleCount = 0;
    }

    private readonly record struct ProbeResult(bool Success, double LatencyMs, bool DnsSec, bool Edns, string Domain)
    {
        public static ProbeResult Failed => new(false, double.NaN, false, false, "");
    }
}
