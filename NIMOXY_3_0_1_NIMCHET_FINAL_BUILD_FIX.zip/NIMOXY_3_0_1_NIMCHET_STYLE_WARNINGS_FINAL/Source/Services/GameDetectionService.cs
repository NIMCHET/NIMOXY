using System.Diagnostics;

namespace NIMOXY.Services;

/// <summary>
/// FIX (gaming-safety gap, found during forensic review): the master prompt's
/// Phase 3 / Priority #3 requires NIMOXY to detect that the user is actively
/// gaming and switch background scanning into a paused/ultra-low-rate mode.
/// No such detection existed anywhere in the prior codebase — "Gaming Mode"
/// and the Gaming Profiles only changed *scoring/ranking* of DNS results,
/// never whether/how much background probing happens. This service closes
/// that gap with the cheapest, safest signal available without a kernel
/// driver or elevated access: is a known game/launcher process running.
///
/// This is deliberately NOT a network-path or adapter check (that is a
/// separate, harder problem the master prompt calls out on its own around
/// multi-adapter isolation) — it only asks "does a matching process exist",
/// which has no network side effects and cannot itself cause any lag.
///
/// Per Phase 3's explicit rule ("اگر gaming detection قابل اعتماد نیست،
/// default محافظه‌کارانه باشد" — if detection is not reliable, default
/// conservative): if process enumeration itself fails (e.g. restricted
/// permissions), this returns true (assume gaming) rather than false,
/// because a false "not gaming" during an actual match is exactly the
/// outcome this feature exists to prevent, while a false "gaming" only
/// costs one deferred background candidate search.
///
/// Known limitation (documented honestly, not hidden): process-name
/// matching is a heuristic. It will miss games that don't match the list
/// below and can in principle false-positive on an unrelated process that
/// happens to share a name. The list is configurable via
/// AppSettings.GamingSafeModeProcessNames specifically so it can be tuned
/// without a code change; it is not claimed to be exhaustive.
/// </summary>
public sealed class GameDetectionService
{
    private readonly AppSettings settings;

    // FIX (testability gap, noted in the prior handoff): IsGameLikelyRunning()
    // used to call Process.GetProcesses() directly, so the regression suite
    // had no deterministic way to simulate "a game is running" vs. "it is
    // not" without actually launching a matching process on the test
    // machine. This provider defaults to the real Windows process list but
    // can be swapped for a fake one in tests -- the detection *logic*
    // (name matching, conservative-on-failure) stays identical either way.
    private readonly Func<IEnumerable<string>> processNameProvider;

    public GameDetectionService(AppSettings settings) : this(settings, DefaultProcessNameProvider) { }

    /// <summary>Test/DI entry point: supply a fake list of running process names.</summary>
    public GameDetectionService(AppSettings settings, Func<IEnumerable<string>> processNameProvider)
    {
        this.settings = settings;
        this.processNameProvider = processNameProvider;
    }

    private static IEnumerable<string> DefaultProcessNameProvider()
    {
        foreach (var p in Process.GetProcesses())
        {
            using (p)
            {
                string name;
                try { name = p.ProcessName; }
                catch { continue; /* one process failing to answer must not abort the whole check */ }
                yield return name;
            }
        }
    }

    private static readonly string[] DefaultProcessNames =
    {
        // Launchers / platforms (cover the large majority of active sessions
        // for the gaming profiles NIMOXY already targets in Section 12).
        "steam", "steamwebhelper", "epicgameslauncher", "battle.net", "riotclientservices",
        "riotclientux", "gamingservices", "galaxyclient", "origin", "eadesktop",
        "ubisoftconnect", "upc",
        // High-population titles, matched on the actual game process name.
        "csgo", "cs2", "valorant-win64-shipping", "leagueoflegends",
        "fortniteclient-win64-shipping", "modernwarfare", "cod", "overwatch",
        "dota2", "rainbowsix", "apex_legends", "gta5", "rocketleague",
    };

    /// <summary>
    /// True if a known game/launcher process is currently running, or if
    /// process enumeration itself could not be completed at all.
    /// </summary>
    public bool IsGameLikelyRunning()
    {
        HashSet<string> names;
        try
        {
            names = settings.GamingSafeModeProcessNames is { Count: > 0 } cfg
                ? new HashSet<string>(cfg, StringComparer.OrdinalIgnoreCase)
                : new HashSet<string>(DefaultProcessNames, StringComparer.OrdinalIgnoreCase);
        }
        catch
        {
            names = new HashSet<string>(DefaultProcessNames, StringComparer.OrdinalIgnoreCase);
        }

        try
        {
            foreach (var name in processNameProvider())
            {
                if (names.Contains(name)) return true;
            }
            return false;
        }
        catch
        {
            // Conservative default per Phase 3: cannot verify -> assume gaming.
            return true;
        }
    }
}
