using System.IO;
using System.Text.Json;

namespace NIMOXY.Services;

/// <summary>
/// Implements master-prompt Section 67 (Log Detail): every DNS switch must
/// record OperationId, OldDNS, NewDNS, OldScore, NewScore, OldP95, NewP95,
/// OldLoss, NewLoss, Reason, Verification, Rollback. Also backs the History
/// tab from Section 3, and is deliberately bounded (Section 63: no unbounded
/// growth / no runaway resource use from logging).
/// </summary>
public sealed record SwitchLogEntry(
    Guid OperationId,
    DateTimeOffset Timestamp,
    string? OldDns,
    string? NewDns,
    double? OldScore,
    double? NewScore,
    double? OldP95,
    double? NewP95,
    double? OldLoss,
    double? NewLoss,
    string Reason,
    bool Verified,
    bool RolledBack);

public sealed class HistoryService
{
    // Bounded log: rotated rather than left to grow forever (Section 63).
    private const int MaxEntries = 2000;
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = false };
    private readonly string directoryPath;
    // FIX 2.4: AppendSwitch/TrimIfNeeded/LoadRecent had no synchronization at
    // all. A manual switch and an Auto Pilot switch logging within the same
    // instant could interleave File.AppendAllText calls (or an append vs. a
    // TrimIfNeeded rewrite), throw, and silently lose that log line — this
    // is a static per-process lock since HistoryService is used from a
    // single process and each MainWindow-owned instance shares one file.
    private static readonly object FileLock = new();
    private string FilePath => Path.Combine(directoryPath, "switch-history.jsonl");

    // Optional override exists so the regression suite (BenchmarkLogicTests)
    // can exercise real file I/O against a throwaway directory instead of the
    // user's actual %LocalAppData%\NIMOXY switch-history.jsonl.
    public HistoryService(string? directoryOverride = null) =>
        directoryPath = directoryOverride ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NIMOXY");

    public void AppendSwitch(SwitchLogEntry entry)
    {
        try
        {
            lock (FileLock)
            {
                Directory.CreateDirectory(directoryPath);
                File.AppendAllText(FilePath, JsonSerializer.Serialize(entry, JsonOptions) + Environment.NewLine);
                TrimIfNeeded();
            }
        }
        catch
        {
            // Logging must never crash or block a real DNS switch — this is a
            // diagnostic aid, not something the apply/rollback path depends on.
        }
    }

    public IReadOnlyList<SwitchLogEntry> LoadRecent(int max = 300)
    {
        try
        {
            lock (FileLock)
            {
                if (!File.Exists(FilePath)) return Array.Empty<SwitchLogEntry>();
                var result = new List<SwitchLogEntry>();
                foreach (var line in File.ReadLines(FilePath).TakeLast(Math.Max(1, max)))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    try
                    {
                        var entry = JsonSerializer.Deserialize<SwitchLogEntry>(line, JsonOptions);
                        if (entry is not null) result.Add(entry);
                    }
                    catch
                    {
                        // Skip a single corrupt line rather than losing the whole
                        // history file to one bad write (e.g. a crash mid-append).
                    }
                }
                return result;
            }
        }
        catch { return Array.Empty<SwitchLogEntry>(); }
    }

    // FIX 7.2: previously this read the whole file and rewrote it in place
    // with File.WriteAllLines — if the process was killed mid-write, the
    // history file could be left truncated/corrupt. Write to a temp file
    // and atomically replace, which is what File.Replace/File.Move(overwrite)
    // guarantee on the same volume.
    private void TrimIfNeeded()
    {
        try
        {
            var lines = File.ReadAllLines(FilePath);
            if (lines.Length <= MaxEntries) return;
            var tmp = FilePath + ".tmp";
            File.WriteAllLines(tmp, lines.Skip(lines.Length - MaxEntries));
            File.Move(tmp, FilePath, overwrite: true);
        }
        catch
        {
            // Best-effort trim; a failure here should not affect the
            // already-successfully-applied DNS switch.
        }
    }
}
