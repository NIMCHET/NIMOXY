using System.Windows;
using System.Windows.Media;

namespace NIMOXY.Services;

public enum NimoxySound { Click, Hover, Confirm, Startup, Success, Failure, ScanStart, ScanComplete, AutoComplete, Connected, Winner, Warning }

/// <summary>Crash-safe UI audio. MediaPlayer is retained per effect so async media opening
/// cannot race Play(), and every audio failure is intentionally swallowed.</summary>
public sealed class SoundService : IDisposable
{
    private readonly AppSettings settings;
    private readonly Dictionary<NimoxySound, MediaPlayer> players = new();
    private readonly HashSet<NimoxySound> ready = new();
    private readonly object gate = new();
    private bool disposed;

    public SoundService(AppSettings settings) => this.settings = settings;

    public void Play(NimoxySound sound)
    {
        if (disposed || !settings.SoundsEnabled) return;
        try
        {
            System.Windows.Application.Current?.Dispatcher.BeginInvoke(new Action(() =>
            {
                try
                {
                    lock (gate)
                    {
                        if (disposed) return;
                        var player = GetPlayer(sound);
                        player.Volume = Math.Clamp(settings.Volume, 0, 1);
                        if (ready.Contains(sound))
                        {
                            player.Stop();
                            player.Position = TimeSpan.Zero;
                            player.Play();
                        }
                    }
                }
                catch { }
            }), System.Windows.Threading.DispatcherPriority.Background);
        }
        catch { }
    }

    private MediaPlayer GetPlayer(NimoxySound sound)
    {
        if (players.TryGetValue(sound, out var existing)) return existing;
        var name = sound switch
        {
            NimoxySound.Click => "frog-click.wav",
            NimoxySound.Hover => "ui-hover.wav",
            NimoxySound.Confirm => "ui-confirm.wav",
            NimoxySound.Startup => "frog-startup.wav",
            NimoxySound.Success => "frog-success.wav",
            NimoxySound.Failure => "frog-fail.wav",
            NimoxySound.ScanStart => "ui-start.wav",
            NimoxySound.ScanComplete => "frog-scan.wav",
            NimoxySound.AutoComplete => "frog-auto.wav",
            NimoxySound.Connected => "frog-connect.wav",
            NimoxySound.Winner => "frog-winner.wav",
            NimoxySound.Warning => "ui-warning.wav",
            _ => "frog-click.wav"
        };
        var p = new MediaPlayer();
        p.MediaOpened += (_, _) =>
        {
            try
            {
                lock (gate) ready.Add(sound);
                p.Volume = Math.Clamp(settings.Volume, 0, 1);
                p.Position = TimeSpan.Zero;
                p.Play();
            }
            catch { }
        };
        p.MediaFailed += (_, _) => { try { lock (gate) ready.Remove(sound); } catch { } };
        try { p.Open(new Uri($"pack://application:,,,/Assets/{name}", UriKind.Absolute)); } catch { }
        players[sound] = p;
        return p;
    }

    public void Dispose()
    {
        lock (gate)
        {
            disposed = true;
            foreach (var p in players.Values) { try { p.Close(); } catch { } }
            players.Clear();
            ready.Clear();
        }
    }
}
