namespace NIMOXY.Services;

/// <summary>
/// Implements master-prompt Section 62 (History / Trends) for a single
/// resolver's live probe stream: rolling median, EWMA, and a consecutive-
/// degradation counter derived from the EWMA baseline rather than from a
/// single instantaneous sample.
///
/// This exists specifically because the prompt calls out, in plain words:
/// "Auto Pilot باید فقط از یک sample تصمیم نگیرد" — Auto Pilot must not
/// decide from a single sample. Before this class, AutoPilotService's bad/
/// good classification compared one fresh probe latency against a resolver's
/// old static Deep Benchmark median, which is exactly a single-sample-driven
/// decision layered on stale data.
/// </summary>
public sealed class TrendTracker
{
    private readonly int maxWindow;
    private readonly double alpha;
    private readonly Queue<double> window;

    public double? Ewma { get; private set; }
    public int ConsecutiveDegraded { get; private set; }
    public int SampleCount => window.Count;

    public TrendTracker(int maxWindow = 20, double alpha = 0.35)
    {
        this.maxWindow = Math.Max(4, maxWindow);
        this.alpha = Math.Clamp(alpha, 0.05, 0.9);
        window = new Queue<double>(this.maxWindow);
    }

    public double? RollingMedian()
    {
        if (window.Count == 0) return null;
        var ordered = window.OrderBy(x => x).ToArray();
        return ordered[ordered.Length / 2];
    }

    /// <summary>
    /// Feed one fresh probe latency into the trend. relativeDegradationPct is
    /// the same "Relative degradation" setting Auto Pilot already exposes —
    /// reused here so there is exactly one knob for "how much worse than
    /// baseline counts as degraded", not two divergent ones.
    /// </summary>
    public void Add(double latencyMs, double relativeDegradationPct)
    {
        window.Enqueue(latencyMs);
        while (window.Count > maxWindow) window.Dequeue();

        var baseline = Ewma;
        // Only compare against a baseline formed from prior samples — the
        // very first reading can never itself be "degraded", by definition.
        var isDegraded = baseline is { } b && latencyMs > b * (1 + relativeDegradationPct / 100.0);

        // FIX 1.1: previously Ewma was updated with *every* sample, including
        // degraded ones. That let the "healthy baseline" itself drift toward
        // a sustained bad latency within ~4 samples, after which the same bad
        // latency stopped counting as degraded relative to its own drifted
        // baseline — ConsecutiveDegraded kept resetting to 0 and a sustained
        // DNS degradation (the exact case Auto Pilot exists for) was never
        // detected. The baseline must only be updated from non-degraded
        // samples, so it keeps representing "how this resolver performs when
        // healthy" instead of chasing whatever is happening right now.
        if (isDegraded)
        {
            ConsecutiveDegraded++;
        }
        else
        {
            ConsecutiveDegraded = 0;
            Ewma = baseline is null ? latencyMs : alpha * latencyMs + (1 - alpha) * baseline.Value;
        }
    }

    public void Reset()
    {
        window.Clear();
        Ewma = null;
        ConsecutiveDegraded = 0;
    }
}
