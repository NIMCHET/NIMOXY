using NIMOXY.Models;

namespace NIMOXY.Services;

public enum AutoPilotState { Stopped, Starting, Healthy, Degraded, Verifying, Searching, CandidateFound, VerifyingCandidate, Switching, Switched, Cooldown, Recovering, Paused, Error }
public sealed record AutoPilotEvent(AutoPilotState State, string Message, DnsResolver? Current, DnsResolver? Candidate, FastProbeResult? Probe);

public sealed class AutoPilotService
{
    private readonly AppSettings settings;
    private readonly FastProbeService fast;
    // FIX (gaming-safety gap found during forensic review): see
    // GameDetectionService's own doc comment. Gates only the heavy,
    // full-catalog candidate search below -- the cheap single-probe health
    // check on the current DNS still runs every cycle either way.
    private readonly GameDetectionService gameDetection;
    private readonly SemaphoreSlim gate = new(1, 1);
    private CancellationTokenSource? loopCts;
    private Task? loopTask;

    // FIX 1.4: Start()/Stop()/Pause()/Resume() can be called back-to-back
    // from the UI thread (user toggles the checkbox quickly). Stop() used to
    // cancel the old token and return immediately without waiting for the old
    // LoopAsync body to actually observe the cancellation and exit, so a
    // fast Start() right after could have two LoopAsync instances alive at
    // once, both mutating consecutiveBad/currentTrend/lastSwitch. `epoch` is
    // a monotonically increasing generation counter: a loop instance checks
    // it belongs to the current epoch before running, and a new Start()
    // always awaits the previous loop's real completion first.
    private long epoch;

    private int consecutiveBad;
    private DateTimeOffset lastSwitch = DateTimeOffset.MinValue;
    private DateTimeOffset holdUntil = DateTimeOffset.MinValue;
    // Section 62: trend state for whichever DNS is currently active. Reset on
    // every switch/start so a new resolver is judged on its own live samples,
    // never on the trend of the resolver it replaced.
    private TrendTracker currentTrend = new();
    private string? trendedIp;
    public AutoPilotState State { get; private set; } = AutoPilotState.Stopped;
    // FIX 1.5: distinct from "Stopped" so the UI can tell "operator turned
    // Auto Pilot off" apart from "operator paused it and can resume".
    public bool IsPaused { get; private set; }
    public event Action<AutoPilotEvent>? Changed;

    // FIX 1.5: remembered so Resume() can restart the loop without the
    // caller re-supplying every delegate — Pause/Resume must be a genuinely
    // separate code path from Stop/Start (Section 66), not a relabeling of it.
    private Func<CancellationToken, Task<DnsResolver?>>? chooseReplacementFn;
    private Func<DnsResolver, DnsResolver?, CancellationToken, Task<SwitchOutcome>>? switchVerifiedFn;
    private Func<Task<DnsResolver?>>? getCurrentFn;
    private Func<IEnumerable<DnsResolver>>? getFallbacksFn;

    public AutoPilotService(AppSettings settings, FastProbeService fast)
        : this(settings, fast, new GameDetectionService(settings)) { }

    // Test/DI entry point: lets the regression suite supply a GameDetectionService
    // built with a fake process-name provider instead of the real Windows process
    // list, so "a game is running" vs. "it is not" is deterministic in tests.
    public AutoPilotService(AppSettings settings, FastProbeService fast, GameDetectionService gameDetection)
    {
        this.settings = settings;
        this.fast = fast;
        this.gameDetection = gameDetection;
    }

    // FIX (gaming-safety gap): the only three places in LoopAsync that
    // invoke a full multi-candidate search across the catalog. A detected
    // game/launcher process defers the search for this cycle instead of
    // running it -- Auto Pilot tries again on its next scheduled tick, same
    // as when a manual operation is holding operationGate (see MainWindow's
    // AutoPilotChooseReplacementAsync). Returning a tuple rather than an
    // out/ref parameter because this method is async (see FastProbeService's
    // ClientSlot comment for why C# disallows ref/out on async methods).
    private async Task<(DnsResolver? candidate, bool deferredForGaming)> ChooseReplacementGameSafeAsync(
        Func<CancellationToken, Task<DnsResolver?>> chooseReplacement, CancellationToken ct)
    {
        if (settings.GamingSafeModeEnabled && gameDetection.IsGameLikelyRunning())
            return (null, true);
        return (await chooseReplacement(ct), false);
    }

    public void Start(Func<CancellationToken, Task<DnsResolver?>> chooseReplacement, Func<DnsResolver, DnsResolver?, CancellationToken, Task<SwitchOutcome>> switchVerified, Func<Task<DnsResolver?>> getCurrent, Func<IEnumerable<DnsResolver>> getFallbacks)
    {
        chooseReplacementFn = chooseReplacement;
        switchVerifiedFn = switchVerified;
        getCurrentFn = getCurrent;
        getFallbacksFn = getFallbacks;
        IsPaused = false;
        StartLoop();
    }

    /// <summary>
    /// FIX 1.5: Pause actually halts the loop while remembering the
    /// delegates, so Resume() can bring it back exactly where Stop()/Start()
    /// would not (Start() from scratch has no memory of "was running before").
    /// Previously Pause() existed but was never called from anywhere in the
    /// app — the UI's "PAUSE" button called Stop() instead.
    /// </summary>
    public void Pause()
    {
        if (State == AutoPilotState.Stopped) return; // never started; nothing to pause
        Interlocked.Increment(ref epoch);
        try { loopCts?.Cancel(); } catch { }
        loopCts = null;
        IsPaused = true;
        State = AutoPilotState.Paused;
        Raise("Auto Pilot paused.");
    }

    public void Resume()
    {
        if (!IsPaused) return;
        if (chooseReplacementFn is null || switchVerifiedFn is null || getCurrentFn is null || getFallbacksFn is null) return;
        IsPaused = false;
        StartLoop();
    }

    public void Stop()
    {
        Interlocked.Increment(ref epoch);
        try { loopCts?.Cancel(); } catch { }
        loopCts = null;
        IsPaused = false;
        State = AutoPilotState.Stopped;
    }

    private void StartLoop()
    {
        var myEpoch = Interlocked.Increment(ref epoch);
        var previous = loopTask;
        try { loopCts?.Cancel(); } catch { }
        var cts = new CancellationTokenSource();
        loopCts = cts;
        loopTask = RunAfterPreviousAsync(previous, myEpoch, cts.Token);
    }

    private async Task RunAfterPreviousAsync(Task? previous, long myEpoch, CancellationToken ct)
    {
        if (previous is not null)
        {
            // Let a superseded loop instance actually finish before this one
            // starts touching shared state — see the `epoch` comment above.
            try { await previous.ConfigureAwait(false); } catch { }
        }
        if (myEpoch != Interlocked.Read(ref epoch)) return; // superseded again while we waited
        await LoopAsync(chooseReplacementFn!, switchVerifiedFn!, getCurrentFn!, getFallbacksFn!, myEpoch, ct);
    }

    private async Task LoopAsync(Func<CancellationToken, Task<DnsResolver?>> chooseReplacement, Func<DnsResolver, DnsResolver?, CancellationToken, Task<SwitchOutcome>> switchVerified, Func<Task<DnsResolver?>> getCurrent, Func<IEnumerable<DnsResolver>> getFallbacks, long myEpoch, CancellationToken ct)
    {
        State = AutoPilotState.Starting; Raise("Auto Pilot started.");
        var firstCycle = true;
        // FIX 12: this outer try/catch used to wrap the entire while loop, so
        // a single unexpected exception on any one cycle (a probe throwing
        // something other than the exceptions FastProbeService already
        // catches, a transient null reference, etc.) set State=Error and then
        // fell out of the loop for good — Auto Pilot silently stopped
        // protecting the connection forever, while the UI checkbox still
        // showed it as "on". A bad cycle must be reported and skipped, not
        // treated as fatal; only real cancellation should end the loop.
        while (!ct.IsCancellationRequested && myEpoch == Interlocked.Read(ref epoch))
        {
            try { await gate.WaitAsync(ct); }
            catch (OperationCanceledException) { break; }
            try
            {
                try
                {
                    var current = await getCurrent();
                    if (current is null)
                    {
                        State = AutoPilotState.Searching; Raise("No manually configured DNS detected; searching verified candidates.");
                        var (candidate, deferredNoDns) = await ChooseReplacementGameSafeAsync(chooseReplacement, ct);
                        if (deferredNoDns)
                        {
                            State = AutoPilotState.Recovering; Raise("Game detected; deferring the no-DNS candidate search this cycle to avoid impacting your session.");
                        }
                        else if (candidate is not null && await VerifyCandidate(candidate, ct))
                        {
                            State = AutoPilotState.Switching; Raise($"Verified candidate {candidate.Ip} found; applying.", null, candidate);
                            var outcome = await switchVerified(candidate, null, ct);
                            if (outcome.Verified)
                            {
                                lastSwitch = DateTimeOffset.UtcNow; holdUntil = DateTimeOffset.UtcNow.AddMinutes(settings.AutoPilotMinimumHoldMinutes); consecutiveBad = 0;
                                State = AutoPilotState.Switched; Raise($"DNS switched to verified candidate {candidate.Ip}.", candidate);
                            }
                            else
                            {
                                // FIX 1.3: switchVerified applies, verifies, and rolls back
                                // internally on failure. That must be reported to the
                                // operator (Section 50/51), not leave a stale "Switching"
                                // state on screen with no explanation.
                                // FIX 4.3: the message now reflects what actually happened
                                // during rollback instead of always asserting success.
                                State = AutoPilotState.Degraded; Raise(RollbackMessage(outcome), current, candidate);
                            }
                        }
                    }
                    else
                    {
                        var probe = await fast.ProbeAsync(current.Ip, settings.AutoPilotProbeDomain, ct);
                        if (trendedIp != current.Ip) { currentTrend.Reset(); trendedIp = current.Ip; }
                        if (probe.Success)
                        {
                            currentTrend.Add(probe.LatencyMs, settings.AutoPilotRelativeDegradationPct);
                            var bad = IsBad(current, probe.LatencyMs);
                            if (!bad)
                            {
                                consecutiveBad = 0;
                                State = AutoPilotState.Healthy;
                                Raise($"Current DNS {current.Ip} is healthy.", current, null, probe);
                                // First Auto Pilot cycle: actively benchmark the current Top 5 in parallel
                                // and allow a verified, meaningfully-better resolver to win immediately.
                                if (firstCycle)
                                {
                                    firstCycle = false;
                                    State = AutoPilotState.Searching;
                                    Raise("Initial Auto Pilot optimization: testing Top 5 DNS servers.", current);
                                    var (candidate, deferredInitial) = await ChooseReplacementGameSafeAsync(chooseReplacement, ct);
                                    if (deferredInitial)
                                    {
                                        State = AutoPilotState.Recovering;
                                        Raise("Game detected; deferring the initial Top 5 optimization to avoid impacting your session.", current);
                                    }
                                    else if (candidate is not null && !candidate.Ip.Equals(current.Ip, StringComparison.OrdinalIgnoreCase) && IsMeaningfullyBetter(current, candidate) && await VerifyCandidate(candidate, ct))
                                    {
                                        State = AutoPilotState.Switching;
                                        Raise($"Top 5 selected {candidate.Ip} as a verified improvement; applying.", current, candidate);
                                        var initialOutcome = await switchVerified(candidate, current, ct);
                                        if (initialOutcome.Verified)
                                        {
                                            lastSwitch = DateTimeOffset.UtcNow;
                                            holdUntil = lastSwitch.AddMinutes(settings.AutoPilotMinimumHoldMinutes);
                                            consecutiveBad = 0;
                                            State = AutoPilotState.Switched;
                                            Raise($"Initial Auto Pilot optimization switched to {candidate.Ip}.", candidate);
                                        }
                                        else
                                        {
                                            State = AutoPilotState.Degraded;
                                            Raise(RollbackMessage(initialOutcome), current, candidate);
                                        }
                                    }
                                    else
                                    {
                                        State = AutoPilotState.Healthy;
                                        Raise("Current DNS remains best enough after Top 5 verification.", current);
                                    }
                                }
                            }
                            else
                            {
                                consecutiveBad++;
                                State = AutoPilotState.Degraded; Raise($"Current DNS {current.Ip} is degraded ({probe.LatencyMs:F1} ms).", current, null, probe);
                                if (consecutiveBad >= Math.Clamp(settings.AutoPilotBadChecks, 1, 10) && DateTimeOffset.UtcNow >= holdUntil && DateTimeOffset.UtcNow >= lastSwitch.AddSeconds(Math.Max(0, settings.AutoPilotCooldownSeconds)))
                                {
                                    State = AutoPilotState.Verifying; Raise("Degradation confirmed; evaluating alternatives.", current, null, probe);
                                    var (candidate, deferredDegraded) = await ChooseReplacementGameSafeAsync(chooseReplacement, ct);
                                    if (deferredDegraded)
                                    {
                                        State = AutoPilotState.Recovering; Raise("Game detected; deferring candidate search this cycle to avoid impacting your session.", current);
                                    }
                                    else if (candidate is not null && IsMeaningfullyBetter(current, candidate) && await VerifyCandidate(candidate, ct))
                                    {
                                        State = AutoPilotState.CandidateFound; Raise($"Candidate {candidate.Ip} is meaningfully better; final verification passed.", current, candidate);
                                        State = AutoPilotState.Switching;
                                        var switchOutcome = await switchVerified(candidate, current, ct);
                                        if (switchOutcome.Verified)
                                        {
                                            lastSwitch = DateTimeOffset.UtcNow; holdUntil = lastSwitch.AddMinutes(settings.AutoPilotMinimumHoldMinutes); consecutiveBad = 0; State = AutoPilotState.Switched; Raise($"Switched from {current.Ip} to {candidate.Ip}.", candidate);
                                        }
                                        else
                                        {
                                            State = AutoPilotState.Degraded; Raise(RollbackMessage(switchOutcome), current, candidate);
                                        }
                                    }
                                    else { State = AutoPilotState.Recovering; Raise("No verified replacement was better enough; keeping current DNS.", current); }
                                }
                            }
                        }
                        else
                        {
                            consecutiveBad++;
                            State = AutoPilotState.Degraded; Raise($"Current DNS {current.Ip} did not answer ({probe.Status}).", current, null, probe);
                            if (consecutiveBad >= Math.Clamp(settings.AutoPilotBadChecks, 1, 10) && DateTimeOffset.UtcNow >= holdUntil)
                            {
                                var fallback = getFallbacks().FirstOrDefault(x => !x.Ip.Equals(current.Ip, StringComparison.OrdinalIgnoreCase));
                                if (fallback is not null && await VerifyCandidate(fallback, ct))
                                {
                                    State = AutoPilotState.Switching; Raise($"Current DNS failed repeatedly; verified fallback {fallback.Ip} is ready.", current, fallback);
                                    var fallbackOutcome = await switchVerified(fallback, current, ct);
                                    if (fallbackOutcome.Verified) { lastSwitch = DateTimeOffset.UtcNow; holdUntil = lastSwitch.AddMinutes(settings.AutoPilotMinimumHoldMinutes); consecutiveBad = 0; State = AutoPilotState.Switched; Raise($"Recovered on fallback {fallback.Ip}.", fallback); }
                                    else { State = AutoPilotState.Degraded; Raise(RollbackMessage(fallbackOutcome), current, fallback); }
                                }
                                else
                                {
                                    State = AutoPilotState.Searching; Raise("Current DNS failed; searching for a verified replacement.", current);
                                    var (candidate, deferredFailed) = await ChooseReplacementGameSafeAsync(chooseReplacement, ct);
                                    if (deferredFailed)
                                    {
                                        State = AutoPilotState.Recovering; Raise("Game detected; deferring candidate search this cycle to avoid impacting your session.", current);
                                    }
                                    else if (candidate is not null && await VerifyCandidate(candidate, ct))
                                    {
                                        var searchOutcome = await switchVerified(candidate, current, ct);
                                        if (searchOutcome.Verified)
                                        {
                                            // FIX 1.2: this fourth switch path used to be the only one
                                            // that did NOT update lastSwitch/holdUntil/consecutiveBad/
                                            // State on a successful switch. That meant the very next
                                            // cycle (one AutoPilotIntervalSeconds later) could switch
                                            // again immediately with no cooldown/hold at all — exactly
                                            // the flapping Section 17 exists to prevent.
                                            lastSwitch = DateTimeOffset.UtcNow; holdUntil = lastSwitch.AddMinutes(settings.AutoPilotMinimumHoldMinutes); consecutiveBad = 0;
                                            State = AutoPilotState.Switched; Raise($"Switched to verified replacement {candidate.Ip}.", candidate);
                                        }
                                        else
                                        {
                                            State = AutoPilotState.Degraded; Raise(RollbackMessage(searchOutcome), current, candidate);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    // Report and keep looping — one bad cycle no longer ends
                    // Auto Pilot protection for the rest of the session.
                    State = AutoPilotState.Error; Raise("Auto Pilot recovered from an internal error: " + ex.Message);
                }
            }
            finally { gate.Release(); }
            var delay = State is AutoPilotState.Degraded or AutoPilotState.Recovering or AutoPilotState.Error
                ? TimeSpan.FromMilliseconds(100)
                : TimeSpan.FromSeconds(1);
            try { await Task.Delay(delay, ct); }
            catch (OperationCanceledException) { break; }
        }
    }

    private async Task<bool> VerifyCandidate(DnsResolver c, CancellationToken ct)
    {
        State = AutoPilotState.VerifyingCandidate; Raise($"Verifying {c.Ip} before any switch.", null, c);
        var attempts = Math.Clamp(settings.AutoPilotCandidateVerificationProbes, 2, 5);
        var samples = new List<double>();
        for (var i = 0; i < attempts; i++)
        {
            var p = await fast.ProbeAsync(c.Ip, settings.AutoPilotProbeDomain, ct);
            if (p.Success) samples.Add(p.LatencyMs);
        }
        if (samples.Count == 0) return false;
        // Section 60: this is a pass/fail gate before switching, not a
        // replacement for the resolver's real Deep Benchmark statistics.
        // AvgMs/MedianMs/P95Ms/LossPct/SampleCount/Confidence are deliberately
        // left untouched here so a resolver's genuine measurement history —
        // possibly hundreds of samples — is never silently overwritten by 2-5
        // verification pings. Only the presentational Status label reflects
        // that verification happened.
        c.Status = "Verified";
        var verificationLossPct = 100.0 * (attempts - samples.Count) / attempts;
        return verificationLossPct <= settings.AutoPilotMaxCandidateLossPct;
    }
    private bool IsBad(DnsResolver current, double latency)
    {
        // Absolute threshold on the live sample is still checked instantly —
        // a genuinely terrible single ping is worth noting. But turning that
        // into "degraded" for switching purposes additionally requires the
        // EWMA-based trend to show consecutive degradation, per Section 62:
        // Auto Pilot must not decide from a single sample.
        var absoluteBad = latency >= settings.AutoPilotLatencyThresholdMs;
        var trendBad = currentTrend.ConsecutiveDegraded >= 2;
        return absoluteBad && trendBad;
    }
    private bool IsMeaningfullyBetter(DnsResolver current, DnsResolver candidate)
    {
        var currentScore = current.GamingScore > 0 ? current.GamingScore : current.Score;
        var candidateScore = candidate.GamingScore > 0 ? candidate.GamingScore : candidate.Score;
        var latencyBetter = double.IsNaN(current.MedianMs) || candidate.MedianMs <= current.MedianMs * (1 - settings.AutoPilotMinimumImprovementPct / 100.0);
        var scoreBetter = candidateScore >= currentScore + settings.AutoPilotMinimumScoreImprovement;
        return latencyBetter || scoreBetter;
    }
    // FIX 4.3: previously every failed-switch message unconditionally said
    // "Previous configuration restored" whether or not that was true. This
    // reports the real SwitchOutcome from ApplyResolverAsync's rollback path.
    private static string RollbackMessage(SwitchOutcome outcome) =>
        !outcome.RolledBack
            ? "DNS switch verification failed."
            : outcome.RollbackVerified
                ? "DNS switch verification failed. Previous configuration restored and verified."
                : "DNS switch verification failed. Rollback was attempted but could not be verified — check the network connection manually.";
    private void Raise(string message, DnsResolver? current = null, DnsResolver? candidate = null, FastProbeResult? probe = null) => Changed?.Invoke(new(State, message, current, candidate, probe));
}
