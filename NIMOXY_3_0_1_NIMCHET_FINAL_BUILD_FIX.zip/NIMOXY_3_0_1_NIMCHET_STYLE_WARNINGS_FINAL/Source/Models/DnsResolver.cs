namespace NIMOXY.Models;

public sealed class DnsResolver
{
    public string Ip { get; set; } = "";
    public string Provider { get; set; } = "Unknown";
    public string Country { get; set; } = "";
    public string Use { get; set; } = "Public DNS";
    public bool Trusted { get; set; }
    public bool DnsSec { get; set; }
    public bool Edns { get; set; }
    public double AvgMs { get; set; } = double.NaN;
    public double MedianMs { get; set; } = double.NaN;
    public double P95Ms { get; set; } = double.NaN;
    public double P99Ms { get; set; } = double.NaN;
    public double JitterMs { get; set; } = double.NaN;
    public double LossPct { get; set; } = 100;
    public double Score { get; set; }
    public double GamingScore { get; set; }
    public double GamingCoveragePct { get; set; }
    // Section 61: shown next to Sample Count in the UI, driven only by sample
    // count and measurement consistency — never a hardcoded/random label.
    public string Confidence { get; set; } = "LOW";
    public string Status { get; set; } = "Not tested";
    public int SampleCount { get; set; }
    public bool DeepTested { get; set; }
    public int ConsecutiveFailures { get; set; }
    // Section 5: dead/unstable endpoints must be temporarily retired from the
    // active pool (never permanently deleted) so a false negative can recover
    // on a later recheck.
    public bool Retired { get; set; }
    public DateTimeOffset? RetiredAt { get; set; }
    public DateTimeOffset? LastChecked { get; set; }
    public DateTimeOffset? LastSuccessful { get; set; }
    public string Source { get; set; } = "Built-in";
    public string Icon { get; set; } = "🐸";
}
