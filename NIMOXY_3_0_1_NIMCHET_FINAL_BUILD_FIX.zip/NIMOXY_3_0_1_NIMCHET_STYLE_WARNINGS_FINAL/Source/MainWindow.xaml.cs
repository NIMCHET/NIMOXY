using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Forms = System.Windows.Forms;
using WpfButton = System.Windows.Controls.Button;
using MediaColor = System.Windows.Media.Color;
using WpfPoint = System.Windows.Point;
using MediaBrush = System.Windows.Media.Brush;
using NIMOXY.Models;
using NIMOXY.Services;

namespace NIMOXY;

public partial class MainWindow : Window
{
    private readonly AppSettings settings = App.Settings;
    private readonly CatalogService catalog = new();
    private readonly BenchmarkService benchmark;
    private readonly FastProbeService fast;
    private readonly AutoPilotService autoPilot;
    private readonly DnsApplyService dnsApply = new();
    private readonly RetirementService retirement;
    private readonly HistoryService history = new();
    private readonly DnsStateStore dnsState = new();
    private readonly SoundService sounds;
    private readonly ObservableCollection<Row> rows = new();
    private readonly Queue<double> graphSamples = new();
    private readonly SemaphoreSlim operationGate = new(1, 1);
    private readonly SemaphoreSlim applyGate = new(1, 1);
    private CancellationTokenSource? operationCts;
    private List<DnsResolver> catalogData = new();
    private string? connectedDns;
    private bool allowClose;
    private Forms.NotifyIcon? tray;
    private LinearGradientBrush? nimchetNeonBrush;
    private TranslateTransform? nimchetNeonTransform;
    private DateTime lastUiUpdate = DateTime.MinValue;
    private int operationTotal, operationDone, operationSuccess, operationFailed;
    private Stopwatch? operationWatch;
    // Section 9 (Critical Test Completion Integrity): the authoritative source
    // of truth for whether an operation may claim COMPLETE. operationDone/
    // operationSuccess/operationFailed above remain for the fast live counter
    // UI, but the final verdict always comes from opTracker.Reconcile().
    private OperationTracker? opTracker;

    public MainWindow()
    {
        InitializeComponent();
        StartNimchetNeon();
        benchmark = new BenchmarkService(settings);
        fast = new FastProbeService(settings);
        retirement = new RetirementService(settings);
        autoPilot = new AutoPilotService(settings, fast);
        sounds = new SoundService(settings);
        Grid.ItemsSource = rows;
        ThemeBtn.Content = settings.Theme == "Light" ? "☀ LIGHT" : "🌙 DARK";
        SoundBtn.Content = settings.SoundsEnabled ? "🔊 FX ON" : "🔇 FX OFF";
        // Section 12 names five official gaming profiles; read them from the
        // single source of truth (AppSettings.OfficialGamingProfiles) instead
        // of a hand-copied array, so the combo box can never again drift out
        // of sync with what GetGamingDomainsForProfile() actually supports.
        AutoCheck.IsChecked = settings.AutoPilotEnabled;
        // Keep the Windows Run-key state in sync with the persisted setting on
        // every launch. This is a per-user registry write (no elevation
        // needed) and is idempotent, so it is always safe to re-apply.
        StartupBtn.Content = settings.StartWithWindows ? "🚀 STARTUP ON" : "🚀 STARTUP OFF";
        autoPilot.Changed += OnAutoPilotChanged;
        Loaded += async (_, _) =>
        {
            // Startup is deliberately staged. The first frame must be the real
            // UI, with no splash/overlay and no tray/registry/network work in
            // the constructor. Optional integrations are isolated so one bad
            // integration cannot blank/crash the main window.
            try { ThemeService.Apply(settings.Theme); } catch { }
            try { AppStartupService.SetEnabled(settings.StartWithWindows); } catch { }
            try { CreateTray(); } catch { }

            // Always present the main UI on a normal launch. The tray/minimized
            // behavior can still be used after the window is running, but a
            // stale settings.json must never make the first frame disappear.
            await InitializeAsync();
        };
    }
    private void StartNimchetNeon()
    {
        try
        {
            nimchetNeonBrush = new LinearGradientBrush(
                new GradientStopCollection
                {
                    new GradientStop(MediaColor.FromRgb(255, 77, 0), 0.00),
                    new GradientStop(MediaColor.FromRgb(255, 23, 68), 0.32),
                    new GradientStop(MediaColor.FromRgb(255, 138, 0), 0.50),
                    new GradientStop(MediaColor.FromRgb(255, 23, 68), 0.68),
                    new GradientStop(MediaColor.FromRgb(255, 77, 0), 1.00)
                }, 0);
            nimchetNeonBrush.StartPoint = new WpfPoint(0, 0.5);
            nimchetNeonBrush.EndPoint = new WpfPoint(1, 0.5);
            nimchetNeonTransform = new TranslateTransform(-1.2, 0);
            nimchetNeonBrush.RelativeTransform = nimchetNeonTransform;
            NimchetWatermarkName.Foreground = nimchetNeonBrush;
            NimchetWatermarkPhone.Foreground = nimchetNeonBrush;
            nimchetNeonTransform.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(-1.2, 1.2, TimeSpan.FromSeconds(2.4))
            {
                AutoReverse = true,
                RepeatBehavior = RepeatBehavior.Forever
            });
        }
        catch { }
    }

    private void Startup_Click(object s, RoutedEventArgs e)
    {
        settings.StartWithWindows = !settings.StartWithWindows;
        var applied = AppStartupService.SetEnabled(settings.StartWithWindows);
        if (!applied)
        {
            // Do not claim a state change that did not actually happen
            // (Section 69: no fake feature status).
            settings.StartWithWindows = !settings.StartWithWindows;
            ReportRecoverableError(new InvalidOperationException("Could not update the Windows startup entry."));
            return;
        }
        settings.Save();
        StartupBtn.Content = settings.StartWithWindows ? "🚀 STARTUP ON" : "🚀 STARTUP OFF";
        sounds.Play(NimoxySound.Confirm);
    }

    private async Task InitializeAsync()
    {
        try
        {
            LoadAdapters();
            catalogData = await catalog.LoadGlobalAsync();
            RestorePersistedDnsState();
            CatalogStats.Text = $"{catalogData.Count:N0} resolvers • global IPv4/IPv6 catalog";
            await RefreshConnectedDnsAsync();
            UpdateFallbacks();
            if (settings.StartupSound) sounds.Play(NimoxySound.Startup);
            if (settings.AutoPilotEnabled) StartAutoPilot();
            _ = RefreshCatalogInBackground();
            FooterText.Text = $"✓ {catalogData.Count:N0} DNS loaded • verified-first • no telemetry • v3.0.1";
        }
        catch (Exception ex) { ReportRecoverableError(ex); }
    }

    private void CreateTray()
    {
        tray = new Forms.NotifyIcon { Icon = System.Drawing.Icon.ExtractAssociatedIcon(Environment.ProcessPath ?? System.Windows.Forms.Application.ExecutablePath) ?? System.Drawing.SystemIcons.Application, Visible = true, Text = "NIMOXY • DNS Optimizer" };
        tray.MouseDoubleClick += (_, _) => ShowFromTray();
        var menu = new Forms.ContextMenuStrip();
        menu.Items.Add("Open NIMOXY", null, (_, _) => ShowFromTray());
        menu.Items.Add("Auto Pilot: ON / OFF", null, (_, _) => { AutoCheck.IsChecked = !AutoCheck.IsChecked; });
        menu.Items.Add("Find Better DNS", null, (_, _) => _ = RunScoutAsync(true));
        menu.Items.Add("Switch to Next Verified Server", null, (_, _) => _ = SwitchFallbackAsync());
        menu.Items.Add("Flush DNS Cache", null, (_, _) => _ = FlushAsync());
        menu.Items.Add("Open Settings", null, (_, _) => Settings_Click(this, new RoutedEventArgs()));
        menu.Items.Add("Exit NIMOXY", null, (_, _) => { tray.Visible = false; RequestExit(); });
        tray.ContextMenuStrip = menu;
    }
    private void ShowFromTray() { Show(); WindowState = WindowState.Normal; Activate(); }
    // FIX 9: Section 22 defines a 9-stage shutdown sequence whose stage 3 is
    // "Await bounded tasks" — in-flight probes/benchmarks/applies must get a
    // bounded window to unwind through their own cancellation + finally block
    // (which releases operationGate/applyGate) before we tear down the tray
    // icon, sound engine, and any open sockets out from under them. The old
    // code cancelled and disposed in the same synchronous tick, so a running
    // operation was killed mid-flight instead of allowed to wind down.
    private bool shutdownDrainStarted;

    private void RequestExit()
    {
        if (shutdownDrainStarted) return;
        shutdownDrainStarted = true;
        _ = FinishShutdownAsync();
    }

    private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (allowClose) return;
        // The window close button/Alt+F4 only hides the UI. The process remains
        // alive in the notification area; actual process exit is exposed only
        // through the tray menu's explicit "Exit NIMOXY" command.
        e.Cancel = true;
        Hide();
    }

    private void Minimize_Click(object? sender, RoutedEventArgs e)
    {
        Hide();
    }

    private void Maximize_Click(object? sender, RoutedEventArgs e)
    {
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        MaximizeBtn.Content = WindowState == WindowState.Maximized ? "❐" : "□";
    }

    private void Window_StateChanged(object? sender, EventArgs e)
    {
        if (MaximizeBtn is not null)
            MaximizeBtn.Content = WindowState == WindowState.Maximized ? "❐" : "□";
    }

    private void CloseToTray_Click(object? sender, RoutedEventArgs e)
    {
        Hide();
    }

    private async Task FinishShutdownAsync()
    {
        try { operationCts?.Cancel(); } catch { }
        try { autoPilot.Stop(); } catch { }

        // Bounded wait, not indefinite: give any in-flight operation a chance
        // to observe cancellation and release its gate, but never hang the
        // app shutdown on a stuck probe/socket.
        var bound = TimeSpan.FromSeconds(3);
        try { if (await operationGate.WaitAsync(bound)) operationGate.Release(); } catch { }
        try { if (await applyGate.WaitAsync(bound)) applyGate.Release(); } catch { }

        try { tray?.Dispose(); } catch { }
        try { sounds.Dispose(); } catch { }

        allowClose = true;
        await Dispatcher.InvokeAsync(Close);
    }
    // FIX 0.1: was `private`, which App.xaml.cs (a different class) cannot call —
    // that was a hard CS0122 compile error, so the whole project never built.
    internal void ReportRecoverableError(Exception ex)
    {
        SetStatusColor("error");
        OperationText.Text = "🔴 ERROR • NIMOXY stayed running";
        OperationStats.Text = ex.Message.Length > 160 ? ex.Message[..160] + "…" : ex.Message;
        try { sounds.Play(NimoxySound.Warning); } catch { }
    }
    private void Button_MouseEnter(object? s, System.Windows.Input.MouseEventArgs e) { try { sounds.Play(NimoxySound.Hover); } catch { } }
    private void Sound_Click(object s, RoutedEventArgs e) { settings.SoundsEnabled = !settings.SoundsEnabled; settings.Save(); SoundBtn.Content = settings.SoundsEnabled ? "🔊 FX ON" : "🔇 FX OFF"; if (settings.SoundsEnabled) sounds.Play(NimoxySound.Confirm); }
    private void Theme_Click(object s, RoutedEventArgs e) { settings.Theme = settings.Theme == "Light" ? "Dark" : "Light"; settings.Save(); ThemeService.Apply(settings.Theme); ThemeBtn.Content = settings.Theme == "Light" ? "☀ LIGHT" : "🌙 DARK"; sounds.Play(NimoxySound.Confirm); }
    private void Settings_Click(object s, RoutedEventArgs e)
    {
        System.Windows.MessageBox.Show($"NIMOXY Settings\n\nAuto Pilot: {(settings.AutoPilotEnabled ? "ON" : "OFF")}\nInterval: {settings.AutoPilotIntervalSeconds}s\nLatency threshold: {settings.AutoPilotLatencyThresholdMs} ms\nRelative degradation: {settings.AutoPilotRelativeDegradationPct:F0}%\nRequired improvement: {settings.AutoPilotMinimumImprovementPct:F0}%\nBad checks: {settings.AutoPilotBadChecks}\nHold: {settings.AutoPilotMinimumHoldMinutes} min\nCooldown: {settings.AutoPilotCooldownSeconds}s\nFast timeout: {settings.FastProbeTimeoutMs} ms\nDeep timeout: {settings.TimeoutMs} ms\nConcurrency: {settings.BenchmarkConcurrency}\nCatalog refresh: {settings.CatalogRefreshHours}h\nDead DNS recheck: {settings.DeadResolverRetestHours}h\n\nConfiguration file: %LOCALAPPDATA%\\NIMOXY\\settings.json", "NIMOXY • Advanced Settings", MessageBoxButton.OK, MessageBoxImage.Information);
    }
    private void Window_KeyDown(object s, System.Windows.Input.KeyEventArgs e) { if (e.Key == Key.F5) { e.Handled = true; _ = RunScoutAsync(false); } else if (e.Key == Key.F8) { e.Handled = true; _ = RunGamingAsync(); } else if (e.Key == Key.T && Keyboard.Modifiers == ModifierKeys.Control) { e.Handled = true; Theme_Click(this, new RoutedEventArgs()); } }
    private void Adapter_Changed(object s, System.Windows.Controls.SelectionChangedEventArgs e) { if (IsLoaded) _ = RefreshConnectedDnsAsync(); }
    private void LoadAdapters()
    {
        AdapterCombo.Items.Clear(); foreach (var x in dnsApply.GetActiveInterfaces()) AdapterCombo.Items.Add(x);
        if (AdapterCombo.Items.Count > 0) AdapterCombo.SelectedIndex = 0;
    }
    private async Task RefreshConnectedDnsAsync()
    {
        if (AdapterCombo.SelectedItem is not string adapter) return;
        try
        {
            var list = await dnsApply.GetCurrentDnsAsync(adapter, AddressFamily.InterNetwork);
            if (list.Count == 0) list = await dnsApply.GetCurrentDnsAsync(adapter, AddressFamily.InterNetworkV6);
            connectedDns = list.FirstOrDefault();
            CurrentDnsText.Text = connectedDns ?? "DHCP / UNKNOWN";
            CurrentStatusText.Text = connectedDns is null ? "Automatic DNS" : "Configured on Windows";
            UpdateFallbacks();
        }
        catch (Exception ex) { ReportRecoverableError(ex); }
    }
    private void UpdateFallbacks()
    {
        var best = catalogData.Where(x => x.Status is "Verified" or "Healthy" or "Stable" && !x.Ip.Equals(connectedDns, StringComparison.OrdinalIgnoreCase) && x.SampleCount > 0)
            .OrderByDescending(x => settings.GamingMode ? x.GamingScore : x.Score).ThenBy(x => x.P95Ms).Take(2).ToArray();
        Fallback1Text.Text = best.ElementAtOrDefault(0)?.Ip ?? "—"; Fallback1Meta.Text = best.ElementAtOrDefault(0) is { } a ? $"{a.MedianMs:F1} ms • verified" : "Not verified";
        Fallback2Text.Text = best.ElementAtOrDefault(1)?.Ip ?? "—"; Fallback2Meta.Text = best.ElementAtOrDefault(1) is { } b ? $"{b.MedianMs:F1} ms • verified" : "Not verified";
    }

    private void BuildAutoTopFiveButtons(IEnumerable<DnsResolver> candidates)
    {
        if (AutoTopFiveButtons is null) return;
        AutoTopFiveButtons.Children.Clear();
        foreach (var (dns, index) in candidates.Take(5).Select((x, i) => (x, i + 1)))
        {
            var button = new WpfButton
            {
                Content = $"#{index} {dns.Ip}",
                Tag = dns.Ip,
                Style = (Style)FindResource("Btn"),
                Padding = new Thickness(8, 5, 8, 5),
                Margin = new Thickness(0, 0, 6, 5),
                ToolTip = "Connect to this Auto Pilot Top 5 server"
            };
            button.Click += AutoTopFiveServer_Click;
            AutoTopFiveButtons.Children.Add(button);
        }
    }

    private async void AutoTopFiveServer_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not WpfButton { Tag: string ip } || !IPAddress.TryParse(ip, out _)) return;
        await ApplyResolverAsync(ip, reason: "Manual Auto Pilot Top 5 connect");
    }

    private async void ConnectFallback1_Click(object sender, RoutedEventArgs e)
    {
        if (IPAddress.TryParse(Fallback1Text.Text, out _)) await ApplyResolverAsync(Fallback1Text.Text, reason: "Manual fallback 1 connect");
    }

    private async void ConnectFallback2_Click(object sender, RoutedEventArgs e)
    {
        if (IPAddress.TryParse(Fallback2Text.Text, out _)) await ApplyResolverAsync(Fallback2Text.Text, reason: "Manual fallback 2 connect");
    }

    private async void ConnectSelected_Click(object sender, RoutedEventArgs e)
    {
        if (Grid.SelectedItem is Row r) await ApplyResolverAsync(r.Ip, reason: "Manual selected server connect");
    }

    private void RefreshDnsList_Click(object sender, RoutedEventArgs e)
    {
        // Failed/Timeout entries are already persisted in the StoreFail DNS ledger.
        // Refresh only removes those unhealthy entries from the visible active list;
        // it does not touch any benchmark/apply/settings configuration.
        foreach (var dns in catalogData)
        {
            var bucket = dnsState.Get(dns.Ip);
            if (bucket is DnsBucket.Failed or DnsBucket.Timeout) continue;
            if (dns.Status.Equals("Failed", StringComparison.OrdinalIgnoreCase) || dns.Status.Equals("Timeout", StringComparison.OrdinalIgnoreCase))
                MarkDnsBucket(dns, dns.Status.Equals("Timeout", StringComparison.OrdinalIgnoreCase) ? DnsBucket.Timeout : DnsBucket.Failed);
        }
        var visible = catalogData.Where(dns => dnsState.Get(dns.Ip) is not DnsBucket.Failed and not DnsBucket.Timeout).ToList();
        RebuildRows(visible);
        UpdateFallbacks();
        UpdateDnsRecoveryStats();
        OperationText.Text = $"↻ DNS LIST REFRESHED • {visible.Count:N0} active entries • failed/timeout moved to StoreFail DNS";
    }


    // FIX 14: rebuilding the grid used to be rows.Clear() followed by up to
    // 5000 individual rows.Add() calls, each raising its own CollectionChanged
    // notification that the live-bound DataGrid had to react to one at a time
    // — a visible freeze right when a big Global Scout/Gaming Benchmark
    // finishes and the operator is watching for the result. Detaching
    // ItemsSource during the rebuild and reattaching once afterwards turns
    // that into a single layout pass.
    private void RebuildRows(IEnumerable<DnsResolver> ordered)
    {
        Grid.ItemsSource = null;
        rows.Clear();
        var materialized = ordered
            .Where(x => !string.IsNullOrWhiteSpace(x.Ip))
            .GroupBy(x => x.Ip, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.First())
            .Take(Math.Min(settings.MaxUiRows, 5000))
            .ToList();
        foreach (var r in materialized)
            rows.Add(new Row(r, r.Ip.Equals(connectedDns, StringComparison.OrdinalIgnoreCase), rows.Count + 1));
        Grid.ItemsSource = rows;
        UpdateDnsRecoveryStats();
    }
    private void RestorePersistedDnsState()
    {
        foreach (var dns in catalogData)
        {
            var bucket = dnsState.Get(dns.Ip);
            dns.Status = bucket switch
            {
                DnsBucket.Applied when dns.Status is "Not tested" or "" => "Applied",
                DnsBucket.Timeout when dns.Status is "Not tested" or "" => "Timeout",
                DnsBucket.Failed when dns.Status is "Not tested" or "" => "Failed",
                _ => dns.Status
            };
        }
    }

    private void MarkDnsBucket(DnsResolver dns, DnsBucket bucket)
    {
        if (bucket == DnsBucket.None) return;
        dnsState.Set(dns.Ip, bucket);
        if (!dns.Retired || bucket != DnsBucket.Applied)
            dns.Status = bucket.ToString();
    }

    private void UpdateDnsRecoveryStats()
    {
        var timeout = dnsState.GetAll(DnsBucket.Timeout).Count;
        var failed = dnsState.GetAll(DnsBucket.Failed).Count;
        var applied = dnsState.GetAll(DnsBucket.Applied).Count;
        DnsRecoveryStats.Text = $"TIMEOUT {timeout:N0}  •  FAILED {failed:N0}  •  APPLIED {applied:N0}";
        RestoreTimeoutBtn.Content = $"↻ RESTORE TIMEOUT DNS ({timeout:N0})";
        RestoreFailedBtn.Content = $"↻ RESTORE FAILED DNS ({failed:N0})";
        RestoreAppliedBtn.Content = $"↻ RESTORE APPLIED DNS ({applied:N0})";
    }

    private async void RestoreDnsBucket_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not WpfButton button || !Enum.TryParse<DnsBucket>(button.Tag?.ToString(), true, out var bucket)) return;
        var ips = dnsState.GetAll(bucket).Select(x => x.Ip).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (ips.Count == 0) { UpdateDnsRecoveryStats(); return; }

        // FIX (forensic review, RESTORE APPLIED DNS gap): this handler used to
        // treat all three buckets identically — flip the matching catalog rows'
        // Status/Retired flags back and print "restored", with no actual
        // network call for ANY of the three. That is a correct, sufficient
        // meaning for TIMEOUT and FAILED ("bring back into current Auto Pilot
        // consideration" — nothing on the wire needs to change for that).
        // But per USER_REQUIREMENTS_FA.txt Section 9, "RESTORE APPLIED DNS"
        // means "restore the prior/applied DNS configuration on the machine/
        // network", not just relabel a catalog row — and the button printed
        // "✓ RESTORED ... TO CATALOG" (a success claim) without ever touching
        // the adapter. That is exactly the false-status pattern the project's
        // own Rule 3 forbids. Applied now goes through the same real
        // apply+verify+rollback path (ApplyResolverAsync) every other DNS
        // switch in this app uses, targeting the most recently-applied IP
        // (dnsState.GetAll already orders newest-first). Timeout/Failed keep
        // the original catalog-only behavior, which was already correct for
        // what those two buttons mean.
        if (bucket == DnsBucket.Applied)
        {
            var targetIp = dnsState.GetAll(DnsBucket.Applied).FirstOrDefault()?.Ip;
            if (targetIp is null) { UpdateDnsRecoveryStats(); return; }
            OperationText.Text = $"↻ RESTORING APPLIED DNS • {targetIp}…";
            var outcome = await ApplyResolverAsync(targetIp, reason: "Restore applied DNS");
            OperationText.Text = outcome.Verified
                ? $"✓ RESTORED APPLIED DNS • {targetIp} • verified live"
                : outcome.RolledBack
                    ? $"✕ RESTORE APPLIED DNS FAILED • {targetIp} • rolled back to previous config"
                    : $"✕ RESTORE APPLIED DNS FAILED • {targetIp}";
            OperationStats.Text = outcome.Verified ? "Applied and verified on the adapter" : "No network change was left in place";
            UpdateDnsRecoveryStats();
            return;
        }

        foreach (var dns in catalogData.Where(x => ips.Contains(x.Ip)))
        {
            dns.Retired = false;
            dns.RetiredAt = null;
            dns.Status = bucket.ToString();
        }
        var restored = catalogData.Where(x => ips.Contains(x.Ip))
            .OrderByDescending(x => x.SampleCount)
            .ThenBy(x => x.P95Ms)
            .ToList();
        var rest = catalogData.Where(x => !ips.Contains(x.Ip));
        catalogData = restored.Concat(rest).ToList();
        RebuildRows(catalogData);
        OperationText.Text = $"✓ RESTORED {bucket.ToString().ToUpperInvariant()} DNS TO CATALOG";
        OperationStats.Text = $"{ips.Count:N0} DNS entries restored • nothing deleted";
    }

    private void SetBusy(bool busy) { QuickBtn.IsEnabled = !busy; GlobalBtn.IsEnabled = !busy; GamingBtn.IsEnabled = !busy; ApplyBtn.IsEnabled = !busy; RestoreBtn.IsEnabled = !busy; FlushBtn.IsEnabled = !busy; }
    private void BeginOperation(string name, int total)
    {
        operationCts?.Cancel(); operationCts = new CancellationTokenSource(); operationTotal = total; operationDone = operationSuccess = operationFailed = 0; operationWatch = Stopwatch.StartNew(); OperationText.Text = name; OperationBar.Value = 0; LiveProgress.IsIndeterminate = false;
        opTracker = new OperationTracker(total);
    }
    // key must be unique per candidate within this single operation (e.g. its
    // index in the candidate list), so a duplicate terminal write for the same
    // candidate is detectable rather than silently double-counted.
    private void ProgressOne(string key, TerminalState state)
    {
        var accepted = opTracker?.MarkTerminal(key, state) ?? true;
        Interlocked.Increment(ref operationDone);
        if (state == TerminalState.Success) Interlocked.Increment(ref operationSuccess); else Interlocked.Increment(ref operationFailed);
        if (!accepted)
        {
            // A candidate already had a terminal state. This is exactly the
            // bug class Section 9 exists to catch — surface it instead of
            // hiding it behind a normal-looking progress bar.
            Dispatcher.BeginInvoke(() => OperationText.Text = "⚠ ACCOUNTING ERROR • duplicate terminal state detected");
        }
        if ((DateTime.UtcNow - lastUiUpdate).TotalMilliseconds < 120 && operationDone < operationTotal) return;
        lastUiUpdate = DateTime.UtcNow;
        var done = operationDone; var ok = operationSuccess; var fail = operationFailed;
        Dispatcher.BeginInvoke(() =>
        {
            if (operationTotal <= 0) return;
            OperationBar.Value = done * 100.0 / operationTotal;
            var rate = operationWatch?.Elapsed.TotalSeconds > 0 ? done / operationWatch.Elapsed.TotalSeconds : 0;
            var remain = rate > 0 ? TimeSpan.FromSeconds(Math.Max(0, (operationTotal - done) / rate)) : TimeSpan.Zero;
            OperationStats.Text = $"{done:N0} / {operationTotal:N0} • {rate:N0} DNS/s • ETA {(rate > 0 ? remain.ToString(@"mm\:ss") : "…")} • OK {ok:N0} • FAIL {fail:N0}";
        }, System.Windows.Threading.DispatcherPriority.Background);
    }
    // Only place allowed to say a scan "COMPLETE". Reconciles against
    // Expected/terminal-state accounting before ever showing 100%/COMPLETE.
    private void EndOperation(string completeLabel)
    {
        var snap = opTracker?.Reconcile();
        LiveProgress.IsIndeterminate = false;
        if (snap is null)
        {
            OperationText.Text = completeLabel; OperationBar.Value = 100;
        }
        else
        {
            OperationBar.Value = snap.Expected > 0 ? snap.Completed * 100.0 / snap.Expected : 100;
            OperationText.Text = snap.Status switch
            {
                OperationStatus.Complete => completeLabel,
                OperationStatus.Incomplete => $"INCOMPLETE • {snap.Completed:N0}/{snap.Expected:N0} terminal",
                OperationStatus.Inconsistent => $"INCONSISTENT • accounting did not reconcile ({snap.Completed:N0}/{snap.Expected:N0})",
                OperationStatus.Cancelled => $"CANCELLED • {snap.Completed:N0}/{snap.Expected:N0}",
                _ => completeLabel
            };
        }
        OperationStats.Text = $"{operationDone:N0} / {operationTotal:N0} • OK {operationSuccess:N0} • FAIL {operationFailed:N0}";
        dnsState.Save();
        UpdateDnsRecoveryStats();
    }
    private async Task RunScoutAsync(bool applyWinner)
    {
        if (!await operationGate.WaitAsync(0)) return;
        try
        {
            if (catalogData.Count == 0) catalogData = await catalog.LoadGlobalAsync();
            var now = DateTimeOffset.UtcNow;
            var candidates = catalogData.Where(x => !string.IsNullOrWhiteSpace(x.Ip) && retirement.IsEligibleForActivePool(x, now)).ToList();
            BeginOperation("GLOBAL FAST SCOUT", candidates.Count); sounds.Play(NimoxySound.ScanStart);
            SetBusy(true);
            var ranked = new List<DnsResolver>();
            var gate = new object();
            // Section C.1: pooled worker loop (one UdpClient per worker, not
            // per resolver) instead of Parallel.ForEachAsync calling
            // fast.ProbeAsync per item -- this is the highest-volume socket
            // path in the app (up to the full catalog, concurrency up to
            // 1024), see FastProbeService.ProbeManyWithCallbackAsync.
            await fast.ProbeManyWithCallbackAsync(candidates, Math.Clamp(settings.BenchmarkConcurrency, 32, 1024), settings.AutoPilotProbeDomain,
                onStart: (i, _) => opTracker?.MarkStarted(i.ToString()),
                onResult: async (i, dns, p) =>
            {
                // FIX 3.1: previously EVERY resolver that answered a Fast Probe here
                // had its AvgMs/MedianMs/P95Ms/JitterMs/LossPct/SampleCount/Score
                // overwritten by this single ping — including resolvers that had
                // already gone through a full Deep Benchmark (dozens/hundreds of
                // samples). That meant every Global Scout silently demoted
                // genuinely well-tested resolvers back down to "1 sample", which
                // is exactly what Section 60 and AutoPilotService.VerifyCandidate's
                // own comment say must never happen. A resolver's real measurement
                // history is now only touched here if it was never Deep Benchmarked.
                if (p.Success)
                {
                    if (!dns.DeepTested)
                    {
                        dns.AvgMs = dns.MedianMs = dns.P95Ms = p.LatencyMs;
                        dns.JitterMs = 0; // a single sample carries no jitter signal yet
                        dns.LossPct = 0;
                        dns.SampleCount = 1;
                        // Section 60: a single Fast Probe sample must be capped exactly
                        // like a single Deep Benchmark sample — it must never be able to
                        // outrank resolvers with many stable measurements just because
                        // this one ping happened to be fast.
                        dns.Score = SingleProbeScore(p.LatencyMs);
                        dns.GamingScore = dns.Score;
                        dns.Confidence = ConfidenceService.Classify(dns.SampleCount, dns.LossPct, dns.JitterMs, dns.MedianMs);
                        dns.Status = "Healthy";
                    }
                    dns.LastChecked = DateTimeOffset.UtcNow;
                    dns.LastSuccessful = DateTimeOffset.UtcNow;
                    lock (gate) ranked.Add(dns);
                }
                else if (!dns.DeepTested) { dns.LossPct = 100; }
                retirement.RecordResult(dns, p.Success, DateTimeOffset.UtcNow);
                if (p.Success)
                {
                    dns.Status = dnsState.Get(dns.Ip) == DnsBucket.Applied ? "Applied" : (dns.DeepTested ? dns.Status : "Healthy");
                    if (dnsState.Get(dns.Ip) != DnsBucket.Applied) dnsState.Clear(dns.Ip);
                }
                else
                {
                    var bucket = p.Status == ProbeStatus.Timeout ? DnsBucket.Timeout : DnsBucket.Failed;
                    MarkDnsBucket(dns, bucket);
                    if (dns.Retired) dns.Status = "Retired";
                }
                var terminal = p.Success ? TerminalState.Success : p.Status switch { ProbeStatus.Timeout => TerminalState.Timeout, ProbeStatus.Cancelled => TerminalState.Cancelled, _ => TerminalState.Failed };
                ProgressOne(i.ToString(), terminal);
            }, ct: operationCts!.Token);
            // Keep every resolver in the catalog, including Timeout/Failed entries.
            // They are marked, persisted and recoverable instead of disappearing.
            catalogData = candidates.OrderByDescending(x => settings.GamingMode ? x.GamingScore : x.Score).ThenBy(x => x.P95Ms).ToList(); RebuildRows(catalogData);
            UpdateFallbacks(); EndOperation($"✓ SCOUT COMPLETE • {ranked.Count:N0} responded"); sounds.Play(NimoxySound.ScanComplete);
            if (opTracker?.IsGenuinelyComplete == true && applyWinner) await ApplyResolverAsync(FindBest(ranked)?.Ip, reason: "Global scout winner auto-apply");
        }
        catch (OperationCanceledException) { opTracker?.MarkOperatorCancelled(); EndOperation("CANCELLED"); }
        catch (Exception ex) { ReportRecoverableError(ex); }
        finally { SetBusy(false); operationGate.Release(); }
    }
    private async Task RunGamingAsync()
    {
        settings.GamingMode = true; settings.Save(); await RunScoutAsync(false);
        var finalists = catalogData.Take(Math.Clamp(settings.GamingDeepCandidates, 25, 150)).ToList();
        if (finalists.Count == 0) return;
        await DeepBenchmarkAsync(finalists, Math.Clamp(settings.GamingRounds, 2, 8));
    }
    private async Task DeepBenchmarkAsync(List<DnsResolver> candidates, int rounds)
    {
        if (!await operationGate.WaitAsync(0)) return;
        try
        {
            BeginOperation("DEEP GAMING BENCHMARK", candidates.Count); SetBusy(true);
            var indexed = candidates.Select((dns, i) => (dns, key: i.ToString())).ToList();
            await Parallel.ForEachAsync(indexed, new ParallelOptions { MaxDegreeOfParallelism = Math.Clamp(settings.BenchmarkConcurrency, 32, 1024), CancellationToken = operationCts!.Token }, async (item, ct) =>
            {
                var dns = item.dns;
                opTracker?.MarkStarted(item.key);
                var terminal = TerminalState.Failed;
                try { await benchmark.TestAsync(dns, rounds, ct); terminal = dns.SampleCount > 0 && dns.LossPct < 100 ? TerminalState.Success : TerminalState.Failed; }
                catch (OperationCanceledException) { dns.Status = "Cancelled"; terminal = TerminalState.Cancelled; throw; }
                catch { dns.Status = "Error"; terminal = TerminalState.Failed; }
                finally
                {
                    retirement.RecordResult(dns, terminal == TerminalState.Success, DateTimeOffset.UtcNow);
                    if (terminal == TerminalState.Success) dnsState.Clear(dns.Ip);
                    else MarkDnsBucket(dns, terminal == TerminalState.Cancelled ? DnsBucket.Failed : (dns.Status.Contains("Timeout", StringComparison.OrdinalIgnoreCase) ? DnsBucket.Timeout : DnsBucket.Failed));
                    ProgressOne(item.key, terminal);
                }
            });
            catalogData = candidates.OrderByDescending(x => x.GamingScore).ThenBy(x => x.P95Ms).ToList(); RebuildRows(catalogData); UpdateFallbacks();
            // The "winner" sound and label are only earned when every candidate
            // genuinely reached a terminal state — no fake 100% on a partial run.
            if (opTracker?.IsGenuinelyComplete == true) { EndOperation("✓ GAMING BENCHMARK COMPLETE"); sounds.Play(NimoxySound.Winner); }
            else EndOperation("GAMING BENCHMARK");
        }
        catch (OperationCanceledException) { opTracker?.MarkOperatorCancelled(); EndOperation("CANCELLED"); }
        catch (Exception ex) { ReportRecoverableError(ex); }
        finally { SetBusy(false); operationGate.Release(); }
    }
    private DnsResolver? FindBest(IEnumerable<DnsResolver> source) => source.Where(x => x.SampleCount > 0 && x.LossPct < 100).OrderByDescending(x => settings.GamingMode ? x.GamingScore : x.Score).ThenBy(x => x.P95Ms).FirstOrDefault();
    // Shared with RunScoutAsync so a single-probe result is scored exactly one
    // way everywhere (Section 60's confidence cap applied every time, not
    // reimplemented and potentially forgotten in a second call site).
    private static double SingleProbeScore(double latencyMs) =>
        ConfidenceService.ApplyConfidenceCap(Math.Clamp(100 * Math.Exp(-latencyMs / 80), 0, 100), 1);

    private async Task<DnsResolver?> ChooseReplacementAsync(CancellationToken ct)
    {
        var now = DateTimeOffset.UtcNow;
        var candidates = catalogData
            .Where(x => !string.IsNullOrWhiteSpace(x.Ip) && !x.Ip.Equals(connectedDns, StringComparison.OrdinalIgnoreCase) && retirement.IsEligibleForActivePool(x, now))
            .OrderByDescending(x => x.DeepTested ? (settings.GamingMode ? x.GamingScore : x.Score) : -1)
            .ThenBy(x => double.IsNaN(x.P95Ms) ? double.MaxValue : x.P95Ms)
            .ThenBy(x => x.Ip, StringComparer.OrdinalIgnoreCase)
            .Take(5)
            .ToList();
        if (candidates.Count == 0)
        {
            await Dispatcher.InvokeAsync(() => AutoTopFiveText.Text = "No eligible verified candidates yet.");
            return null;
        }

        await Dispatcher.InvokeAsync(() =>
        {
            AutoTopFiveText.Text = string.Join("   •   ", candidates.Select((x, i) => $"#{i + 1} {x.Ip}"));
            BuildAutoTopFiveButtons(candidates);
        });

        // Auto Pilot intentionally tests only the five current Top candidates.
        // This keeps the automatic decision fast while preserving every other
        // catalog/benchmark setting and data set unchanged.
        var probes = await fast.ProbeManyAsync(candidates, Math.Clamp(settings.BenchmarkConcurrency, 32, 512), ct);
        var successful = new List<(DnsResolver resolver, FastProbeResult probe)>();
        var checkedAt = DateTimeOffset.UtcNow;
        for (var i = 0; i < candidates.Count; i++)
        {
            var dns = candidates[i];
            var probe = probes[i];
            retirement.RecordResult(dns, probe.Success, checkedAt);
            if (probe.Success)
            {
                if (!dns.DeepTested)
                {
                    dns.AvgMs = dns.MedianMs = dns.P95Ms = probe.LatencyMs;
                    dns.JitterMs = 0;
                    dns.LossPct = 0;
                    dns.SampleCount = 1;
                    dns.Score = dns.GamingScore = SingleProbeScore(probe.LatencyMs);
                    dns.Confidence = ConfidenceService.Classify(1, 0, 0, dns.MedianMs);
                }
                dns.LastChecked = checkedAt;
                dns.LastSuccessful = checkedAt;
                dns.Status = dns.DeepTested ? dns.Status : "Healthy";
                successful.Add((dns, probe));
            }
            else
            {
                dns.Status = probe.Status == ProbeStatus.Timeout ? "Timeout" : (dns.Retired ? "Retired" : "Failed");
                if (!dns.DeepTested) dns.LossPct = 100;
            }
        }

        if (successful.Count == 0) return null;

        // The fresh probe chooses the fastest healthy resolver among the five.
        var selected = successful
            .OrderBy(x => x.probe.LatencyMs)
            .ThenByDescending(x => settings.GamingMode ? x.resolver.GamingScore : x.resolver.Score)
            .Select(x => x.resolver)
            .FirstOrDefault();
        await Dispatcher.InvokeAsync(() => AutoSelectedServerText.Text = selected is null ? "Selected: none" : $"Selected: {selected.Ip}");
        return selected;
    }
    private async Task<DnsResolver?> GetCurrentResolverAsync()
    {
        await RefreshConnectedDnsAsync();
        return connectedDns is null ? null : catalogData.FirstOrDefault(x => x.Ip.Equals(connectedDns, StringComparison.OrdinalIgnoreCase)) ?? new DnsResolver { Ip = connectedDns, Provider = "Current Windows DNS", Status = "Current" };
    }
    // FIX 4.3: previously returned a plain bool, so a failed switch's rollback
    // outcome was invisible to AutoPilotService — see SwitchOutcome for why.
    private async Task<SwitchOutcome> SwitchVerifiedAsync(DnsResolver candidate, DnsResolver? previous, CancellationToken ct) => await ApplyResolverAsync(candidate.Ip, previous?.Ip, ct, reason: "Auto Pilot verified switch");
    private async Task<SwitchOutcome> ApplyResolverAsync(string? ip, string? previousIp = null, CancellationToken ct = default, string reason = "Manual apply")
    {
        // FIX 4.1: the address family of the target IP now drives every step
        // below (which netsh/PowerShell IP version to read and write), so an
        // IPv6 resolver goes through the same real apply/verify/rollback path
        // an IPv4 one does instead of failing at the DnsApplyService layer.
        if (string.IsNullOrWhiteSpace(ip) || AdapterCombo.SelectedItem is not string adapter || !IPAddress.TryParse(ip, out var parsedIp))
            return new SwitchOutcome(false, false, false);
        var family = parsedIp.AddressFamily;
        if (!await applyGate.WaitAsync(0, ct)) return new SwitchOutcome(false, false, false);
        var operationId = Guid.NewGuid();
        var oldIp = previousIp ?? connectedDns;
        var oldResolver = catalogData.FirstOrDefault(x => x.Ip.Equals(oldIp, StringComparison.OrdinalIgnoreCase));
        var newResolver = catalogData.FirstOrDefault(x => x.Ip.Equals(ip, StringComparison.OrdinalIgnoreCase));
        var verified = false; var rolledBack = false; var rollbackVerified = false;
        try
        {
            var before = await dnsApply.GetCurrentDnsAsync(adapter, family);
            var result = await dnsApply.ApplyAsync(ip, null, adapter);
            if (!result.Success)
            {
                // FIX 4.2: this path already had a try/catch; kept, but now
                // shares the same family-aware, verifying RestoreExactAsync as
                // the other rollback path below instead of a bare fire-and-
                // forget ApplyAsync call.
                try { rollbackVerified = await RestoreExactAsync(adapter, before, family); }
                catch (Exception ex) { ReportRecoverableError(ex); }
                rolledBack = true;
                return new SwitchOutcome(false, rolledBack, rollbackVerified);
            }
            await RefreshConnectedDnsAsync();
            var verify = await fast.ProbeAsync(ip, settings.AutoPilotProbeDomain, ct);
            verified = verify.Success;
            if (!verify.Success)
            {
                // FIX 4.2: this second rollback path used to call
                // RestoreExactAsync with NO try/catch at all — any exception
                // here (e.g. netsh/PowerShell throwing) propagated straight
                // out of ApplyResolverAsync. Callers like Apply_Click and
                // Grid_DoubleClick invoke this from an async void event
                // handler with no surrounding try/catch, so an unhandled
                // exception there crashes the entire WPF application. Both
                // rollback paths are now symmetric.
                try { rollbackVerified = await RestoreExactAsync(adapter, before, family); }
                catch (Exception ex) { ReportRecoverableError(ex); }
                rolledBack = true;
                await RefreshConnectedDnsAsync();
                sounds.Play(NimoxySound.Failure);
                return new SwitchOutcome(false, rolledBack, rollbackVerified);
            }
            AddGraphSample(verify.LatencyMs);
            if (newResolver is not null) MarkDnsBucket(newResolver, DnsBucket.Applied);
            if (oldResolver is not null && !oldResolver.Ip.Equals(ip, StringComparison.OrdinalIgnoreCase)) oldResolver.Status = oldResolver.SampleCount > 0 ? oldResolver.Status : "Not tested";
            RebuildRows(catalogData.OrderByDescending(x => x.Ip.Equals(ip, StringComparison.OrdinalIgnoreCase)).ThenByDescending(x => settings.GamingMode ? x.GamingScore : x.Score));
            sounds.Play(NimoxySound.Success);
            return new SwitchOutcome(true, false, false);
        }
        finally
        {
            // Section 67: every switch attempt is logged with this exact
            // field set, whether it ultimately succeeded, failed, or rolled
            // back — not only the happy path.
            history.AppendSwitch(new SwitchLogEntry(
                operationId, DateTimeOffset.UtcNow, oldIp, ip,
                oldResolver?.Score, newResolver?.Score,
                oldResolver?.P95Ms, newResolver?.P95Ms,
                oldResolver?.LossPct, newResolver?.LossPct,
                reason, verified, rolledBack));
            applyGate.Release();
        }
    }
    // FIX 4.3: previously fired the restore and returned immediately with no
    // idea whether it actually landed — the caller then unconditionally
    // logged/announced "restored". This reads the adapter back afterwards
    // and only reports success if the servers Windows now reports actually
    // match what was requested.
    private async Task<bool> RestoreExactAsync(string adapter, IReadOnlyList<string> servers, AddressFamily family)
    {
        if (servers.Count == 0)
        {
            var dhcp = await dnsApply.RestoreAutomaticAsync(adapter, family);
            return dhcp.Success;
        }
        var result = await dnsApply.ApplyAsync(servers[0], servers.Count > 1 ? servers[1] : null, adapter);
        if (!result.Success) return false;
        var after = await dnsApply.GetCurrentDnsAsync(adapter, family);
        var expected = servers.Select(x => x.Trim()).ToArray();
        return after.Count == expected.Length && expected.SequenceEqual(after, StringComparer.OrdinalIgnoreCase);
    }
    private async Task SwitchFallbackAsync()
    {
        var fallback = catalogData.Where(x => x.SampleCount > 0 && x.LossPct < 35 && !x.Ip.Equals(connectedDns, StringComparison.OrdinalIgnoreCase)).OrderByDescending(x => x.GamingScore).ThenBy(x => x.P95Ms).FirstOrDefault();
        if (fallback is not null) await ApplyResolverAsync(fallback.Ip);
    }
    // FIX C.2 (perf/race): AutoCheck.IsChecked is set from settings.AutoPilotEnabled
    // in the constructor, which fires this very handler synchronously — before
    // LoadAdapters()/catalog.LoadGlobalAsync() have run (those only happen in
    // InitializeAsync, invoked from Loaded). That started a first Auto Pilot
    // cycle against an empty adapter list and an empty catalog (a wasted,
    // guaranteed-no-op search), and then InitializeAsync's own
    // "if (settings.AutoPilotEnabled) StartAutoPilot();" started a *second*
    // one a moment later — every launch paid for one throwaway cycle for
    // nothing. Guarded the same way Adapter_Changed already guards itself
    // (`if (IsLoaded)`) so only a genuine user/tray toggle after the window
    // has loaded reaches StartAutoPilot()/Stop() here.
    private void Auto_Checked(object s, RoutedEventArgs e) { if (!IsLoaded) return; settings.AutoPilotEnabled = true; settings.Save(); StartAutoPilot(); }
    private void Auto_Unchecked(object s, RoutedEventArgs e) { if (!IsLoaded) return; settings.AutoPilotEnabled = false; settings.Save(); autoPilot.Stop(); AutoStateText.Text = "○ PAUSED"; AutoStatusDetail.Text = "Paused"; }
    private void StartAutoPilot()
    {
        settings.AutoPilotEnabled = true; AutoStateText.Text = "● STARTING"; AutoCountdownText.Text = $"Every {settings.AutoPilotIntervalSeconds}s";
        autoPilot.Start(AutoPilotChooseReplacementAsync, SwitchVerifiedAsync, GetCurrentResolverAsync, GetAutoPilotFallbacks);
    }
    // FIX 2.1: previously this took operationGate and released it on the very
    // next line, before ChooseReplacementAndApplyAsync ever ran — the check
    // was pure theater and RUN NOW could freely overlap a Global Scout / Deep
    // Benchmark that was already mutating the same DnsResolver objects. The
    // gate is now held for the entire choose+apply operation, exactly like
    // RunScoutAsync/DeepBenchmarkAsync do, and a second RUN NOW (or Scout/
    // Benchmark) click while one is in flight is correctly rejected instead
    // of silently racing it.
    // FIX 2.2: RUN NOW used to hand ChooseReplacementAsync a hard-coded
    // CancellationToken.None, so once started it could never be cancelled.
    // It now shares operationCts with every other operation, so the existing
    // Cancel button actually cancels a RUN NOW in progress.
    private async void AutoRun_Click(object s, RoutedEventArgs e)
    {
        if (!await operationGate.WaitAsync(0)) return;
        try
        {
            operationCts?.Cancel();
            operationCts = new CancellationTokenSource();
            SetStatusColor("working");
            OperationText.Text = "🟠 AUTO PILOT • TESTING TOP 5 SERVERS…";
            AutoStatusDetail.Text = "Testing top 5 DNS servers…";
            AutoReasonText.Text = "Auto Pilot is testing the current Top 5 and will select the best verified server automatically.";
            SetBusy(true);
            await ChooseReplacementAndApplyAsync(operationCts.Token);
            SetStatusColor("success");
        }
        catch (OperationCanceledException) { OperationText.Text = "AUTO PILOT PAUSED"; }
        catch (Exception ex) { SetStatusColor("error"); ReportRecoverableError(ex); }
        finally { SetBusy(false); operationGate.Release(); }
    }
    private async Task ChooseReplacementAndApplyAsync(CancellationToken ct)
    {
        var c = await ChooseReplacementAsync(ct);
        if (c is not null) await ApplyResolverAsync(c.Ip, ct: ct, reason: "Manual Run Now");
    }
    // FIX 2.3: Auto Pilot's own background cycle (AutoPilotService.LoopAsync,
    // running on its own timer) used to call ChooseReplacementAsync directly,
    // completely outside operationGate. ChooseReplacementAsync's "untested"
    // branch mutates DnsResolver.AvgMs/MedianMs/P95Ms/Score/SampleCount/etc.
    // in place — the exact same fields RunScoutAsync's and DeepBenchmarkAsync's
    // Parallel.ForEachAsync loops mutate on the exact same shared catalogData
    // objects. With no shared lock, a background Auto Pilot tick landing
    // mid-Scout/Benchmark was a genuine data race. Routing the Auto Pilot
    // delegate through the same operationGate as every manual operation means
    // only one of {Auto Pilot cycle, RUN NOW, Global Scout, Deep Benchmark}
    // can ever touch those objects at a time. If a manual operation currently
    // owns the gate, this simply skips the candidate search for this tick
    // (returns null, i.e. "nothing found this round") instead of racing —
    // Auto Pilot tries again on its next scheduled tick.
    private async Task<DnsResolver?> AutoPilotChooseReplacementAsync(CancellationToken ct)
    {
        if (!await operationGate.WaitAsync(0, ct)) return null;
        try { return await ChooseReplacementAsync(ct); }
        finally { operationGate.Release(); }
    }
    private IEnumerable<DnsResolver> GetAutoPilotFallbacks()
    {
        return catalogData
            .Where(x => x.SampleCount > 0 && x.LossPct < 35 && !string.Equals(x.Ip, connectedDns, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(x => x.DeepTested ? (settings.GamingMode ? x.GamingScore : x.Score) : -1)
            .ThenBy(x => double.IsNaN(x.P95Ms) ? double.MaxValue : x.P95Ms)
            .Take(5)
            .ToList();
    }
    private void AutoPause_Click(object s, RoutedEventArgs e) { AutoCheck.IsChecked = false; }
    private void OnAutoPilotChanged(AutoPilotEvent e)
    {
        Dispatcher.BeginInvoke(() =>
        {
            var working = e.State is AutoPilotState.Starting or AutoPilotState.Verifying or AutoPilotState.Searching or AutoPilotState.CandidateFound or AutoPilotState.VerifyingCandidate or AutoPilotState.Switching;
            var error = e.State == AutoPilotState.Error || e.Message.Contains("failed", StringComparison.OrdinalIgnoreCase) || e.Message.Contains("error", StringComparison.OrdinalIgnoreCase);
            SetStatusColor(error ? "error" : working ? "working" : e.State is AutoPilotState.Healthy or AutoPilotState.Switched ? "success" : "neutral");
            AutoStateText.Text = e.State switch { AutoPilotState.Healthy => "● HEALTHY", AutoPilotState.Degraded => "⚠ DEGRADED", AutoPilotState.Verifying => "🔎 VERIFYING", AutoPilotState.Searching => "⚡ SEARCHING", AutoPilotState.Switching => "↔ SWITCHING", AutoPilotState.Switched => "✓ OPTIMIZED", AutoPilotState.Paused => "○ PAUSED", _ => "● " + e.State.ToString().ToUpperInvariant() };
            AutoStatusDetail.Text = e.Message;
            AutoReasonText.Text = e.Message;
            AutoCountdownText.Text = $"Next check • {settings.AutoPilotIntervalSeconds}s";
            if (e.Probe is { } p && p.Success) AddGraphSample(p.LatencyMs);
            CurrentStatusText.Text = e.Message;
            OperationText.Text = working ? $"🟠 {e.Message}" : error ? $"🔴 {e.Message}" : e.Message;
            PersistKnownDnsBuckets();
            UpdateDnsRecoveryStats();
        });
    }

    private void SetStatusColor(string state)
    {
        var brushKey = state switch
        {
            "working" => "Orange",
            "error" => "ErrorRed",
            "success" => "Good",
            _ => "Text"
        };
        try
        {
            var brush = (MediaBrush)FindResource(brushKey);
            AutoStateText.Foreground = brush;
            AutoStatusDetail.Foreground = brush;
            AutoSelectedServerText.Foreground = brushKey == "ErrorRed" ? brush : (MediaBrush)FindResource("Orange");
        }
        catch { }
    }

    private void PersistKnownDnsBuckets()
    {
        foreach (var dns in catalogData)
        {
            if (dns.Status.Equals("Timeout", StringComparison.OrdinalIgnoreCase)) dnsState.Set(dns.Ip, DnsBucket.Timeout);
            else if (dns.Status.Equals("Failed", StringComparison.OrdinalIgnoreCase) || dns.Status.Equals("Retired", StringComparison.OrdinalIgnoreCase)) dnsState.Set(dns.Ip, DnsBucket.Failed);
            else if (dns.Status.Equals("Applied", StringComparison.OrdinalIgnoreCase)) dnsState.Set(dns.Ip, DnsBucket.Applied);
        }
        dnsState.Save();
    }
    private async void FastProbe_Click(object s, RoutedEventArgs e) { var c = await GetCurrentResolverAsync(); if (c is null) { OperationText.Text = "No explicit DNS • Auto Pilot will use verified candidates."; return; } var p = await fast.ProbeAsync(c.Ip); if (p.Success) { AddGraphSample(p.LatencyMs); OperationText.Text = $"✓ FAST PROBE • {c.Ip} • {p.LatencyMs:F1} ms"; } else OperationText.Text = $"⚠ FAST PROBE • {c.Ip} • {p.Status}"; }
    private async void Global_Click(object s, RoutedEventArgs e) => await RunScoutAsync(false);
    private async void Gaming_Click(object s, RoutedEventArgs e) => await RunGamingAsync();
    private async void Apply_Click(object s, RoutedEventArgs e) { if (Grid.SelectedItem is Row r) await ApplyResolverAsync(r.Ip); }
    private async void Restore_Click(object s, RoutedEventArgs e)
    {
        if (AdapterCombo.SelectedItem is not string a) return;
        var r4 = await dnsApply.RestoreAutomaticAsync(a, AddressFamily.InterNetwork);
        var r6 = await dnsApply.RestoreAutomaticAsync(a, AddressFamily.InterNetworkV6);
        OperationText.Text = r4.Success && r6.Success ? "✓ DHCP DNS RESTORED" : "✕ RESTORE FAILED";
        if (connectedDns is not null) dnsState.Clear(connectedDns);
        dnsState.Save();
        await RefreshConnectedDnsAsync();
        RebuildRows(catalogData);
    }
    private async void Flush_Click(object s, RoutedEventArgs e) => await FlushAsync();
    private async Task FlushAsync() { var r = await dnsApply.FlushDnsAsync(); OperationText.Text = r.Success ? "✓ DNS CACHE FLUSHED" : "✕ FLUSH FAILED"; sounds.Play(r.Success ? NimoxySound.Success : NimoxySound.Failure); }
    private void Cancel_Click(object s, RoutedEventArgs e) { try { operationCts?.Cancel(); } catch { } }
    private void Grid_SelectionChanged(object s, System.Windows.Controls.SelectionChangedEventArgs e) { if (Grid.SelectedItem is Row r) { SelectedDns.Text = r.Ip; SelectedProvider.Text = $"{r.Provider} • {r.Country}"; SelectedMetrics.Text = $"MED {F(r.MedianMs)} ms  •  P95 {F(r.P95Ms)}  •  JITTER {F(r.JitterMs)}  •  LOSS {r.LossPct:F1}%  •  GAME {r.GamingScore:F1}  •  SCORE {r.Score:F1}"; } }
    private void Grid_DoubleClick(object s, MouseButtonEventArgs e) { if (Grid.SelectedItem is Row r) _ = ApplyResolverAsync(r.Ip); }
    private void AddGraphSample(double ms) { if (double.IsNaN(ms) || double.IsInfinity(ms)) return; graphSamples.Enqueue(ms); while (graphSamples.Count > 80) graphSamples.Dequeue(); GraphValue.Text = $"{ms:F1} ms"; GraphMeta.Text = $"Live samples: {graphSamples.Count} • last {DateTime.Now:HH:mm:ss}"; RenderGraph(); }
    private void RenderGraph()
    {
        if (PrimaryGraph.ActualWidth < 20 || PrimaryGraph.ActualHeight < 20) return; var a = graphSamples.ToArray(); if (a.Length < 2) return; var min = Math.Max(0, a.Min() - 5); var max = Math.Max(min + 10, a.Max() + 5); var pts = new PointCollection(); for (var i = 0; i < a.Length; i++) pts.Add(new System.Windows.Point(i * PrimaryGraph.ActualWidth / Math.Max(1, a.Length - 1), PrimaryGraph.ActualHeight - ((a[i] - min) / (max - min) * (PrimaryGraph.ActualHeight - 4)))); PrimaryLine.Points = pts;
    }
    private async Task RefreshCatalogInBackground()
    {
        try { await Task.Delay(TimeSpan.FromSeconds(5)); var fresh = await catalog.LoadGlobalAsync(); if (fresh.Count > 0) { catalogData = MergeCatalog(catalogData, fresh); RestorePersistedDnsState(); CatalogStats.Text = $"{catalogData.Count:N0} resolvers • background refresh complete"; RebuildRows(catalogData); } } catch { }
    }
    private static List<DnsResolver> MergeCatalog(IEnumerable<DnsResolver> a, IEnumerable<DnsResolver> b) { var map = new Dictionary<string, DnsResolver>(StringComparer.OrdinalIgnoreCase); foreach (var x in a.Concat(b)) if (!string.IsNullOrWhiteSpace(x.Ip)) map.TryAdd(x.Ip, x); return map.Values.ToList(); }
    private static string F(double x) => double.IsNaN(x) ? "—" : x.ToString("F1");
    public sealed class Row
    {
        private readonly DnsResolver r; public Row(DnsResolver r, bool connected, int rank) { this.r = r; IsConnected = connected; Rank = rank; }
        public int Rank { get; } public bool IsConnected { get; } public string Ip => r.Ip; public string Provider => r.Provider; public string Country => r.Country; public double MedianMs => r.MedianMs; public double P95Ms => r.P95Ms; public double JitterMs => r.JitterMs; public double LossPct => r.LossPct; public double GamingScore => r.GamingScore; public double Score => r.Score; public string Status => IsConnected ? "CONNECTED" : r.Status;
    }
}
