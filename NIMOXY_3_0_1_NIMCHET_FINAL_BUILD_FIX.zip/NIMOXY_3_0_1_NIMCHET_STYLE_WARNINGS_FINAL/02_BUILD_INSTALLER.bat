@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title NIMOXY - Build Installer
color 0B

echo.
echo  ==================================================
echo       NIMOXY  -  BUILD INSTALLER
echo  ==================================================
echo.
if not exist "Release\NIMOXY\NIMOXY.exe" (
  echo [INFO] EXE is missing. Building it first...
  call "%~dp001_BUILD_EXE.bat"
  if errorlevel 1 exit /b 1
)

set "ISCC="
for %%P in (
  "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
  "%ProgramFiles%\Inno Setup 6\ISCC.exe"
  "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"
  "%ProgramFiles%\Inno Setup 7\ISCC.exe"
) do if not defined ISCC if exist %%P set "ISCC=%%~P"

if not defined ISCC (
  for /f "delims=" %%P in ('where ISCC 2^>nul') do if not defined ISCC set "ISCC=%%P"
)

if not defined ISCC (
  echo [ERROR] Inno Setup compiler (ISCC.exe) was not found.
  echo.
  echo NIMOXY EXE is already built successfully.
  echo To create NIMOXY_Setup.exe, install Inno Setup 6/7 and run this file again.
  echo The script automatically checks the normal installation folders.
  echo.
  pause
  exit /b 2
)

echo [INFO] Using: %ISCC%
if not exist "Release\Installer" mkdir "Release\Installer"
"%ISCC%" "Installer\NIMOXY.iss" /O"%CD%\Release\Installer"
if errorlevel 1 (
  echo.
  echo [FAILED] Installer compilation failed. Read the Inno Setup error above.
  pause
  exit /b 1
)

echo.
echo [OK] Installer created:
echo %CD%\Release\Installer\NIMOXY_Setup.exe
echo.
pause
exit /b 0
